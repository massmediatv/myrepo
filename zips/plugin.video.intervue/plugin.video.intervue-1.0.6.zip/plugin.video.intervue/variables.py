import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob, zipfile
import shutil
try: import urllib.request as urlrequest
except: import urllib2 as urlrequest
import urllib
import re
import time
import datetime
from datetime import date, datetime, timedelta
from sqlite3 import dbapi2 as database



###############################################################################
#						                                                  XBMC ARGUMENTS
###############################################################################

dialog = xbmcgui.Dialog()
dialogProgress  = xbmcgui.DialogProgress()
space = '[COLOR ffa8a8a8][B]-------------------------------------------------[/B][/COLOR]'

###############################################################################
#						                                                  GLOBAL PATHS
###############################################################################
addonID = 'script.ivueguide'
try: transPath = xbmc.translatePath
except: transPath = xbmcvfs.translatePath
addon_name = xbmcaddon.Addon(addonID)
linkaddon = addon_name.getSetting('userurl')
addon_ID       = 'plugin.video.intervue'
addonTitle     = 'InterVUE'
addon          = xbmcaddon.Addon(addon_ID)
home           = transPath('special://home/')
profile       = transPath('special://profile/')
addons       = os.path.join(home, 'addons')
userData       = os.path.join(home, 'userdata')
addonData      = os.path.join(userData, 'addon_data', addon_ID)
inipath = transPath(os.path.join('special://profile', 'addon_data', addon_ID, 'resources', 'ini'))
subpath = transPath(os.path.join('special://profile', 'addon_data', addon_ID, 'resources', 'subs'))
ivuepath = transPath(os.path.join('special://profile', 'addon_data', addonID))
subData = transPath('special://profile/addon_data/script.ivueguide/resources/config/Data.txt')
subLogos = transPath('special://profile/addon_data/script.ivueguide/resources/config/Logo.txt')
catData = transPath('special://profile/addon_data/script.ivueguide/resources/categories/')	
packagesdir    =  transPath(os.path.join('special://home/addons/packages',''))
thumbnails    =  transPath('special://home/userdata/Thumbnails')
cachePath = os.path.join(home, 'cache')
tempPath = transPath('special://temp')
textures  = transPath('special://home/userdata/Database/Textures13.db')
kodilog = transPath('special://logpath/kodi.log')
kodiold = transPath('special://logpath/kodi.old.log')
icon = transPath(os.path.join('special://home/addons/', addon_ID, 'icon.png'))

if not os.path.exists(subpath):
    os.makedirs(subpath)
if not os.path.exists(inipath):
    os.makedirs(inipath)


