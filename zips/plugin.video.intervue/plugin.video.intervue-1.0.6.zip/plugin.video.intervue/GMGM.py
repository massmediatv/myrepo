# -*- coding: utf-8 -*-

# Deleting this file cripples the entire addon

#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
# http://kodi.wiki/view/How-to:Write_Python_Scripts
################################################

import sys,os,json
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re, xbmcvfs
import shutil
import base64
try: import urllib.request as urlrequest
except: import urllib as urlrequest
try:import urllib.parse
except:pass
import time
import datetime
try: transPath = xbmc.translatePath
except: transPath = xbmcvfs.translatePath
addontag = ['plugin.video.gmgm']
subname       = 'GMGM'
addon         = 'plugin.video.intervue'
ADDONID       = addon
ivue          = 'script.ivueguide'
addonPath     = transPath(os.path.join('special://home/addons', addon))
basePath      = transPath(os.path.join('special://profile', 'addon_data', addon))
tmp_File      = os.path.join(basePath, 'tmp.ini')
icon          = transPath(os.path.join('special://home/addons', addon, 'icon.png'))
dbPath        = transPath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog        = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
subData       = transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config', 'Data.txt'))
subLogos       = transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config', 'Logo.txt'))
inipath       = transPath(os.path.join(basePath, 'resources', 'ini'))
inifile = os.path.join(inipath, subname+'.ini')

xmlurl = ''
logosUrl = ''
categoryUrl = ''
categoryFile = transPath(os.path.join('special://profile', 'addon_data', addon, 'resources', 'categories', subname+'.ini'))

if not os.path.exists(basePath):
    os.makedirs(basePath)
            
if not os.path.exists(os.path.join(basePath, 'resources')):
    os.makedirs(os.path.join(basePath, 'resources'))
if not os.path.exists(transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config'))):
    os.makedirs(transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config')))
def notify(header,msg,icon_path):
    duration=2000
    xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)

def StartCreate():

    if os.path.exists(inifile):
        os.remove(inifile)
    if not os.path.exists(inipath):
        os.makedirs(inipath)
    path = os.path.join(transPath('special://home/addons'), ivue) 
    path2 = os.path.join(transPath('special://home/addons'), addon)
    if os.path.exists(path) and os.path.exists(path2):
        add_ini()

    return

def add_ini():
    for FoundAddon in addontag:
        if CheckHasThisAddon(FoundAddon):
            notify('generating channels',subname,os.path.join('special://home/addons', FoundAddon, 'icon.png'))##NOTIFY##
            ParseData(FoundAddon)
def CheckHasThisAddon(FoundAddon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % FoundAddon) == 1:
        settingsFileCheck = transPath(os.path.join('special://home/userdata/addon_data',FoundAddon,'settings.xml'))
        if os.path.exists(settingsFileCheck):
            return True
    else:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        return False 
#

def ParseData(FoundAddon):
	Addoninipath  = inifile
	response = GrabSettingsFrom(FoundAddon)
	result   = response['result'] 
	ChannelsResult = result['files']    
	ExtrasFileToWrite  = open(Addoninipath, 'w')  
	ExtrasFileToWrite.write('[')
	ExtrasFileToWrite.write(FoundAddon)
	ExtrasFileToWrite.write(']')
	ExtrasFileToWrite.write('\n')   
	TheAddonURL = []   
	for channel in ChannelsResult:
		ParsedChannels = channel['label']
		stream  = channel['file']
		ChannelURL  = GetStuff(FoundAddon, ParsedChannels)
		channel = RemoveChanCrap(FoundAddon, ChannelURL)
		try:FinalChannelString = channel.split(' -  ')[0] + ' =' + stream#Jules: make correct formating for channel names
		except:FinalChannelString = channel.split('  ')[0] + ' =' + stream
		
		TheAddonURL.append(FinalChannelString.encode('ascii', 'ignore'))
		TheAddonURL.sort()
	for item in TheAddonURL:
	  if not str(item.decode('utf-8')).lstrip().startswith('='):
	    ExtrasFileToWrite.write(str(item.decode('utf-8')).lstrip() +"\n" )
	ExtrasFileToWrite.close()
	Clean_Names_(Addoninipath,tmp_File)
	
	

def GrabSettingsFrom(FoundAddon):
	try:quotePlus = urllib.parse
	except:quotePlus = urlrequest
	Addon    =  xbmcaddon.Addon(FoundAddon)
	username =  Addon.getSetting('Username')
	password =  Addon.getSetting('Password')
	BeginningOfPluginString   = 'plugin://' + FoundAddon

	urlBody= '/?action=LiveCategory&extra&page&plot&thumbnail=&title=All&url='
	endOfString    =  GetVariables(FoundAddon)
	startOfString  =  BeginningOfPluginString + urlBody + quotePlus.quote_plus(endOfString)
	GrabThisUrl = 'username=' + username + '&password=' + password + '&type=get_live_streams&cat_id=0'
	queryURL = BeginningOfPluginString  + '/?action=security_check&extra&page&plot&thumbnail&title=live%20TV&url'
	query = startOfString +  quotePlus.quote_plus(GrabThisUrl)
	checkthisurl = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % queryURL)
	checkthisurltoo = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query)   
	try:
		#xbmc.executeJSONRPC(checkthisurl)
		response = xbmc.executeJSONRPC(checkthisurltoo)
		content = json.loads(response)
		return content
	except Exception as e:
		xbmc.executebuiltin( "Dialog.Close(busydialog)" )
		#RunSetSetting(e)
		print (e)
		return {'Error' : 'Plugin Error'}
#    
def GetStuff(FoundAddon, RemoveURLGarbage):
    RemoveURLGarbage = RemoveURLGarbage.replace('COLOR+', '').replace(' [/B]', '').replace('[COLOR WHITE]', '').replace('[/COLOR]', '').replace('[COLOR white]', '').replace('COLOR+steelblue', '').replace('[COLOR steelblue]', '')      
    return RemoveURLGarbage
#    
def RemoveChanCrap(FoundAddon, FoundChannels):
    channel = FoundChannels.rsplit('[/B]', 1)[0].split('[B]', 1)[-1]        
    return channel
#       
def GetVariables(FoundAddon):
    Addon    =  xbmcaddon.Addon(FoundAddon) 
    addre_ss =  'https://iwday1.com' 
    po_rt =  '2087'
    correct_address = addre_ss + ':' + po_rt + '/enigma2.php?'
    return correct_address

def Clean_Names_(Clean_Name,tmpFile): 
	if os.path.exists(tmpFile):
		os.remove(tmpFile)
	os.rename(Clean_Name, tmpFile)
	orig=open(tmpFile).read()	
	f=open(Clean_Name,'a')
	f.write(orig)

	r=open(tmpFile).read().splitlines()
	o=open(Clean_Name).read().splitlines()
	for s in r:

		s=s.replace('BT SPORTS 1 UK','BT Sport 1 UK')
		s=s.replace('BT SPORTS 2 UK','BT Sport 2 UK')
		s=s.replace('BT SPORTS 3 UK','BT Sport 3 UK')
		s=s.replace('(HD)NFL: ','NFL ')
		s=s.replace('(HD)NFLFOX: ','NFL ')
		s=s.replace(' # ','')
		s=s.replace(' - ','')
		s=s.replace(' - .','')
		s=s.replace('(HD)NFLN Redzone: 		','NFL ')
		s=s.replace('(HD)NFLN: ','NFL')
		s=s.replace('(HD)NFLNBC:','NFL NBC')
		
		s=s.replace('[COLOR Normal \e[1mBold]','')
		
		s=s.replace('E!','E! Entertainment')
		s=s.replace('BBC 1','BBC One')
		s=s.replace('BBC1','BBC One')
		s=s.replace('BBC 2','BBC Two')
		s=s.replace('BBC 3','BBC THREE')
		s=s.replace('BBC 4','BBC FOUR')
		s=s.replace('COMEDY CENTRAL EXTRA UK','COMEDY CENTRAL XTRA UK')
		s=s.replace('INVESTIGATION DISCOVERY','ID')
		s=s.replace('DISCOVERY UK HD','DISCOVERY CHANNEL UK HD')
		s=s.replace('DISCOVERY UK SD','DISCOVERY CHANNEL UK SD')
		s=s.replace('DISCOVERY HOME & HEALTH','Discovery Home and Health')
		s=s.replace('DISCOVERY USA','Discovery Channel USA')
		s=s.replace('NATIONAL GEOGRAPHICAL','National Geographic Channel HD')
		s=s.replace('SKY ONE','Sky1')
		s=s.replace('SKY TWO','Sky2')
		s=s.replace('SKY WITNESS','SKY WITNESS / LIVING')
		s=s.replace('CRIME AND INVESTIGATION','CI')
		s=s.replace('CLUBLAND UK','CLUBLAND TV')
		s=s.replace('SKY CINEMA PREMIER HD','SKY CINEMA PREMIERE HD')
		s=s.replace('SKY CINEMA PREMIER SD','SKY CINEMA PREMIERE SD')
		s=s.replace('SKY CINEMA SCI-FI HD','SKY CINEMA SCI-FI AND HORROR HD')
		s=s.replace('SKY CINEMA SCI-FI SD','SKY CINEMA SCI-FI AND HORROR SD')
		s=s.replace('SKY CINEMA VILLAINS HD','SKY CINEMA GREATS HD')
		s=s.replace('SKY CINEMA VILLAINS SD','SKY CINEMA GREATS SD')
		s=s.replace('SKY CINEMA HITS HD','SKY CINEMA SHOWCASE HD')	
		s=s.replace('SKY CINEMA HITS SD','SKY CINEMA SHOWCASE SD')	
		s=s.replace('SONY MOVIES USA','SONY MOVIE CHANNEL')
		s=s.replace('SkySports','Sky Sports')
		s=s.replace('SKY SPORT ','Sky Sports')
		s=s.replace('SKY SPORTS NEWS','Sky Spts News')
		s=s.replace('EUROSPORT 1 HD','BRITISH EUROSPORT HD')
		s=s.replace('BEIN SPORTS 12','beIN-sports-12hd')
		s=s.replace('BEIN SPORTS 11','beIN-sports-11hd')
		s=s.replace('BEIN SPORTS 10','beIN-sports-10hd')
		s=s.replace('BEIN SPORTS 1','beIN-sports-1hd') 
		s=s.replace('BEIN SPORTS 2','beIN-sports-2hd') 
		s=s.replace('BEIN SPORTS 3','beIN-sports-3hd') 
		s=s.replace('BEIN SPORTS 4','beIN-sports-4hd') 
		s=s.replace('BEIN SPORTS 5','beIN-sports-5hd') 
		s=s.replace('BEIN SPORTS 6','beIN-sports-6hd') 
		s=s.replace('BEIN SPORTS 7','beIN-sports-7hd') 
		s=s.replace('BEIN SPORTS 8','beIN-sports-8hd') 
		s=s.replace('BEIN SPORTS 9','beIN-sports-9hd')
		s=s.replace('WWE','WWE Network HD')
		s=s.replace('NICK JR.TOO','NICK JR TOO')
		s=s.replace('NICKELODEON HD USA','Nickeloadeon US HD')
		s=s.replace('DISNEY JR','Disney Junior')
		s=s.replace('DISNEY JNR','Disney Junior')
		s=s.replace('DISNEY USA','Disney Channel US')
		s=s.replace('DISNEY XD HD USA','Disney XD USA HD')
		s=s.replace('ITV PLUS 1','itv 1 +1')
		s=s.replace('1 1','1 +1')
		s=s.replace('2 1','2 +1')
		s=s.replace('3 1','3 +1')
		s=s.replace('4 1','4 +1')
		s=s.replace('5 1','5 +1')
		s=s.replace("'","")
		s=s.replace('E! 1','E! Entertainment +1')
		s=s.replace('FIVE USA 1','5USA +1')
		s=s.replace('FIVE USA','5USA')
		s=s.replace('FIVE STAR','5 star')
		s=s.replace('FOUR SEVEN','4seven')
		if s not in o and s !='':
		    f.write('\n%s'% (s)) 

	f.close()
	os.remove(tmpFile) 
	grabXml()

def grabXml():
    if not xmlurl == '':
        try:
            data = []
            path = 'name="%s" url="%s"' % (subname, xmlurl)
            if os.path.exists(subData):
                o = open(subData).read().splitlines()
                for line in o:
                    if not line == '':
                        if not line.split('name="')[1].split('" url')[0] == subname:
                            data.append(line)
            data.append(path)
            foundxml = sorted(data)
            f = open(subData, 'w+')
            for item in foundxml:
                f.write('%s\n' % item)
            f.close()
            if not xbmcaddon.Addon(ivue).getSetting('sub.xmltv') == subname or not int(xbmcaddon.Addon(ivue).getSetting('xmltv.type')) == 15:
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Integration[/B][/COLOR]', subname+' channel listings are available for iVue \nwould you like to setup there listings with ivue',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('sub.xmltv.url', xmlurl)
                    xbmcaddon.Addon(ivue).setSetting('sub.xmltv', subname)
                    xbmcaddon.Addon(ivue).setSetting('xmltv.type', '15')
                    xbmcaddon.Addon(ivue).setSetting('xmltv.type_select', 'Sub File')

            else:
                xbmcaddon.Addon(ivue).setSetting('sub.xmltv.url', xmlurl)
        except:
            pass
    grabcats()

def grabcats():
    if not categoryUrl == '':
        try:
            dp.create("iVue","Downloading "+subname+" categories file",'')
            urlrequest.urlretrieve(categoryUrl,categoryFile,lambda nb, bs, fs, url=categoryUrl: _pbhook(nb,bs,fs,url,dp))
            dp.close()
            if not xbmcaddon.Addon(ivue).getSetting('categories.path') == subname:	
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Integration[/B][/COLOR]', subname+' categories are available for iVue \nwould you like to use these',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('categories.path', subname)
        except:
            pass
    grablogos()
	
def grablogos():
    if not logosUrl == '':
        try:
            data = [] 

            path = 'name="%s" logo="%s"' % (subname, logosUrl)
            if os.path.exists(subLogos):
                o = open(subLogos).read().splitlines()
                for line in o:
                    if not line == '':
                        if not line.split('name="')[1].split('" logo')[0] == subname:
                            data.append(line)
            data.append(path)
            foundlogos = sorted(data)
            f = open(subLogos, 'w+')
            for item in foundlogos:
                f.write('%s\n' % item)
            f.close()
   
            if not xbmcaddon.Addon(ivue).getSetting('sub.logos') == subname or not int(xbmcaddon.Addon(ivue).getSetting('logos.source')) == 1:	
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Integration[/B][/COLOR]', subname+' logo packs are available for iVue \nwould you like to use these',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('logos.source', '1')
                    xbmcaddon.Addon(ivue).setSetting('sub.logos', subname)
                    xbmcaddon.Addon(ivue).setSetting('sub.logos.url', logosUrl)
            else:
                xbmcaddon.Addon(ivue).setSetting('sub.logos.url', logosUrl)
        except:
            pass
    dialog.ok('iVue integration', subname+' has been fully integrated into ivue\nPlease restart the guide for changes to take affect')
    return
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*100)/filesize, 100)
		print ('done' +str(percent)+'%')
		dp.update(percent)
	except:
		percent = 100
		dp.update(percent)
	if dp.iscanceled():
		raise Exception("Cancelled")
		dp.close()


#if __name__ == '__main__':
    #if StartCreate():
        #StartCreate()
        #print ('Subscriptions1')
   # else:
       # print ('Subscriptions2')
    #os.remove(transPath(os.path.join(basePath, 'resources', 'subs', sys.argv[0])))