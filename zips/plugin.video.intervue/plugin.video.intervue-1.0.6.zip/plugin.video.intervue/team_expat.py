# -*- coding: utf-8 -*-

# Deleting this file cripples the entire addon

#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
# http://kodi.wiki/view/How-to:Write_Python_Scripts
################################################

import sys,os,json
try: import urllib.request as urlrequest
except: import urllib as urlrequest
try:import urllib.parse
except:pass
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re, xbmcvfs
import shutil
import base64
import time
import datetime
try: transPath = xbmc.translatePath
except: transPath = xbmcvfs.translatePath

addontag = ['plugin.video.teamexpatiptv']
subname       = 'Expat'
addon         = 'plugin.video.intervue'
ADDONID       = addon
ivue          = 'script.ivueguide'
addonPath     = transPath(os.path.join('special://home/addons', addon))
basePath      = transPath(os.path.join('special://profile', 'addon_data', addon))
tmp_File      = os.path.join(basePath, 'tmp.ini')
icon          = transPath(os.path.join('special://home/addons', addon, 'icon.png'))
dbPath        = transPath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog        = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
subData       = transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config', 'Data.txt'))
subLogos       = transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config', 'Logo.txt'))
inipath       = transPath(os.path.join(basePath, 'resources', 'ini'))
inifile = os.path.join(inipath, subname+'.ini')

xmlurl = 'http://rebrand.ly/teapp'
logosUrl = ''
categoryUrl = ''
categoryFile = transPath(os.path.join('special://profile', 'addon_data', addon, 'resources', 'categories', subname+'.ini'))

if not os.path.exists(basePath):
    os.makedirs(basePath)
            
if not os.path.exists(os.path.join(basePath, 'resources')):
    os.makedirs(os.path.join(basePath, 'resources'))

if not os.path.exists(transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config'))):
    os.makedirs(transPath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'config')))
def notify(header,msg,icon_path):
    duration=2000
    xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)

def StartCreate():


    if os.path.exists(inifile):
        os.remove(inifile)
    if not os.path.exists(inipath):
        os.makedirs(inipath)
    path = os.path.join(transPath('special://home/addons'), ivue) 
    path2 = os.path.join(transPath('special://home/addons'), addon)
    if os.path.exists(path) and os.path.exists(path2):
        add_ini()

    return


def add_ini():
	for FoundAddon in addontag:
		if CheckHasThisAddon(FoundAddon):
			notify('generating channels',FoundAddon,os.path.join('special://home/addons', FoundAddon, 'icon.png'))##NOTIFY##
			ParseData(FoundAddon)
def CheckHasThisAddon(FoundAddon):
	if xbmc.getCondVisibility('System.HasAddon(%s)' % FoundAddon) == 1:
		settingsFileCheck = transPath(os.path.join('special://home/userdata/addon_data',FoundAddon,'settings.xml'))
		if os.path.exists(settingsFileCheck):
			return True
	else:
		return False
#

def ParseData(FoundAddon):
	Addoninipath  = inifile
	response = GrabSettingsFrom(FoundAddon)
	result   = response['result'] 
	ChannelsResult = result['files']    
	ExtrasFileToWrite  = open(Addoninipath, 'w')  
	ExtrasFileToWrite.write('[')
	ExtrasFileToWrite.write(FoundAddon)
	ExtrasFileToWrite.write(']')
	ExtrasFileToWrite.write('\n')   
	TheAddonURL = []   
	for channel in ChannelsResult:
		ParsedChannels = channel['label']
		stream  = channel['file']
		ChannelURL  = GetStuff(FoundAddon, ParsedChannels)
		channel = RemoveChanCrap(FoundAddon, ChannelURL)
		FinalChannelString = channel.split('  ')[0] + ' =' + stream#Jules: make correct formating for channel names
		TheAddonURL.append(FinalChannelString.encode('ascii', 'ignore'))
		TheAddonURL.sort()
	for item in TheAddonURL:
	  if not str(item.decode('utf-8')).lstrip().startswith('='):
	    ExtrasFileToWrite.write("%s\n" % str(item.decode('utf-8')))
	ExtrasFileToWrite.close()
	Clean_Names_(Addoninipath,tmp_File)
#
def GrabSettingsFrom(FoundAddon):
	try:quotePlus = urllib.parse
	except:quotePlus = urlrequest
	Addon    =  xbmcaddon.Addon(FoundAddon)
	username =  Addon.getSetting('kasutajanimi')
	password =  Addon.getSetting('salasona')
	BeginningOfPluginString   = 'plugin://' + FoundAddon    
	urlBody     = '/?action=LiveCategory&extra&page&plot&thumbnail=&title=All&url='
	endOfString    =  GetVariables(FoundAddon)
	startOfString  =  BeginningOfPluginString + urlBody + endOfString
	GrabThisUrl = 'username=' + username + '&password=' + password + '&type=get_live_streams&cat_id=0'
	queryURL = BeginningOfPluginString  + '/?action=OoOo&extra&page&plot&thumbnail&title=Live%20TV&url'
	query = startOfString +  quotePlus.quote_plus(GrabThisUrl)
	checkthisurl = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % queryURL)
	checkthisurltoo = ('{"jsonrpc":"2.0", "method":"Files.GetDirectory", "params":{"directory":"%s"}, "id": 1}' % query)
	try:
		#xbmc.executeJSONRPC(checkthisurl)
		response = xbmc.executeJSONRPC(checkthisurltoo)
		content = json.loads(response)
		return content
	except Exception as e:
		#RunSetSetting(e)
		print (e)
		return {'Error' : 'Plugin Error'}
#    
def GetStuff(FoundAddon, RemoveURLGarbage):
	RemoveURLGarbage = RemoveURLGarbage.replace('[COLOR ffffffff]','').replace('COLOR+', '').replace(' [/B]', '').replace('[COLOR white]', '').replace('[/COLOR]', '').replace('[COLOR grey]', '').replace('COLOR+white', '')      
	return RemoveURLGarbage
#    
def RemoveChanCrap(FoundAddon, FoundChannels):
	channel = FoundChannels.rsplit('[/B]', 1)[0].split('[B]', 1)[-1]
	return channel
#       
def GetVariables(FoundAddon):
	Addon    =  xbmcaddon.Addon(FoundAddon) 
	addre_ss =  'http://go.teamexpat.ninja' 
	po_rt =  '80'
	correct_address = addre_ss + ':' + po_rt + '/enigma2.php?'
	return correct_address
	

def Clean_Names_(Clean_Name,tmpFile):
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    orig=open(tmpFile).read()	
    f=open(Clean_Name,'a')
    f.write(orig)

    r=open(tmpFile).read().splitlines()
    o=open(Clean_Name).read().splitlines()
    for s in r:

	    s=s.replace('QA: ','')
	    s=s.replace('RU: ','')
	    s=s.replace('PT: ','')
	    s=s.replace('AR:','')
	    s=s.replace('EN: ','')
	    s=s.replace('FR: ','')
	    s=s.replace('IE: ','')
	    s=s.replace('UK: ','')
	    s=s.replace('US: ','')
	    s=s.replace('CA: ','')
	    s=s.replace('Nat Geo (','National Geographic Channel HD (')
	    s=s.replace('Investigation Discovery','ID')
	    s=s.replace('Discovery SD','Discovery Channel HD')
	    s=s.replace('Discovery Home & Health','Discovery Home and Health')
	    s=s.replace('Sky Movies','Sky Cinema')
	    s=s.replace('Sky Cinema Sci-Fi','Sky Cinema Sci-Fi and Horror')
	    s=s.replace('Sky Sports News','Sky Spts News')
	    s=s.replace('Sky Sports The Open','Sky Sports Golf')
	    s=s.replace('beINSport 12','beIN-sports-12hd')
	    s=s.replace('beINSport 11','beIN-sports-11hd')
	    s=s.replace('beINSport 10','beIN-sports-10hd')
	    s=s.replace('beINSport 1','beIN-sports-1hd') 
	    s=s.replace('beINSport 2','beIN-sports-2hd') 
	    s=s.replace('beINSport 3','beIN-sports-3hd') 
	    s=s.replace('beINSport 4','beIN-sports-4hd') 
	    s=s.replace('beINSport 5','beIN-sports-5hd') 
	    s=s.replace('beINSport 6','beIN-sports-6hd') 
	    s=s.replace('beINSport 7','beIN-sports-7hd') 
	    s=s.replace('beINSport 8','beIN-sports-8hd') 
	    s=s.replace('beINSport 9','beIN-sports-9hd')
	    s=s.replace('WWE Network','WWE Network HD')
	    s=s.replace(': ','')
	    if s not in o:
		    if not s.startswith('='):
		        f.write('\n%s'% (s)) 

    f.close()
    os.remove(tmpFile) 
    grabXml()
def grabXml():
    if not xmlurl == '':
        try:
            data = []
            path = 'name="%s" url="%s"' % (subname, xmlurl)
            if os.path.exists(subData):
                o = open(subData).read().splitlines()
                for line in o:
                    if not line == '':
                        if not line.split('name="')[1].split('" url')[0] == subname:
                            data.append(line)
            data.append(path)
            foundxml = sorted(data)
            f = open(subData, 'w+')
            for item in foundxml:
                f.write('%s\n' % item)
            f.close()
            if not xbmcaddon.Addon(ivue).getSetting('sub.xmltv') == subname or not int(xbmcaddon.Addon(ivue).getSetting('xmltv.type')) == 15:
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Intergration[/B][/COLOR]', subname+' channel listings are available for iVue ', 'would you like to setup there listings with ivue',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('sub.xmltv.url', xmlurl)
                    xbmcaddon.Addon(ivue).setSetting('sub.xmltv', subname)
                    xbmcaddon.Addon(ivue).setSetting('xmltv.type', '15')
                    xbmcaddon.Addon(ivue).setSetting('xmltv.type_select', 'Sub File')

            else:
                xbmcaddon.Addon(ivue).setSetting('sub.xmltv.url', xmlurl)
        except:
            pass
    grabcats()

def grabcats():
    if not categoryUrl == '':
        try:
            dp.create("iVue","Downloading "+subname+" categories file",'')
            urlrequest.urlretrieve(categoryUrl,categoryFile,lambda nb, bs, fs, url=categoryUrl: _pbhook(nb,bs,fs,url,dp))
            dp.close()
            if not xbmcaddon.Addon(ivue).getSetting('categories.path') == subname:	
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Intergration[/B][/COLOR]', subname+' categories are available for iVue ', 'would you like to use these',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('categories.path', subname)
        except:
            pass
    grablogos()
	
def grablogos():
    if not logosUrl == '':
        try:
            data = [] 

            path = 'name="%s" logo="%s"' % (subname, logosUrl)
            if os.path.exists(subLogos):
                o = open(subLogos).read().splitlines()
                for line in o:
                    if not line == '':
                        if not line.split('name="')[1].split('" logo')[0] == subname:
                            data.append(line)
            data.append(path)
            foundlogos = sorted(data)
            f = open(subLogos, 'w+')
            for item in foundlogos:
                f.write('%s\n' % item)
            f.close()
   
            if not xbmcaddon.Addon(ivue).getSetting('sub.logos') == subname or not int(xbmcaddon.Addon(ivue).getSetting('logos.source')) == 1:	
                yes_pressed = dialog.yesno('[COLOR ffff7e14][B]IVUE Intergration[/B][/COLOR]', subname+' logo packs are available for iVue ', 'would you like to use these',nolabel='no',yeslabel='yes')
                if yes_pressed:
                    xbmcaddon.Addon(ivue).setSetting('logos.source', '1')
                    xbmcaddon.Addon(ivue).setSetting('sub.logos', subname)
                    xbmcaddon.Addon(ivue).setSetting('sub.logos.url', logosUrl)
            else:
                xbmcaddon.Addon(ivue).setSetting('sub.logos.url', logosUrl)
        except:
            pass
    dialog.ok('iVue integration', subname+' has been fully integrated into ivue\nPlease restart the guide for changes to take affect')
    return
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*100)/filesize, 100)
		print ('done' +str(percent)+'%')
		dp.update(percent)
	except:
		percent = 100
		dp.update(percent)
	if dp.iscanceled():
		raise Exception("Cancelled")
		dp.close()

if __name__ == '__main__':
	if StartCreate():
		StartCreate()
		print ('Subscriptions1')
	else:
		print ('Subscriptions2')
	os.remove(transPath(os.path.join(basePath, 'resources', 'subs', sys.argv[0])))