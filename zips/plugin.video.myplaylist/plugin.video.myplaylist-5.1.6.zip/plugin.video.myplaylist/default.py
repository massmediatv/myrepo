############# Imports #################
from resources.plugins.daddy import*
from resources.plugins.streamed import*
from resources.plugins.reddit import*
from resources.plugins.maxone import*
from resources.plugins.watchwrestling import*
from resources.plugins.l1l1 import*
from resources.utils import jsunpack
from resources.utils.plugintools import*
from resources.utils.dom_parse import*

import itertools
redd = 'reddit'
dadd = 'daddy'
dp = xbmcgui.DialogProgress()
inputaddons = ['inputstream.adaptive', 'inputstream.ffmpegdirect', 'inputstream.rtmp', 'script.module.inputstreamhelper']
sysaddon = sys.argv[0]
    
############# Lists #################
def userLists(url=None):
    
    found = 0
    content = getContent(url)
    content = six.ensure_str(content)
    
    try:
        xmlLists = re.findall('<dir>.*?</dir>',content, re.MULTILINE | re.DOTALL)
        if len(xmlLists) < 1:
            raise Exception()
    except: 
        xmlLists = re.findall('<item>.*?</item>',content, re.MULTILINE | re.DOTALL)
    if url == mainXml: 
        cm = []
        #cm.append(('MaxOne', 'max_sched()'))
        addDir('Channels','daddy',24,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)
        addDir('Sports','reddit',29,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)

    for item in xmlLists:
        try:
	        title,links,thumb,fanart,description  = compile(item) 
	        
	        if len(links) >1:
	            addDir(title,str(links),3,thumb,fanart, description,extra='', isFolder= False)
	        
	        elif links[0].endswith('dl=1') or links[0].endswith('.xml'):
	            if not any(x in six.ensure_str(title) for x in ['Live Sports', 'Fight Replays']):
	                addDir(title,links[0],1,thumb,fanart, description, extra='', isFolder= True)
	        else:
	            addDir(title,links[0],2,thumb,fanart, description, extra='', isFolder= False)
	
	        found += 1
	
        except Exception as e:
	        continue
            
    #if url == mainXml: 
        #addDir('Tools','',13,icon,xbmcaddon.Addon().getAddonInfo("fanart"), 'Install needed addons for live streams', extra='', isFolder= True)        



def chanLists():
     addDir('Daddy HD','daddy',30,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)
     #addDir('Sports Streamed','',16,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), 'Boxing',extra='', isFolder= True)
     addDir('Web Scraper','reddit',4,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)



def sportsLists(url=None):

    addDir('Football','',7,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='Soccer', isFolder= True)
    addDir('Boxing','https://boxingstreamlinks.com/',8,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), 'Boxing',extra='', isFolder= True)
    addDir('UFC','https://mmastreamlinks.to/',8,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), 'MMA',extra='', isFolder= True)





def tools():
    #if addonid.getSetting('chanlist') == 'false':
        #status = '[COLOR red]Disabled'
    #else:
        #status = '[COLOR lime]Enabled'
    #addDir('[B]Split Live Channel Lists - '+status+'[/B]','',18,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
    for id in inputaddons:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % id):
            installed = '[COLOR red]Not Installed[/COLOR]'
            addDir('[B]'+id+' - '+installed+'[/B]',id,15,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
        else:
            installed = '[COLOR lime]Installed[/COLOR]'
            addDir('[B]'+id+' - '+installed+'[/B]',id,7777,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)



        
############# Multi Links #################



    

def getUrls(name, url, iconimage=None):
    urls = eval(url)
    found = 0
    links = []
    for link in urls:
        found += 1
        item = xbmcgui.ListItem('Link '+str(found),str(name))
        item.setArt({'icon': iconimage})
        links.append(item)    
    select = dialog.select(str(name), links, useDetails=True)
    if select < 0:
        quit()
    else:
        url = urls[select]
        playUrl(name,url,iconimage)
        
def getServer(name, url, iconimage=None):
    urls = eval(url)
    found = 0
    links = []
    for link in urls:
        item=link[0]
        #item = xbmcgui.ListItem(link[0],str(name))
        #item.setArt({'icon': iconimage})
        links.append(item)    
    select = dialog.contextmenu(links)
    if select < 0:
        quit()
    else:
        url = urls[select][1]
        xbmc.executebuiltin(url)
        #eval(url)
        	

def parse_m3u(url):
    categories = []
    data = getContent(url)
    content = data.rstrip()
    content = six.ensure_str(content)
    match = re.compile(r'group-title="(.*?)"').findall(content)
    [categories.append(c) for c in match if c not in categories]
    if len(categories) > 3:
        for category in categories:
            if category == '': category = "Uncategorized"
            addDir(category,url,5,'','', '', '', isFolder= True)
    else:
        match = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)').findall(content)
        for other,channel_name,stream_url in match:
            
            if 'tvg-logo' in other:
                thumbnail = re.compile(r'tvg-logo="(.*?)"').findall(other)[0]

            else:
                thumbnail = ''
            addDir(channel_name,stream_url.replace('\n', ' ').replace('\r', ''),2,thumbnail,'fanart', 'description', '', isFolder= False)
    	
        
def parse_m3uCat(name, url):
    categories = []
    data = getContent(url)
    content = data.rstrip()
    match = re.compile(r'#EXTINF:(.*?)group-title="%s".*?,(.*?)[\n\r]+([^\n]+)' % name).findall(content)
    for other, channel_name,stream_url in match:
        stream_url = stream_url
        if 'tvg-logo' in other:
            thumbnail = re.compile(r'tvg-logo="(.*?)"').findall(other)[0]

        else:
            thumbnail = ''
    	
        addDir(channel_name,stream_url.replace('\n', ' ').replace('\r', ''),2,thumbnail, '', '', isFolder= False)


params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
action=None
extra=None

try: url=urllib.unquote_plus(params["url"])
except: pass

try: name=urllib.unquote_plus(params["name"])
except: pass

try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

try: mode=int(params["mode"])
except: pass

try: fanart=urllib.unquote_plus(params["fanart"])
except: pass

try: description=urllib.unquote_plus(params["description"])
except: pass

try: action=urllib.unquote_plus(params["action"])
except: pass

try: name=urllib.unquote_plus(params["extra"])
except: pass

try: page=urllib.unquote_plus(params["page"])
except: pass



if mode == None:
    for id in inputaddons:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % id) and addonid.getSetting(id) !='missing':
            try:
                xbmc.executebuiltin("InstallAddon(%s)" % id, wait=True)
            
                xbmcaddon.Addon('{}'.format(id))
                addonid.setSetting(id, '')
            except:
                addonid.setSetting(id, 'missing')
            #continue
    userLists(mainXml)
	
elif mode==1: userLists(url)

elif mode==2: playUrl(name, url, iconimage)

elif mode==3: getUrls(name, url, iconimage)

elif mode==4: sportsLists(url) #GetBoxing() #daddy() # parse_m3u(url)

elif mode==5: parse_m3uCat(name, url)

elif mode==7: football()

elif mode==8: boxing(url, description)

elif mode==12: search_links(url, name, description) # parse_m3u(url)

elif mode==13: tools()

elif mode==14: daddy_sched(name, description)

elif mode==15: install_addon(url)

elif mode==16: streamed_sport()

elif mode==17: 
    for id in inputaddons:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % id) and addonid.getSetting(id) !='missing':
            try:
                xbmc.executebuiltin("InstallAddon(%s)" % id, wait=True)
            
                xbmcaddon.Addon('{}'.format(id))
                addonid.setSetting(id, '')
            except:
                addonid.setSetting(id, 'missing')
            #continue
    chanLists()
    
elif mode==18: daddy_league(description)


elif mode==21: football2(url)

elif mode==22: ListLinks2(name,url,iconimage)

elif mode==23: daddylinks(name, url)

elif mode==24: daddy()

elif mode==25: max_sched()

elif mode==26: l1l1_sched()

elif mode == 28: ukentlinks(name, url)

elif mode==29: chanLists()

elif mode==30: daddy_events()
elif mode==114: getServer(name, url, iconimage)
xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)