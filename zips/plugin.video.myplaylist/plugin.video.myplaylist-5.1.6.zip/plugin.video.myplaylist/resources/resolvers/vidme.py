from resources.utils import plugintools 
import re,six,json,xbmcgui,resolveurl
def vidsrc(link):
    sources = []
    try:
        r = plugintools.getContent(link, referer='https://v2.vidsrc.me')
        r = six.ensure_str(r)
        rhash = re.findall('data-hash="(.+?)"><div id="name">(.+?)</div>', r)
        rhash = getUrls(rhash)
        rhash = six.ensure_str(rhash)
        rurl = 'https://source.vidsrc.me/source/%s' % rhash
        reurl = plugintools.getContent(rurl, 'https://v2.vidsrc.me')
        reurl = six.ensure_str(reurl)
        vidurl = re.findall("src: '(.+?)'", reurl)[0]
        vidurl = 'https:' + vidurl if vidurl.startswith('//') else vidurl
        srccontent,srcurl = plugintools.getContent(vidurl, 'https://v2.vidsrc.me', 'redirect')
        srccontent = six.ensure_str(srccontent)
        
        if 'vidsrc.stream/pro' in srcurl:
            path = re.findall('var path = "(\/\/.*?)"',srccontent,re.DOTALL)[0]
            path = 'https:' + path if path.startswith('/') else path
            contentx = plugintools.getContent(path, referer='https://vidsrc.stream/')
            stream_url = re.findall('loadSource\("([^"]+)"',srccontent,re.DOTALL)[0]
            stream_url+='|User-Agent=test&Referer=https://vidsrc.stream/'
            
        elif 'vidsrc.xyz/v/' in srcurl:
            data = {'r': 'https://v2.vidsrc.me/', 'd': 'vidsrc.xyz'}
            id = srcurl.split('/v/')[-1]
            response = plugintools.getContent('https://vidsrc.xyz/api/source/'+id, referer=srcurl, data=data)
            response = json.loads(response)
            qualities = response.get("data", None)
            ab=max(qualities,key=lambda items:int(items["label"].replace('p','')))  
            stream_url = ab.get('file', None)+'|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0&Referer=https://vidsrc.xyz/@resolved@'
        else:
            if resolveurl.HostedMediaFile(srcurl).valid_url(): 
                stream_url = resolveurl.HostedMediaFile(srcurl).resolve()

        return stream_url
    except Exception as e:
        return 
        
def getUrls(url, iconimage=None):
    urls = url
    found = 0
    links = []
    for link,name in urls:
        found += 1
        item = xbmcgui.ListItem(str(name))
        item.setArt({'icon': iconimage})
        links.append(item)    
    select = plugintools.dialog.select('Servers', links)
    if select < 0:
        return
    else:
        url = urls[select][0]
        return url