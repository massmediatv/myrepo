import re, requests, base64, xbmcgui, time, html, xbmc, xbmcvfs, os, xbmcaddon
try: import urllib.parse as urllib
except: import urllib
import json
from resources.utils import jsunpack,hunter
from resources.utils.dom_parse import *
from resources.resolvers import wrestling
from resources.utils import resolve_check as check_again
import resolveurl
try: from urllib.parse import urljoin, unquote_plus, quote_plus, quote, unquote, urlencode, urlparse, parse_qsl
except: from urlparse import urljoin, unquote_plus, quote_plus, quote, unquote, urlencode, urlparse, parse_qsl
dialog =  xbmcgui.Dialog()

#try:transPath = xbmc.translatePath
#except:transPath = xbmcvfs.translatePath
#myAddon = xbmcaddon.Addon().getAddonInfo("id")
#addonid = xbmcaddon.Addon(myAddon) 
#runpath = transPath(addonid.getAddonInfo('Path'))
#testFile2 = os.path.join(runpath, 'test2.txt')
#myfile2 = open(testFile2, 'a+')





def getAuthUrl(embed):
    scode = re.findall(r"const sCode = '(.+?)'", embed)[0]
    ts = re.findall(r"const expireTs = (.+?);", embed)[0]
    unique_id = re.findall(r"const unqiueId = '(.+?)'", embed)[0]
    return "https://key.seckeyserv.me/?stream=%s&scode=%s&expires=%s" % (unique_id, scode, ts)



def weakspell(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('url:\s*"([^"]*)', page_data)[0]
        h = re.findall('data:\s\{\s*"([^"]*)', page_data)[0]
        i = re.findall('var vidgstream = "([^"]*)', page_data)[0]
        t = re.findall('gethlsUrl\(vidgstream,\s([^,]*)', page_data)[0]
        e = re.findall('gethlsUrl\(vidgstream,(?:[^,]*),\s([^\)]*)', page_data)[0]
        hat = w + '?' + h + '=' + i + '&serverid=' + t + '&cid=' + e
        the = requests.get(hat).text
        crew = re.findall('{"rawUrl":"([^"]*)', the)[0]
    except: pass
    try:
        s = re.findall('(?s)iframe frameborder.*?src="([^"]*)', page_data)[0]
        p = requests.get(s).text
        w = re.findall('url:\s*"([^"]*)', p)[0]
        h = re.findall('data:\s\{"([^"]*)', p)[0]
        i = re.findall('var vidgstream = "([^"]*)', p)[0]
        hat = w + '?' + h + '=' + i
        the = requests.get(hat).text
        crew = re.findall('{"rawUrl":"([^"]*)', the)[0]
    except: pass
    made = crew.replace('\\', '')
    return made + '?&connection=keepalive' + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36&Referer=' + url

#link  
def crackstreams(url):
    try:
       
        page_data = requests.get(url).text
        t = re.findall('(?s)<iframe(?:.*?src)="([^"]*)', page_data)[0]
        x = requests.get(t).text
        w = re.findall('(?s)<iframe(?:.*?src)="([^"]*)', x)[0]   
        u = requests.get(w).text
    except: pass
    try:
        s = re.findall('atob\(["|\']([^"|\']*)', u)[0]
        s = base64.b64decode(s).decode('utf-8')
    except: pass
    try:
        s = re.findall('(?s)Player.*?(?:source|src|file):\s*[\'"]([^\'"]+)', u)[0]
    except: pass
    return s + '|user-agent=iPad&referer=' + url

def csis(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        #h = url + w
        i = requests.get(w).text
    except: pass
    try:
        e = re.findall('atob\(["|\']([^"|\']*)', i)[0]; e = base64.b64decode(e).decode('utf-8')
    except: pass
    try:
        e = re.findall('var PLAYBACK_URL = \'([^\']*)', i)[0]
    except: pass
    return e + '|User-Agent=Mozilla/5.0&Referer=' + w

#link  
def hesgoal(url):
    try:
       
        page_data = requests.get(url).text
        t = re.findall('(?s)<iframe(?:.*?src)="([^"]*)', page_data)[0]
        u = requests.get(t).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', u)[0]
        return x + '|user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=https://fordems.biz/'
    except:
        return
#link
def givemereddit(url):
    try:
       
        u = requests.get(url).text 
        headers = {'Referer': 'https://olacast.live/', 'User-Agent': 'Mozilla/5.0','Accept':'*/*','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-US,en;q=0.5','Connection':'keep-alive','Origin':'https://olacast.live','Host':'webdi.openhd.lol','Sec-Fetch-Dest':'empty','Sec-Fetch-Mode':'cors','Sec-Fetch-Site':'cross-site','TE':'trailers'}
        #r = re.findall('(?s)iframe frameborder=0 height=100% width=100% src="([^"]*)', u)[0]
        #r = re.findall('(?s)<iframe class.*?src="([^"]*)', u)[0]
        #w = requests.get(r).text
        #x = re.findall('source:\s*\'([^\']*)', w)[0]
        #return x + '|User-Agent=Mozilla/5.0&Referer=' + r
        if 'iframe' in  u:
            w = re.findall('(?s)iframe class="embed-responsive-item" src="([^"]*)', u)[0]
            h = requests.get(w, headers={"Referer": w, "User-Agent": 'Mozilla/5.0'}).text
            i = re.compile(r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^\)]*)').findall(h)[0]
            t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
            e = re.findall('source:\s*\'([^\']*)',t)[0]
            e = e.replace('\\','')
            return e + '|User-Agent=Mozilla/5.0&Referer=' + w
        else:
            i = re.compile(r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^\)]*)').findall(u)[0]
            t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
            e = re.findall('(?:source|src|file)(?:\:|=)\s*[\'"]([^\'"]+)',t)[0]
            return e + '|User-Agent=Mozilla/5.0&Referer=' + url
        #w = re.findall('(?s)<iframe class.*?src="([^"]*)', u)[0]
        #h = requests.get(w, headers={"Referer": w, "User-Agent": 'Mozilla/5.0'}).text
        #i = re.compile(r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^\)]*)').findall(h)[0]
        #t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), i[5])
        #e = re.findall('<iframe src=.*?id=([^\\\]*)',t)[0]
        #return 'https://webdi.openhd.lol/cdn/' + e + '/tracks-v1a1/mono.m3u8'+'|{0}'.format(urlencode(headers))
    except:
        return

#link
def givememma(url):
    try:
       
        u = requests.get(url).text 
        r = re.findall('(?s)<iframe class.*?src="([^"]*)', u)[0]
        w = requests.get(r).text
        x = re.findall(' source: \'([^\']*)', w)[0]
        return x + '|User-Agent=Mozilla/5.0&Referer=' + r
    except:
        return
#link
def buff(url):
    try:
       
        page_data = requests.get(url, headers={'user-agent':'Mozilla/5.0'}).text
        reg = re.findall('(?s)<iframe(?:.*?src)="([^"]*)', page_data)[0]
        page = requests.get(reg, headers={'user-agent':'Mozilla/5.0','referer':url}).text
        find = re.findall('source: atob\(\'([^\']*)', page)[0]
        find = base64.b64decode(find).decode('utf-8')
        return find + '|user-agent=Mozilla/5.0&referer=' + reg
    except:
        return

#list:url and title
def boxingfightsvideos(url):
    try:
       
        u = requests.get(url).text
        e = re.findall('(?s)<iframe(?:.*?src="([^"]*))', u)
        e = [(i,i.split('//')[-1].split('/')[0]) for i in e]
        e = [(i[0].replace('http:','').replace('https:','').replace('//','https://'),'[COLOR dodgerblue]Source: [/COLOR]'+i[1].replace('www.','').replace('.com','')) for i in e]
        return e
    except:
        return

def topstreams(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('var hlsurl=\'([^\']*)', page_data)[0]
        h = re.findall('var server=\'([^\']*)', page_data)[0]
        i = re.findall('var hlsurl=\'(?:[^\']*)\'(?:[^\']*)\'([^\']*)', page_data)[0]
        t = re.findall('var key= \'([^\']*)', page_data)[0]
        e = re.findall('var hlsurl=\'(?:[^\']*)\'(?:[^\']*)\'(?:[^\']*)\'(?:[^\']*)\'([^\']*)', page_data)[0]
        return w + h + i + t + e
    except:
        return

def topstreamsnfl(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('\}\s*var hlsurl=\'([^\']*)', page_data)[0]
        h = re.findall('-1\';\s*var server=\'([^\']*)', page_data)[0]
        i = re.findall('}\s*var hlsurl=\'(?:[^\']*)\'(?:[^\']*)\'([^\']*)', page_data)[0]
        t = re.findall('(?s)var safety=.*?y= \'([^\']*)', page_data)[0]
        e = re.findall('\}\s*var hlsurl=\'(?:[^\']*)\'(?:[^\']*)\'(?:[^\']*)\'(?:[^\']*)\'([^\']*)', page_data)[0]
        return w + h + i + t + e
    except:
        return

def ripple(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('(?s)"><iframe.*?src="([^"]*)', page_data)[0]
        t = requests.get(s).text
        r = re.findall('source: \'([^\']*)', t)[0]
        r = r.replace('png','m3u8')
        if 'http' not in r:
            r = 'http://cdn.runid.xyz/' + r
        return r + '|Referer=' + s
        #return 'http://cdn.runid.xyz/' + r + '|Referer=' + s
    except:
        return

def streameast(url):
    try:
       
        page_data = requests.get(url).text
        t = re.findall('(?s)<iframe(?:.*?src)="([^"]*)', page_data)[0]
        u = requests.get(t).text
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', u)[0]
        return w + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=' + url
    except:
        return

def skuanet(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('<source src="([^"]*)', page_data)[0]
        return r + '?&connection=keepalive' + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:107.0) Gecko/20100101 Firefox/107.0&referer=' + url
    except:
        return

def hdstreams(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('<iframe f.*?(?:source|src|file)=\s*[\'"]([^\'"]+)', page_data)[0]
        u = requests.get(r).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', u)[0]
        return x + '|user-agent=iPad&referer=' + r
    except:
        return

def tvnba(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '|user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=' + url
    except:
        return

def tvnfl(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('atob\(["|\']([^"|\']*)', page_data)[0]
        r = base64.b64decode(r).decode('utf-8')
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=' + url 
    except:
        return

def tvncaaf(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)atob\("([^"]*)', page_data)[0]
        r = base64.b64decode(r).decode('utf-8')
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=http://123tvsports.com/category/ncaaf-streams/' 
    except:
        return

def tvnhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        #nhl_auth = "|Cookie=Authorization=" + token
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        r = re.findall('source:\s*"([^"]*)', page_data)[0]
        if 'master_wired60' not in r:
            return r + '|Referer=http://bestsolaris.com/'
        else :
             r = r.replace('master_wired60','5600K/5600_slide')
             return r + nhl_auth
    except:
        return

def tvmma(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)atob\("([^"]*)', page_data)[0]
        r = base64.b64decode(r).decode('utf-8')
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=http://123tvsports.com/category/mma-streams/' 
    except:
        return

def tvboxing(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)atob\("([^"]*)', page_data)[0]
        r = base64.b64decode(r).decode('utf-8')
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=http://123tvsports.com/category/boxing-streams/' 
    except:
        return

def tvf1(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)atob\("([^"]*)', page_data)[0]
        r = base64.b64decode(r).decode('utf-8')
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&Referer=http://123tvsports.com/category/f1-streams/' 
    except:
        return

def yss(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe frameborder=0 height=100% width=100% src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('\}\s(?:.*?var)(?:[^\']*)\'([^\']*)', h)[0]
        t = base64.b64decode(i).decode('utf-8')
        if t.startswith('/'): t = 'http://yoursports.stream' + t
        return t + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0&Referer=' + w
    except:
        return

def ssnhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        #the = re.findall('<iframe sandbox.*?src="([^"]*)', page_data)[0]
        #crew = client.request(the)
        #white = re.findall('(?s)var sou.*?"([^"]*)', crew)[0]
        white = re.findall('(?s)var sou.*?"([^"]*)', page_data)[0]
        white = white.replace('master_wired60','5600K/5600_slide')
        return white + nhl_auth
    except:
        return

def ssnba(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        s = requests.get(r).text
        white = re.findall('(?s)source:\s\'([^\']*)', s)[0]
        return white + '|user-agent=iPad&Referer=' + r
    except:
        return

def everysportsnhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        nhl_auth = "|Cookie=Authorization=" + token
        r = re.findall('source: \'([^\']*)', page_data)[0]
        r = r.replace('master_wired60','5600K/5600_slide')
        return r + nhl_auth
    except:
        return

def everysportsmlb(url):
    try:
       
        page_data = requests.get(url).text
        token = requests.get('http://172.105.26.201/mlbs.txt').text
        r = re.findall('source: \'([^\']*)', page_data)[0]
        r = r.replace('master_wired60','5600K/5600_slide')
        return r + '|User-Agent=iPad&Authorization=' + token
    except:
        return

def volokitnhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        #nhl_auth = "|Cookie=Authorization=" + token
        r = re.findall('{source:"([^"]*)', page_data)[0]
        return r + nhl_auth
    except:
        return

def volokitmlb(url):
    try:
       
        page_data = requests.get(url).text
        token = requests.get('http://172.105.26.201/mlmlbs.txt').text
        r = re.findall('{source:"([^"]*)', page_data)[0]
        r = r.replace('master_desktop_complete','5600K/5600_slide_gdfp')
        return r + '|User-Agent=iPad&Authorization=' + token
    except:
        return

def volokitnfl(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('volokit-feed" src="([^"]*)', page_data)[0]
        s = 'http://volokit.com' + s
        u = requests.get(s).text
        r = re.findall('{source:"([^"]*)', u)[0]
        return r
    except:
        return

def playoffnhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        #nhl_auth = "|Cookie=Authorization=" + token
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        r = re.findall('(?s)= "https:\/\/([^"]*)', page_data)[0]
        r = r.replace('hlslive','https://hlslive')
        return r + nhl_auth
    except:
        return

def playoffnfl(url):
    try:
       
        page_data = requests.get(url).text
        iframe_source_url = re.findall("embed-responsive-item\" src='([^']*)", page_data)[0]
        iframe_data = requests.get(iframe_source_url).text
        pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
        zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
        pid = re.findall("pid = ([0-9])", iframe_data)[0]
        edm = re.findall('edm = "([^"]*)', iframe_data)[0]
        embed_script_url = re.findall('<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
        url="https://"+edm+"/sd0embed?v=" + zmid
        embed_source_data = requests.post(url, headers={"Origin": "https://embedstream.me", "Referer": "https://embedstream.me/", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"}).text
        i = re.compile(r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)').findall(embed_source_data)[0]
        t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
        m3u8 = re.findall('const vdoUrl = \'([^\']*)',t)[0]
        m3u8 = base64.b64decode(m3u8).decode("UTF-8")
        unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
        scode = re.findall(r'sCode = \'([^\']*)', t)[0]
        ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
        # Unnessary call for now 
        key = 'https://key.seckeyserv.me/?stream=' + unique_id + '&scode=' + scode + '&expires=' + ts
        authUrl = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0', 'Origin': 'https://www.nolive.me','Referer': 'https://www.nolive.me/sd0embed'}
        return m3u8 + '|{0}'.format(urlencode(authUrl))
    except:
        return

def seventwenty(url):
    try:
       
        page_data = requests.get(url).text
        iframe_source_url = re.findall('(?s)<iframe.*?rc="([^"]*)', page_data)[0]
        iframe_data = requests.get(iframe_source_url).text
        pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
        zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
        pid = re.findall("pid = ([0-9])", iframe_data)[0]
        edm = re.findall('edm = "([^"]*)', iframe_data)[0]
        embed_script_url = re.findall('<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
        url="https://"+edm+"/sd0embed?v=" + zmid
        embed_source_data = requests.post(url, headers={"Origin": "https://embedstream.me", "Referer": "https://embedstream.me/", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"}).text
        i = re.compile(r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)').findall(embed_source_data)[0]
        t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
        m3u8 = re.findall('const vdoUrl = \'([^\']*)',t)[0]
        m3u8 = base64.b64decode(m3u8).decode("UTF-8")
        unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
        scode = re.findall(r'sCode = \'([^\']*)', t)[0]
        ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
        # Unnessary call for now 
        #key = 'https://key.seckeyserv.me/?stream=' + unique_id + '&scode=' + scode + '&expires=' + ts
        authUrl = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0', 'Origin': 'https://www.nolive.me','Referer': 'https://www.nolive.me/sd0embed'}
        return m3u8 + '|{0}'.format(urlencode(authUrl))
    except:
        return
            
def watchkobestreams(url):
    try:
       
        page_data = requests.get(url,headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0' }).text
        iframe_source_url = re.findall('(?s)<iframe.*?rc="([^"]*)', page_data)[0]
        embed_r = requests.get(iframe_source_url,headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0' }).text
        embed_stream = re.findall('(?s)<iframe.*?rc="([^"]*)', embed_r)[0]
        iframe_data = requests.get(embed_stream).text
        pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
        zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
        pid = re.findall("pid = ([0-9])", iframe_data)[0]
        edm = re.findall('edm = "([^"]*)', iframe_data)[0]
        embed_script_url = re.findall('<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
        url="https://"+edm+"/sd0embed?v=" + zmid
        embed_source_data = requests.post(url, headers={"Origin": "https://embedstream.me", "Referer": "https://embedstream.me/", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"}).text
        i = re.compile(r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)').findall(embed_source_data)[0]
        t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
        m3u8 = re.findall('const vdoUrl = \'([^\']*)',t)[0]
        m3u8 = base64.b64decode(m3u8).decode("UTF-8")
        unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
        scode = re.findall(r'sCode = \'([^\']*)', t)[0]
        ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
        # Unnessary call for now 
        #key = 'https://key.seckeyserv.me/?stream=' + unique_id + '&scode=' + scode + '&expires=' + ts
        authUrl = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0', 'Origin': 'https://www.nolive.me','Referer': 'https://www.nolive.me/sd0embed'}
        return m3u8 + '|{0}'.format(urlencode(authUrl))
    except:
        return

def myustv(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('atob\(["|\']([^"|\']*)', page_data)[0]; r = base64.b64decode(r).decode('utf-8')
        return r + '|user-agent=iPad&Referer=' + url
    except:
        return

def livenhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        #nhl_auth = "|Cookie=Authorization=" + token
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        x = re.findall('(?s)<iframe(?:.*?c=)\'([^\']*)', page_data)[0]
        w = requests.get(x).text
        r = re.findall('var source = "([^"]*)', w)[0]
        r = r.replace('master_wired60','5600K/5600_slide')
        return r + nhl_auth
    except:
        return

def sportsbay(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('(?s)<iframe(?:.*?c=)\'([^\']*)', page_data)[0]
        w = requests.get(x).text
        r = re.findall('var source = {   \'hls\':\'([^\']*)', w)[0]
        return r + '|User-Agent=Mozilla/5.0&Referer=' + x
    except:
        return

def tennislive(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('(?s)<iframe.*?src=\'([^\']*)', page_data)[0]
        w = requests.get(x).text
        r = re.findall('Player\({\s*source:\s*\'([^\']*)', w)[0]
        return r + '|User-Agent=Mozilla/5.0&Referer=' + x
    except:
        return

def sports24nhl(url):
    try:
       
        page_data = requests.get(url).text
        #token = client.request('http://continuum.watch/Crew/nhl.txt')
        #nhl_auth = "|Cookie=Authorization=" + token
        nhl_auth = "|Cookie=Authorization=" + 'eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjY3NzM0NTYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTY3MzgwOTkxMywidHlwZSI6IlVzZXIiLCJpYXQiOjE2NDIyNzM5MTMsInVzZXJpZCI6ImY0NDcwNTAyLTJkYWEtNDgzMS1iOWVhLTgyZTY0NDFmNTkzOS0zMTctYmQ2MGJjZjI2YTQ4MTQ4YjFkODljNmVlZTUyYTNiOWM5MjllYzc3YiIsInZlcnNpb24iOiJ2MS4wIiwicGNfbWF4X3JhdGluZ190diI6IiIsImVtYWlsIjoiYmc2NjE1QGdtYWlsLmNvbSJ9.ameiawUY4YxQLGF0e9-kLlsug8czcjAdiahGr3HwwvM;mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b073ba26d541692f17953320772ffa0eba4a000575f2095c9e94fc3511dd9de884109f1bf8cfec7db5a90f25f525537e58c0ce68b4587f94c28ed01bab51ec0d355a0f0e95595434fd39b0cbadd368136229ae6956fc8020bd342f2a1fa6ceb7eded883b08c967a21391862ffb6ee48c0924a87b874c97e4d5e53cb37a67b62203dc916d2530a5c13c30ebf76b13b0e6996f06345bf6a88a97f29c493c5c7768311023d1e8c3cad5130ada0e56ee4e27df63f7c3e1104e87a13b1e4fba3d4d1e1130d27aba5cd34fdd812913520d8811972d05ec90e8b8b6343419cb74e063a3e05cef3272bc8d9c44c46cfb641a306ca78b4c677809171a36b9202630d72f01e502dfb1a5487d2ea586499a718679782a65e6a6800f77eea39fc6d3c544d512160eab8689984ae7084b23c6adbcda40c35bcc813ee744594de07fabae81c127628907e5412dabc14bf05a658aaa90000a78295a1f0f14e644073a757ab7f0092d95c2a5e37a65d8f18eea0f7690a6d3ba27b1a28e421cb51ae7a213c3e2ce6372b135d4059fd9372929fbd9243c93b28b8767a28480cbdc0c360706b508ea9b94de85fea1a410ecac6031bbe31220910200eb587c82fb2c0e6cb23af904a4080b4037e246c9ec1d9daaebacb17d684bc726;192051129147321142019199714547152015'
        u = re.findall('(?s)id="playframe">(?:.*?src)="([^"]*)', page_data)[0]
        b = 'https:'+u
        b = b.replace(' ', '%20')
        x = requests.get(b).text
        l = re.findall('(?s)xurl\s=\satob\(\'([^\']*)', x)[0]; l = base64.b64decode(l).decode('utf-8')
        return l + nhl_auth
    except:
        return

def sports24nba(url):
    try:
       
        page_data = requests.get(url).text
        l = re.findall('(?s)src = "(.*?)"', page_data)[0]; l = base64.b64decode(l).decode('utf-8')
        l = l.replace('https:','')
        l = l.replace('//','https://')
        if l.startswith('/'): l = 'https://sports24.club' + l
        return l + '|user-agent=iPad&referer=https://sports24.club/nba'
    except:
        return

def sports24ncaab(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe id.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        l = re.findall('atob\(["|\']([^"|\']*)', h)[0]; l = base64.b64decode(l).decode('utf-8')
        l = l.replace('https:','')
        l = l.replace('//','https://')
        if l.startswith('/'): l = 'https://sports24.club' + l
        return l + '|user-agent=iPad&referer=' + w
    except:
        return

def sports24nfl(url):
    try:
       
        page_data = requests.get(url).text
        l = re.findall('(?s)src = "(.*?)"', page_data)[0]; l = base64.b64decode(l).decode('utf-8')
        l = l.replace('https:','')
        l = l.replace('//','https://')
        if l.startswith('/'): l = 'https://sports24.club' + l
        return l + '|user-agent=iPad&referer=https://sports24.club/nfl'
    except:
        return

def sports24f1(url):
    try:
       
        page_data = requests.get(url).text
        l = re.findall('(?s)src = "(.*?)"', page_data)[0]; l = base64.b64decode(l).decode('utf-8')
        l = l.replace('https:','')
        l = l.replace('//','https://')
        if l.startswith('/'): l = 'https://sports24.club' + l
        return l + '|user-agent=iPad&referer=https://sports24.club/fl'
    except:
        return

def sports24ncaa(url):
    try:
       
        page_data = requests.get(url).text
        l = re.findall('var xurl = atob\(\'([^\']*)', page_data)[0]; l = base64.b64decode(l).decode('utf-8')
        l = l.replace('https:','')
        l = l.replace('//','https://')
        if l.startswith('/'): l = 'https://sports24.club' + l
        return l + '|user-agent=iPad&referer=https://sports24.club/ncaa'
    except:
        return

def markky(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '|User-Agent=iPad&Referer=' + url
    except:
        return

def nbahdreplay(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('iframe(?:.*?src=")([^"]*)',page_data)[0]
        r = r.replace('//','https://')
        return r
    except:
        return
        
def cric(url):
    try:
       
        p = requests.get(url).text
        r0 = re.findall('(?s)<tr><td>(?:[^<]*)<\/td><td><a href="([^"]*)',p)[0]
        p1 = requests.get(r0).text
        r1 = re.findall('<iframe src="([^"]*)',p1)[0];r1 = r1.replace('//','http://')
        p2 = requests.get(r1).text
        r2 = re.findall('fid="([^"]*)',p2)[0];r3 = re.findall('v_width=([^\;]*)',p2)[0];r4 = re.findall('v_height=([^\;]*)',p2)[0]
        embed = 'http://www.freecast123.com/cricsp.php?player=desktop&live='+r2+'&vw='+r3+'&vh='+r4
        u = requests.get(embed, headers={'user-agent':'iPad','referer':r1}).text
        u = u.replace('\/','/');u = u.replace('",','');u = u.replace('"','');u = u.replace('//','http://')
        r = re.findall('return\(\[([^\]]*)',u)[0]; x = re.findall('\[(hlsendtime.*?)\]',u)[0]; z = re.findall('>(ash.*?)<',u)[0]
        return r + x + z
    except:
        return

def tubby(url):
    try:
       
        u = requests.get(url).text
        r = re.findall('<iframe src="([^"]*)',u)[0]
        u2 = requests.get(r).text
        r2 = re.findall('videoLink = \'([^\']*)',u2)[0]
        return r2
    except:
        return

def btstream(url):
    try:
       
        u = requests.get(url).text
        r = re.findall('(?s)<div class=\'player(?:[^"]*)"(?:[^"]*)"(?:[^"]*)"(?:[^"]*)"(?:[^"]*)"([^"]*)', u)[0]
        t = requests.get(r).text
        s = re.findall('atob\(["|\']([^"|\']*)', t)[0]
        s = base64.b64decode(s).decode('utf-8')
        return s + '|referer=' + r
    except:
        return
        
def jumbo(url):
    try:
       
        u = requests.get(url).content
        r = re.findall('<iframe src="([^"]*)',u)[0]
        u2 = requests.get(r).content
        r2 = re.findall('<iframe src="([^"]*)',u2)[0]
        page = requests.get(r2, headers={'user-agent':'iPad','referer':r}).content
        find = re.findall('(?s)<script>eval(.+?)<\/sc', page)[0]
        unpack = jsunpack.unpack(find)
        r3 = re.findall('source:"([^"]*)',unpack)[0]
        return r3
    except:
        return

def mazy(url):
    try:
       
        page_data = requests.get(url).text
        i = re.findall('source = \'([^\']*)', page_data)[0]
        return i + '|Referer=' + url
    except:
        return

def helena(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('source: "([^"]*)', page_data)[0]
        return w + '|referer=' + url
    except:
        return

def ice(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('iframe src="([^"]*)', page_data)[0]
        r = requests.get(s).text
        t = re.findall('replace\("([^"]*)', r)[0]
        w = re.findall('(?s)\)\;.*?var url = "([^"]*)', r)[0]
        return t + w + '|user-agent=ipad&referer=' + s
    except:
        return

def papahd(url):
    try:
       
        page_data = requests.get(url).text
        r1 = re.findall('(?s)<iframe src="([^"]*)',page_data)[0]
        u2 = requests.get(r1).text
        #r2 = re.findall('<iframe src="([^"]*)',u2)[0]
        #page = requests.get(r2, headers={'user-agent':'iPad','referer':r1}).text
        #find = re.findall('eval\(function(.+?m3u8.+)', page)[0]
        #unpack = jsunpack.unpack(find)
        result = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', u2)[0]
        return result + '|user-agent=iPad&amp;referer=' + r1
    except:
        return


def fightpass(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return x + '|user-agent=Mozilla/5.0&referer=' + url
    except:
        return

def solaris(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '|user-agent=Mozilla/5.0&referer=' + url
    except:
        return

def sportnews(url):
    try:
       
        page_data = requests.get(url).text
        l = re.findall('atob\(\'([^\']*)', page_data)[0]
        l = base64.b64decode(l).decode('utf-8')
        return l + '|user-agent=Mozilla/5.0&referer=' + url
    except:
        return

def beast(url):
    try:
       
        page_data = requests.get(url).text
        white = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        hat = requests.get(white).text
        items = re.findall('=\s*(\[[^;]+)', hat)[0]
        items = re.findall('"(.+?)"', items)
        subitem = int(re.findall('atob.+?-\s*(\d+)', hat)[0])
        srp = ''
        for item in items:
            srp += chr(int(re.sub(r'[^\d]', '', item.decode('base64'))) - subitem)
        link = re.findall('source: \'([^\']*)', srp)[0]
        return link + '|user-agent=ipad&referer=' + url
    except:
        return

def elixx(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)iframe-wrapper">\s*<iframe src="([^"]*)',page_data)[0]
        h = 'http://elixx.xyz' + w
        i = requests.get(h).text
        t = re.findall('<iframe src="([^"]*)',i)[0]
        white = 'https:' + t
        e = requests.get(white, headers={'user-agent':'iPad','referer':t}).text
        z = re.findall('(?s)<iframe.*?src="([^"]*)',e)[0]
        hat = 'https:' + z
        pink = requests.get(hat, headers={'user-agent':'iPad','referer':t}).text
        find = re.findall('eval\(function(.+?m3u8.+)', pink)[0]
        the = jsunpack.unpack(find)
        crew= re.findall('src=\s*"([^"]*)',the)[0]
        return crew + '|User-Agent=iPad&referer=' + h
    except:
        return

def worldstreams(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)',page_data)[0]
        h = requests.get(w).text
        i = re.findall('<iframe src="([^"]*)',h)[0]
        e = requests.get(i, headers={'user-agent':'iPad','referer':i}).text
        crew = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', e)[0]
        #hat = re.findall('eval\(function(.+?m3u8.+)', e)[0]
        #the = jsunpack.unpack(hat)
        #crew= re.findall('source\s*:\s*"([^"]*)',the)[0]
        return crew + '|user-agent=ipad&referer=' + i
    except:
        return

def crackacnfl(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)',page_data)[0]
        h = requests.get(w).text
        i = re.findall('(?s)<iframe.*?src="([^"]*)',h)[0]
        t = requests.get(i).text
        e = re.findall('source: "([^"]*)', t)[0]
        return e + '|user-agent=ipad&referer=' + i
    except:
        return

def bslivenba(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)play">.*?src="([^"]*)',page_data)[0]
        h = requests.get(w).text
        i = re.findall('(?s)<iframe allowfullscreen.*?src="([^"]*)',h)[0]
        t = requests.get(i).text
        e = re.findall('atob\(\'([^\']*)', t)[0]
        hat = base64.b64decode(e).decode('utf-8')
        return hat + '|user-agent=ipad&referer=' + i
    except:
        return
        
def sportea(url):
    try:
       
        page_data = requests.get(url).text
        
        w = re.findall('<iframe.*?src="(.*?)"',page_data)[0]
        if w.startswith('//'):
            w = 'https:'+w
        
        h = requests.get(w).text

        
        i = re.findall('<iframe.*?src="(.*?)"',h)
        if len(i) > 0:
            if i[0].startswith('//'):
                i = 'https:'+i[0]
            else:
                i = i[0]

            t = requests.get(i).text
        else:
            i = w
            t = h
        e = re.findall('atob\(\'([^\']*)', t)[0]
        
        hat = base64.b64decode(e).decode('utf-8')
        
        if hat.startswith('//'):
            hat = 'http:'+hat

        return hat + '|user-agent=ipad&referer=' + i
    except:
        return
        
def espnv2(url):
    try:
       
        page_data = requests.get(url).text
        
        w = re.findall("<iframe.*?src='(.*?)'",page_data)[0]
        if w.startswith('//'):
            w = 'https:'+w
        
        h = requests.get(w).text

        
        e = re.findall('window.atob\(\'([^\']*)', h)[0]
        
        hat = base64.b64decode(e).decode('utf-8')
        
        if hat.startswith('//'):
            hat = 'http:'+hat
        

        return hat + '|user-agent=ipad&referer=' + w
    except:
        return
        
        
def hdenjoy(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        if w.startswith('//'):
            w = 'https:'+w
        
        h = requests.get(w).text
        #dialog.textviewer('hd',str(h))
        i = re.findall('window.atob\(\'([^\']*)', h)[0]
        t = base64.b64decode(i).decode('utf-8')
        if t.startswith('//'):
            t = 'https:'+t
        #dialog.textviewer('hd',str(t))
        return t + '|User-agent=ipad&Referer=' + w
    except:
        return
        
        
def gameshdlive(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        if w.startswith('..'):
            w = 'https://gameshdlive.net'+w.replace('..','')
        
        h = requests.get(w).text
        t = re.findall('(?s)source:\s\'([^\']*)', h)[0]
        #t = base64.b64decode(i).decode('utf-8')
        if t.startswith('//'):
            t = 'https:'+t
        return t + '|User-agent=ipad&Referer=' + w
    except:
        return

def csnetmma(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('(?s)<iframe.*?src="([^"]*)', h)[0]
        t = requests.get(i).text
        e = re.findall('(?s)source:\s\'([^\']*)', t)[0]
        return e + '|user-agent=ipad&referer=' + i
    except:
        return

def csnetnfl(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        s = requests.get(r).text
        w = re.findall('(?s)source:\s"([^"]*)', s)[0]
        return w + '|user-agent=ipad&referer=http://thecrackstreams.net/nflstreams.php'
    except:
        return

def nflup(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('var chunks_link = \'([^\']*)', page_data)[0]
        s = re.findall('var channelName = "([^"]*)', page_data)[0]
        return r + s + '_playlist.m3u8'
    except:
        return

def nflsportz(url):
    try:
       
        page_data = requests.get(url).text
        #r = re.findall('atob\(["|\']([^"|\']*)', page_data)[0]
        #r = base64.b64decode(r).decode('utf-8')
        #return r + '|user-agent=Mozilla/5.0&referer=' + url
        src = re.findall('iframe.*?src="([^"]*)', page_data)[0]
        src = 'http:' + src if src.startswith('//') else src
        fu = requests.get(src, headers={'user-agent':'iPad','referer':url}).text
        hat = re.findall('eval\(function(.+?m3u8.+)', fu)[0]
        the = jsunpack.unpack(hat)
        crew= re.findall('var\s*src="([^"]*)',the)[0]
        return crew + '|user-agent=Mozilla/5.0&referer=' + url
    except:
        return

def blacktienfl(url):
    try:
       
        page_data = requests.get(url).text
        #r = re.findall('<iframe src="([^"]*)', page_data)[0]
        r = re.findall('<iframe id="stream.*?src="([^"]*)', page_data)[0]  
        u = requests.get(r).text
        q = re.findall('(?:source|src|file):\s*[\'"]([^\'"]*)',u)[0]
        return q + '|user-agent=ipad&referer=' + r
    except:
        return

def blacktienba(url):
    try:
       
        page_data = requests.get(url).text
        if 'm3u8' in page_data:
            link = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
            return link + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36&Origin=http://blacktiesports.net&referer=' + r                  
        elif 'php' in page_data:
            r = re.findall('(?s)<iframe id="stream.*?src="([^"]*)', page_data)[0]
            u = requests.get(r).text
            items = re.findall('<script>var.*?=\s*(\[[^;]+)', u)[0]
            items = re.findall('"(.+?)"', items)
            subitem = int(re.findall('\(atob.+?-\s*(\d+)', u)[0])
            srp = ''
            for item in items:
                srp += chr(int(re.sub(r'[^\d]', '', base64.b64decode(item).decode('utf-8'))) - subitem)
            #link = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', srp)[0]
            link = re.findall('atob\(\'([^\']*)', srp)[0]
            link = link.replace(' ','')
            link = base64.b64decode(link).decode('utf-8')
            return link + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36&Origin=http://blacktiesports.net&referer=' + r
        else:
            items = re.findall('<script>var.*?=\s*(\[[^;]+)', page_data)[0]
            items = re.findall('"(.+?)"', items)
            subitem = int(re.findall('\(atob.+?-\s*(\d+)', page_data)[0])
            srp = ''
            for item in items:
                srp += chr(int(re.sub(r'[^\d]', '', base64.b64decode(item).decode('utf-8'))) - subitem)
            link = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', srp)[0]
            link = link.replace(' ','')
            return link + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36&Origin=http://blacktiesports.net&referer=' + url
    except:
        return

def ufckhabib(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('atob\(\'([^\']*)', page_data)[0]
        s = base64.b64decode(w).decode('utf-8')
        return s + '|user-agent=ipad&referer=' + url
    except:
        return

def daddylive(url):
    try:
        #src = url.split('stream-')[1].split('.')[0]
        
        UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
        hea={
            'Referer':'https://dlhd.so/',
            'user-agent':UA,
        }
    
        resp=requests.post(url, headers=hea).text
        #page_data = requests.get(url).text
        src = re.findall('iframe src="([^"]*)', resp)[0]
        
        hea={
            'Referer':url,
             'user-agent':UA,
        }
        resp2=requests.post(src, headers=hea, timeout=10).text
        links = re.findall('(https?:\/\/[^\s]+\.m3u8)', resp2)
        
        if links:
        #link = links[0]
            link = str(links[0])

        #decoded_link = base64.b64decode(link).decode('utf-8')

            parsed_url = urlparse(src)
            referer_base = f"{parsed_url.scheme}://{parsed_url.netloc}"
            referer = quote_plus(referer_base)
            user_agent = quote_plus(UA)
            #dialog.ok('daddy',str(link))

        #final_link = f'{decoded_link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={user_agent}'
            final_link =  f'{link}|Referer={referer}/&Origin={referer}&Keep-Alive=true&User-Agent={user_agent}'
            #dialog.ok('da',str(final_link))
            return final_link
        
        
       # stream_url=stream
      #  hdr='Referer='+quote(str(src))+'&User-Agent='+UA
       # return stream+'|'+hdr #'https://webudi.onlinewebtv.lol/lb/premium' + src + '/index.m3u8?&connection=keepalive|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36&Referer=https://streamservicehd.click/'
        
    except Exception as e:
        
        return 'None'

def ovostreams(url):
    try:
       
        page_data = requests.get(url).text
        hat = re.findall('(?s)<iframe.*?src="([^"]*)',page_data)[0]
        h = requests.get(hat).text
        s = re.findall('var\s(?:source|src|file)\s*=\s*[\'"]([^\'"]+)',h)[0]
        return s + '|User-Agent=Mozilla/5.0&Referer=' + hat
    except:
        return

def tvtwofour(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)baseUrl(?:.*?l = )"([^"]*)', page_data)[0]
        x = re.findall('(?s)channelName = "([^"]*)', page_data)[0]
        s = re.findall('(?s)var link=(?:.*?")([^"]*)', page_data)[0]
        return r + x + s + '|Referer=http://tv247.us/all-channels/'
    except:
        return

def csbiz(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '?&connection=keepalive' + '|Referer=' + url 
    except:
        return

def csto(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('source: "([^"]*)', h)[0]
        return i + '|user-agent=Mozilla/5.0&referer=' + w
    except:
        return

def techno(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('iframe\ssrc="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('source:.*?\'.*?\'.*?\'([^\']*)', h)[0]
        return 'https://reels2watch.com/hls/' + i + '|referer=' + url
    except:
        return

def ranionba(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        i = requests.get(w).text
        t = re.findall('(?s)https:\/\/hls.([^\']*)', i)[0]
        e = 'https://hls.' + t
        return e + '|referer=' + w
    except:
        return

def ranionfl(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        w = 'https:' + w if w.startswith('//') else w
        i = requests.get(w, headers={"User-Agent": 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36',"Orgin": 'http://rainostreams.com', "Referer": 'http://rainostreams.com/'}).text
        z = re.findall('(?:source|file|m3u8URL)=\s*[\'"]([^\'"]+)', i)[0]
        z = 'https:' + z if z.startswith('//') else z
        return z + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A108.0)%20Gecko%2F20100101%20Firefox%2F108.0&Referer=' + w
    except:
        return

def raniofifa(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        w = 'https:' + w if w.startswith('//') else w
        i = requests.get(w).text
        this = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', i)[0]
        this = 'https:' + this if w.startswith('//') else this
        return this + '|referer=' + w
    except:
        return

def recipemam(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('<source src=\s*[\'"]([^\'"]+)', page_data)[0]
        return s
    except:
        return

def catchy(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('50><iframe src="([^"]*)', page_data)[0]
        w = requests.get(r).text
        x = re.findall('(?s)Setup the player.*?(?:source|src|file):\s*[\'"]([^\'"]+)', w)[0]
        return x + '|User-agent=ipad&Referer=' + r
    except:
        return

def sportsurge(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('<iframe.*?src="([^"]*)', h)[0]
        t = requests.get(i).text
        e = re.findall('<iframe.*?src="([^"]*)', t)[0]
        hat = requests.get(e).text
        saysfuckoff = re.findall('source:\s*\'([^\']*)', hat)[0]
        return saysfuckoff + '|Referer=' + e
    except:
        return

def ace(url):
    try:
       
        page_data = requests.get(url).text
        #w = re.findall(' source: \'([^\']*)', page_data)[0]
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return w + '|User-agent=ipad&Referer=' + url
    except:
        return

def nbatvsport(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('atob\(["|\']([^"|\']*)', h)[0]
        t = base64.b64decode(i).decode('utf-8')
        return t + '|User-agent=ipad&Referer=' + w
    except:
        return

def geekingeek(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        hat = 'http://www.geekingeek.com/' + w
        h = requests.get(hat).text
        i = re.findall('atob\(["|\']([^"|\']*)', h)[0]
        t = base64.b64decode(i).decode('utf-8')
        return t + '|User-agent=ipad&Referer=' + w
    except:
        return

def rightcombat(url):
    try:
       
        page_data = requests.get(url).text
        if 'm3u8' in page_data:
            s = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
            return s + '|user-agent=Mozilla/5.0&referer=' + url
        else:
            s = re.findall('iframe.*?src="([^"]*)', page_data)[0]
            q = requests.get(s).text
            src = re.findall('<iframe src="([^"]*)', q)[0]
            src = 'http:' + src if src.startswith('//') else src
            fu = requests.get(src, headers={'user-agent':'iPad','referer':url}).text
            hat = re.findall('eval\(function(.+?m3u8.+)', fu)[0]
            the = jsunpack.unpack(hat)
            crew= re.findall('var\s*src="([^"]*)',the)[0]
            return crew + '|user-agent=ipad&referer=' + url
    except:
        return

def poscitech(url):
    try:
       
        page_data = requests.get(url).text
        #src= re.findall('<iframe.*?src="([^"]*)',page_data)[0]
        #fu = requests.get(src, headers={'user-agent':'iPad','referer':src}).text
        #hat= re.findall('<iframe.*?src="([^"]*)',fu)[0]
        #white = requests.get(hat, headers={'user-agent':'iPad','referer':src}).text
        #crew= re.findall('source\s*:\s*"([^"]*)',white)[0]
        #return crew + '|user-agent=ipad&referer=' + hat
        src = re.findall('iframe.*?src="([^"]*)', page_data)[0]
        src = 'http:' + src if src.startswith('//') else src
        fu = requests.get(src, headers={'user-agent':'Mozilla/5.0','referer':url}).text
        hat = re.findall('iframe src.*?id=([^"]*)', fu)[0]
        return 'https://newtest.webtv1.lol/ddyx2/premium' + hat + '/playlist.m3u8|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A108.0)%20Gecko%2F20100101%20Firefox%2F108.0&Referer=https%3A%2F%2Feplayer.click%2F'
    except:
        return
        

def iwizwig(url):
    try:
       
        page_data = requests.get(url).text
        src= re.findall('<iframe.*?src="([^"]*)',page_data)[0]
        fu = requests.get(src, headers={'user-agent':'iPad','referer':src}).text
        hat= re.findall('<iframe.*?src="([^"]*)',fu)[0]
        white = requests.get(hat, headers={'user-agent':'iPad','referer':src}).text
        #find = re.findall('eval\(function(.+?m3u8.+)', white)[0]
        #the = jsunpack.unpack(find)
        #crew= re.findall('source\s*:\s*"([^"]*)',the)[0]
        crew= re.findall('source\s*:\s*"([^"]*)',white)[0]
        return crew + '|user-agent=ipad&referer=http://iwizwig.online'
    except:
        return

def cricworld(url):
    try:
       
        page_data = requests.get(url).text
        i = re.findall('atob\(["|\']([^"|\']*)', page_data)[0]
        t = base64.b64decode(i).decode('utf-8')
        return t + '|user-agent=ipad&referer=' + url
    except:
        return

def darwinstreams(url):
    try:
       
        page_data = requests.get(url).text
        i = re.findall('source: \'([^\']*)', page_data)[0]
        return i + '|user-agent=ipad&referer=' + url
    except:
        return

def freetvsports(url):
    try:
       
        page_data = requests.get(url).text
        src= re.findall('<iframe.*?src="([^"]*)',page_data)[0]
        fu = requests.get(src, headers={'user-agent':'iPad','referer':src}).text
        hat= re.findall('<iframe.*?src="([^"]*)',fu)[0]
        white = requests.get(hat, headers={'user-agent':'iPad','referer':src}).text
        crew= re.findall('source\s*:\s*"([^"]*)',white)[0]
        return crew + '|user-agent=ipad&referer=' + src
    except:
        return

def capp(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return w + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&referer=' + url
    except:
        return

def ptwopstreams(url):
    try:
       
        u = requests.get(url).text
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','Orgin': 'http://xestreams.com', 'Referer': 'http://ftdryiwv.mmazones.com:8080/'}
        r = re.findall('<iframe class.*?src="([^"]*)',u)[0]
        r = 'http:' + r if r.startswith('//') else r
        page_data = requests.get(r, headers=headers).text
        z = re.findall('window.atob\("([^"]*)',page_data)[0]
        z = base64.b64decode(z).decode('utf-8')
        z = 'http:' + z if z.startswith('//') else z
        return z + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&Orgin=https://xestreams.com&Referer=http://ftdryiwv.mmazones.com:8080/'
        #if 'm3u8' in page_data:
           # z = re.findall('source:\s*\'([^\']*)')
           # return z + '|User-Agent=iPad&Referer=' + r
        #else:
           # pattern = r'''return\(\[([^\]]+).+?\+\s*([^\.]+).+?\+.+?"([^"]+)'''.format(page_data)
          #  par1, par2, par3 = re.findall(pattern, page_data, re.DOTALL)[0]
          #  part2 = re.findall(r'var\s*{0}\s*=\s*\["([^]]+)'.format(par2), page_data)[0].replace('","', '')[:-1]
          #  part3 = re.findall('id={0}>([^<]+)'.format(par3), page_data)[0]
          #  part1 = par1.replace('","','').replace('\\/', '/')[1:-1]
          #  part1 = 'http:' + part1 if part1.startswith('//') else part1
          #  return part1 + part2 + part3 + '|User-Agent=iPad&Referer=' + r
       # if 'window.atob' in page_data:
           # z = re.findall('window.atob\("([^"]*)',page_data)[0]
           # z = base64.b64decode(z).decode('utf-8')
            #return z + '|User-Agent=iPad&Referer=' + r
    except:
        return

def sportek(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('" src="([^"]*)', page_data)[0]
        h = 'http://sportek.xyz' + w
        i = requests.get(h).text
        t = re.findall('src : "([^"]*)', i)[0]
        return t + '|Referer=' + h
    except:
        return

def bong(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        h = 'http://bongstreams.com' + w
        i = requests.get(h).text
        t = re.findall('src : "([^"]*)', i)[0]
        return t + '|Referer=' + h
    except:
        return

def sporteks(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('(?s)iframe frameborder.*?src="([^"]*)', page_data)[0]
        p = requests.get(s).text
        w = re.findall('url:\s*"([^"]*)', p)[0]
        h = re.findall('data:\s\{"([^"]*)', p)[0]
        i = re.findall('var vidgstream = "([^"]*)', p)[0]
        hat = w + '?' + h + '=' + i
        the = requests.get(hat).text
        crew = re.findall('{"rawUrl":"([^"]*)', the)[0]
        made = crew.replace('\\', '')
        return made + '|Referer=http://wpstream.tv/'
    except:
        return

def pawastreams(url):
    try:
       
        page_data = requests.get(url).text
        

        s =  re.findall('(?s)"><iframe.*?src="([^"]*)', page_data)[0] 
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 'Referer':s}
        r = requests.get(s, headers=headers).text
        #myfile2.write(str(r)+'     found\n')
        x = re.findall('atob\(\'([^\']*)', r)[0]
        t = base64.b64decode(x).decode('utf-8')
        return t + '|user-agent=ipad&referer=' + url
    except:
        return

def supertipz(url):
    try:
       
        page_data = requests.get(url).text
        #src = re.findall('<iframe src="([^"]*)', page_data)[0]
        #src = 'http:' + src if src.startswith('//') else src
        #fu = requests.get(src, headers={'user-agent':'iPad','referer':url}).text
        #hat = re.findall('eval\(function(.+?m3u8.+)', fu)[0]
        #the = jsunpack.unpack(hat)
        #crew= re.findall('var\s*src="([^"]*)',the)[0]
        #return crew + '|user-agent=ipad&referer=' + url
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return w + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&referer=' + url
    except:
        return

def dubsstreamz(url):
    try:
       
        page_data = requests.get(url).text
        if 'm3u8' in page_data:
            t = re.findall('var source = \'([^\']*)', page_data)[0]
            return t + '|user-agent=iPad&referer=' + url
        else :
            r = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
            u = requests.get(r, headers={'user-agent':'iPad','referer':'http://www.dubsstreamz.com'}).text
            x = re.findall('atob\(\'([^\']*)', u)[0]
            t = base64.b64decode(x).decode('utf-8')
            return t + '|user-agent=iPad&referer=' + r
    except:
        return

def summerlivestream(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
        murl=(r);now=int((int(time.time()) + 86400) * 1000)
        source=requests.get(murl,headers={'user-agent':'Mozilla/5.0','referer':'https://sportsbay.org/','accept':'*/*'}).text
        if 'm3u8' in source:
            strurl = re.findall('Clappr.Player[\w\W]*?(?:source|src|file)(?:\s*|):(?:\s*|)[\'"]([^\'"]+)',source)[0]+'|user-agent=ipad&origin=https://freefeds.com&referer=https://freefeds.com/'
            return strurl
        else :     
            teleID=re.findall('embed/(\d+)\.',source)[0]
            r=requests.get('https://teleriumtv.com/streams/%s/%s.json'%(teleID,now),headers={'user-agent':'Mozilla/5.0','referer':'https://teleriumtv.com/embed/%s.html'%teleID,'accept':'*/*'},cookies={'volume':'0'}).json()
            strurl=r.get('url');netloc='https://teleriumtv.com'
            headers={'user-agent': 'Mozilla/5.0','origin':netloc,'referer':'https://teleriumtv.com/embed/%s.html'%teleID}
            if r.get('tokenurl'):
                strurl += requests.get(netloc+r.get('tokenurl'),headers=headers).json()[10][::-1]
            strurl=strurl if strurl.startswith('http') else 'https:'+strurl
            return strurl+'|{0}'.format(urlencode(headers))
    except:
        return
            
def myoplay(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('sources[\w\W]*?(?:source|src|file)(?:\s*|):(?:\s*|)[\'"]([^\'"]+)', page_data)[0]
        return r + '|Referer=' + url
    except:
        return

def sstwentyfour(url):
    try:
       
        page_data = requests.get(url).text
        headers={'user-agent':'Mozilla/5.0','referer':'https://ww.soccer24hd.com','accept':'*/*'}
        r = re.findall('(?s)holder">\s*<iframe.*?src="([^"]*)',page_data)[0]
        s = requests.get(r,headers=headers).text
        t = re.findall('iframe.*?src="([^"]*)',s)[0]
        a = requests.get(t,headers=headers).text
        w = re.findall('iframe.*?src="([^"]*)',a)[0]
        h = requests.get(w,headers=headers).text
        if 'm3u8' in h:
            l = re.findall('source:"([^"]*)', h)[0]
            return l + '|User-Agent=Mozilla/5.0&Referer=' + w
        else :
            l = re.findall('atob\(\'([^\']*)', h)[0]
            l = base64.b64decode(l).decode('utf-8')
        #q = re.findall('iframe.*?src="([^"]*)',h)[0]
        #e = requests.get(q,headers=headers).text
        #find = re.findall('eval\(function(.+?m3u8.+)', e)[0]
        #unpack = jsunpack.unpack(find)
        #i = re.findall('var (?:source|src|file)=\s*[\'"]([^\'"]+)',unpack)[0]
            return l + '|User-Agent=Mozilla/5.0&Referer=' + w
    except:
        return



def thecslive(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('window.atob\(\'([^\']*)',page_data)[0]
        x = base64.b64decode(x).decode('utf-8')
        return x + '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36&Referer=' + url
    except:
        return

def crazystreams(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe allow=.*?src=\'([^\']*)',page_data)[0]
        q = requests.get(r).text
        w = re.findall('url:\s*"([^"]*)', q)[0]
        h = re.findall('data:\s\{"([^"]*)', q)[0]
        i = re.findall('var vidgstream = "([^"]*)', q)[0]
        t = re.findall('gethlsUrl\(vidgstream,\s([^,]*)', q)[0]
        e = re.findall('gethlsUrl\(vidgstream,(?:[^,]*),\s([^\)]*)', q)[0]
        hat = w + '?' + h + '=' + i + '&serverid=' + t + '&cid=' + e
        the = requests.get(hat).text
        crew = re.findall('{"rawUrl":"([^"]*)', the)[0]
        made = crew.replace('\\', '')
        return made + '|Referer=' + url
    except:
        return

def sportsnest(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '|User-Agent=User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.14%3B%20rv%3A99.0)%20Gecko%2F20100101%20Firefox%2F99.0&Referer=' + url
    except:
        return

def onestream(url):
    try:
       
        page_data = requests.get(url).text
        
        #r = re.findall('atob\(["|\']([^"|\']*)', page_data)[0]
        #s = re.findall('cdn\s*=\s*\["([^"]*)', page_data)[0]
        #x = base64.b64decode(r).decode("ascii")
        #x = x.replace(x[x.index("/") + 2:].split(".")[0], s)
        #w = re.findall('url:\s*\'([^\']*)', page_data)[0] + str(round(random.random() * 12))
        #h = 'http://1stream.top' + w
        #hat = requests.get(h, headers={"User-Agent": 'Mozilla/5.0'}).text
        #I = re.findall('source":"([^"]*)', hat)[0]
        #t = base64.b64decode(i).decode("utf-8")
        #return x +'|Referer=' + quote_plus(url)
        #return t +'|Referer=' + quote_plus(url)
        #w = re.findall('url:\s*\'([^\']*)', page_data)[0] + str(random.randint(1,64))
        #token = re.findall('_token": "([^"]*)', page_data)[0]
        #h = 'http://1stream.link' + w
        #hat = requests.post(h, data={"_token": token, "sport": "other"}, headers={"Referer": h, "User-Agent": 'Mozilla/5.0', "X-Requested-With": "XMLHttpRequest"}).json()
        #s = re.findall('"source":"([^"]*)', hat)[0]
        #s = base64.b64decode(s).decode('utf-8')
        #return s +'|Referer=' + quote_plus(url)
        #linkUrlPieces = re.findall('canonical" href="([^:]*):\/\/([^\/]*)\/', page_data)[0]
        #protocol = linkUrlPieces[0]
        #domain = linkUrlPieces[1]
        #linkPayload = re.findall('url: \'([^\']*)\'[\s\S]*eventId: "([^"]*)"[\s\S]*_token": "([^"]*)"[\s\S]*sport: \'([^"]*)\'', page_data)
        #path = linkPayload[0][0]
        #eventId = linkPayload[0][1]
        #token = linkPayload[0][2]
        #sport = linkPayload[0][3]
        #postData = {'eventId': eventId, 'token': token, 'sport': sport}
        #streamPostResponse = requests.post(protocol + '://' + domain + '/' + path + str(random.randint(1,64)),postData).text
        #encryptedStreamUrl = re.findall('"source":"([^"]*)', streamPostResponse)[0]
        t = re.findall('src="(.*?)" allowfullscreen',page_data)[0]
        decryptedStreamUrl = check_again.resolve(t)
        #encryptedStreamUrl = re.findall('source: window.atob\("([^"]*)', page_data)[0]
        #decryptedStreamUrl = base64.b64decode(encryptedStreamUrl).decode('utf-8')
        return decryptedStreamUrl + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A120.0)%20Gecko%2F20100101%20Firefox%2F120.0&Referer=https%3A%2F%2F1stream.eu%2F'
    except:
        return

def toptv(url):
    try:
       
        page_data = requests.get(url, headers={"User-Agent": 'ipad'}).text
        s = re.findall('iframe.*?src="([^"]*)', page_data)[0]
        return s
    except:
        return

def dubznetwork(url):
    try:
       
        u = requests.get(url, headers={"User-Agent": 'ipad'}).text
        s = re.findall('atob\(["|\']([^"|\']*)', u)[0]
        s = base64.b64decode(s).decode('utf-8')
        return s + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&referer=' + url
    except:
        return

def tvsportslive(url):
    try:
       
        page_data = requests.get(url, headers={"User-Agent": 'ipad'}).text
        headers={'user-agent':'Mozilla/5.0','referer':'http://www.tvsportslive.fr','accept':'*/*'}
        q = re.findall('iframe.*?src="([^"]*)',page_data)[0]
        e = requests.get(q,headers=headers).text
        find = re.findall('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))', e)[0]
        unpack = jsunpack.unpack(find)
        link = eval(re.findall(r"var jameiei=(\[.+?\])", unpack)[0])
        hat = "".join([chr(x) for x in link])
        return hat + '|User-Agent=Mozilla/5.0&Referer=' + q
    except:     
        return

def sportsio(url):
    try:
       
        page_data = requests.get(url).text
        r1 = re.findall('(?s)<iframe src="([^"]*)',page_data)[0]
        u2 = requests.get(r1).text
        result = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', u2)[0]
        return result + '|user-agent=iPad&amp;referer=' + r1
    except:
        return

def sixtyfps(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe src="([^"]*)',page_data)[0]
        h = requests.get(w).text
        i = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', h)[0]
        return i + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&referer=' + w
    except:
        return

def sportsguild(url):
    try:
       
        u = requests.get(url).text
        r = re.findall('(?s)<iframe src="([^"]*)', u)[0]
        t = requests.get(r).text
        s = re.findall('atob\(["|\']([^"|\']*)', t)[0]
        s = base64.b64decode(s).decode('utf-8')
        return s + '|user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36&referer=' + r
    except:
        return

def ustvtwentyfourseven(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('iframe src=\'([^\']*)', page_data)[0]
        h = 'https://ustv247.tv' + w
        i = requests.get(h).text
        s = re.findall('var hls_src=\'([^\']*)',i)[0]
        return s + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0&Referer=' + h
    except:
        return
     
def    sportinglive (url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('source\s*src="([^"]*)', page_data)[0]
        return w + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0&Referer=' + url
    except:
        return

def rmeth(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        h = requests.get(w).text
        i = re.findall(r"source\s*:\s+?(?:\"|')(.+?)(?:\"|')", h)[0]
        #i = re.findall('atob\("([^"]*)', h)[0]
        #i = base64.b64decode(i).decode('utf-8')
        return i + '|User-Agent=Mozilla/5.0&Referer=' + url
    except:
        return

def silverspoon(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return w + '|User-Agent=Mozilla/5.0&Referer=' + url
    except:
        return

def volokit2(url):
    try:
       
        page_data = requests.get(url).text
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        h = requests.get(w).text
        i = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', h)[0]
        return i + '|User-Agent=Mozilla/5.0&Referer=' + w
    except:
        return

def maxsport(url):
    try:
       
        page_data = requests.get(url).text
        #s = re.findall('(?s)iframe src="([^"]*)',page_data)[0]
        #t = requests.get(s,headers={"Referer": url, "User-Agent": 'Mozilla/5.0'}).text
        #pattern = r'''return\(\[([^\]]+).+?\+\s*([^\.]+).+?\+.+?"([^"]+)'''.format(t)
        #par1, par2, par3 = re.findall(pattern, t, re.DOTALL)[0]
        #part1 = par1.replace('","','').replace('\\/', '/')[1:-1]
        #part1 = 'http:' + part1 if part1.startswith('//') else part1
        #return part1  + '|User-Agent=iPad&Referer=https://gocast2.com/'
        s = re.findall('(?s)<iframe.*?src=".*?(\d+)',page_data)[0]
        return 'https://webudi.webtv1.lol/lb/premium' + s + '/index.m3u8?&connection=keepalive|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36&Referer=https://streamservicehd.click/'
    except:
        return

def hitstreams(url):
    try:
       
        page_data = requests.get(url).text
        if 'weakstream' in page_data:
            s = re.findall('(?s)iframe frameborder.*?src="([^"]*)', page_data)[0]
            p = requests.get(s).text
            w = re.findall('url:\s*"([^"]*)', p)[0]
            h = re.findall('data:\s\{"([^"]*)', p)[0]
            i = re.findall('var vidgstream = "([^"]*)', p)[0]
            hat = w + '?' + h + '=' + i
            the = requests.get(hat).text
            crew = re.findall('{"rawUrl":"([^"]*)', the)[0]
            made = crew.replace('\\', '')
            return made + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=https%3A%2F%2Fweakstream.org%2F'
        else:
            r = re.findall('fid="([^"]*)', page_data)[0]
            s = 'https://switchcast2.com/embed.php?player=desktop&live=' + r
            t = requests.get(s, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0', "Referer": url}).text
            w = ("".join(eval(re.findall(r"return\((\[.+?\])", t)[0]))).replace("\\", "")
            return w + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + s 
    except:  
        return

def alexsports(url):
    try:
       
        page_data = requests.get(url).text
        e = re.findall('iframe class.*?src="(.*?)"',page_data)[0]
        #
        e = e.replace('//', 'https://')
        s = requests.get(e).text

        t = re.findall('atob\(\'([^\']*)', s)[0]
        
        
        t = base64.b64decode(t).decode('utf-8')
        t = t.replace('//', 'https://')
        return t + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=' + e
    except:
        return
        
        
def s2watch(url):
    try:
       
        page_data = requests.get(url).text
        e = re.findall('iframe class.*?src="(.*?)"',page_data)[0]
        #
        e = 'https://s2watch.link/'+e
        s = requests.get(e).text

        t = re.findall("<iframe.*?src='(.*?)'",s)[0]
        #from resources.utils import plugintools
     #   k = plugintools.getContent(t, referer='https://s2watch.link')
        k = requests.get(t, headers={'User-Agent':'ipad','Referer':'https://s2watch.link'}).text
        #dialog.textviewer('s2',str(k))
        a = re.findall('(?s)source:\'([^\']*)',k)[0]
        #t = re.findall('atob\("(.*?)', k)[0]
        #dialog.textviewer('s2',str(t))
        
        #u = base64.b64decode(t).decode('utf-8')
        #u = u.replace('//', 'https://')
        return a + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=' + t
    except:
        return
        
def epl_web(url):
    try:
       
        page_data = requests.get(url).text
        e = re.findall('iframe class.*?src="(.*?)"',page_data)[0]
        #
        #e = e.replace('//', 'https://')
        s = requests.get(e).text

        t = re.findall('<iframe src="(.*?)"',s)[0]
        k = requests.get(t, headers={'user-agent':'ipad','referer':e}).text
        a = re.findall('(?s)atob\("([^"]*)', k)[0]
        
        a = base64.b64decode(a).decode('utf-8')
        #dialog.textviewer('epl',str(a))
        if a.startswith('//'):
            a = 'https:'+a
        return a + '|user-agent=ipad&referer=' + t
    except:
        return

def metaporky(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('(?s)iframe\sf.*?src="([^"]*)',page_data)[0]
        t = requests.get(s).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', t)[0]
        return r + '|user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=' + url
    except:
        return

def nbagaffer(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return r + '|user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=' + url
    except:
        return

def soccerstreams(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)iframe.*?src="([^"]*)', page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', t)[0]
        return x + '|user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36&referer=https://fordems.biz/'
    except:
        return

def soccersislive(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('\?id=([^"]*)', page_data)[0]
        return 'https://newtest.openhd.lol/ddy4/premium'+ x +'/tracks-v1a1/mono.m3u8' + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A108.0)%20Gecko%2F20100101%20Firefox%2F108.0&Referer=https%3A%2F%2Feplayer.click%2F'
    except:
        return

def basketballvideo(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
        return x
    except:
        return

def nflvideo(url):
    try:
       
        page_data = requests.get(url).text
        x = re.findall('(?s)Full Game Replay.*?<iframe.*?src="([^"]*)', page_data)[0]
        return x
    except:
        return

def nizarstream(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe\ssrc="([^"]*)',page_data)[0]
        s = requests.get(r,headers={'user-agent':'ipad','referer':'http://nizarstream.com/nfl/stream/1172'}).text
        find = re.findall('eval\(function(.+?m3u8.+)', s)[0]
        unpack = jsunpack.unpack(find)
        m3u8 = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)',unpack)[0]
        return m3u8 + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A108.0)%20Gecko%2F20100101%20Firefox%2F108.0&Referer=https%3A%2F%2Fonionplay.live%2F'
    except:
        return
            
def enjoyhd(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('iframe.*?src="([^"]*)', page_data)[0]
        t = requests.get(s).text
        e = re.findall('<iframe.*?src="([^"]*)', t)[0]
        w = requests.get(e).text
        hat = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', w)[0]
        return hat + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A108.0)%20Gecko%2F20100101%20Firefox%2F108.0&Referer=https%3A%2F%2Fenjoyhd.xyz%2F' 
    except:
        return

def youpit(url):
    try:
       
        page_data = requests.get(url).text
        s = re.findall('<iframe\ssrc="([^"]*)', page_data)[0]
        h = requests.get(s, headers={"Referer": s, "User-Agent": 'Mozilla/5.0'}).text
        i = re.compile(r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^\)]*)').findall(h)[0]
        t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
        e = re.findall('source:\s*\'([^\']*)',t)[0]
        return e + '|User-Agent=Mozilla/5.0&Referer=' + s
    except:
        return

def prolive(url):
    try:
       
        page_data = requests.get(url).text
        hat = re.findall('(?s)<iframe.*?src=".*?=(\d+)',page_data)[0]
        return 'https://newtest.webtv1.lol/ddy5/premium' + hat + '/tracks-v1a1/mono.m3u8?&connection=keepalive|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36&Referer=https://olacast.live/'
    except:
        return

def paktech(url):
    try:
       
        page_data = requests.get(url).text
        headers={'Accept':'*/*','Accept-Encoding':'gzip, deflate, br','Accept-Language':'en-US,en;q=0.5','Connection':'keep-alive','Host':'newtest.webtv1.lol','Origin':'https://eplayer.click','Referer':'https://eplayer.click/','Sec-Fetch-Dest':'empty','Sec-Fetch-Mode':'cors','Sec-Fetch-Site':'cross-site','TE':'trailers','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0'}
        white = re.findall('(?s)position": 3.*?".*?".*?".*?".*?"([^"]*)',page_data)[0]
        crew = requests.get(white).text
        hat = re.findall('(?s)<iframe.*?ch(\d+)',crew)[0]
        return 'https://webudi.webtv1.lol/lb/premium' + hat + '/index.m3u8' + '|{0}'.format(urlencode(headers))
    except:
        return

def olympicology(url):
    try:
       
        page_data = requests.get(url).text
        hat = re.findall('(?s)<iframe.*?src="([^"]*)',page_data)[0]
        h = requests.get(hat).text
        s = re.findall('var\s(?:source|src|file)\s*=\s*[\'"]([^\'"]+)',h)[0]
        return s + '|User-Agent=Mozilla/5.0&Referer=' + hat
    except:
        return
            
def enjoyfourk(url):
    try:
       
        page_data = requests.get(url).text
        hat = re.findall('<iframe\s*src="([^"]*)',page_data)[0]
        h = requests.get(hat).text
        whitehat = re.findall('<iframe\s*src="([^"]*)',h)[0]
        s = requests.get(whitehat).text
        crew = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', s)[0]
        return s + '|User-Agent=Mozilla/5.0&Referer=' + s
    except:
        return

def sportsstreamsite(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('iframe sc.*?src="([^"]*)', page_data)[0]
        q = requests.get(r).text
        w = re.findall('iframe\s*.*?src="([^"]*)', q)[0]
        s = 'https://www.sports-stream.site' + w
        e = requests.get(s).text
        u = re.findall('iframe src="([^"]*)', e)[0]
        t = requests.get(u, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0', "Referer": u}).text
        w = ("".join(eval(re.findall(r"return\((\[.+?\])", t)[0]))).replace("\\", "")
        return w + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + u
    except:
        return

def hdrez(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)wrap">\s<iframe.*?src="([^"]*)',page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?s)m3u8URL="([^"]*)',t)[0]
        #x = base64.b64decode(x).decode('utf-8')
        headers = {"Origin": "https://embed4u.xyz","Referer": "https://embed4u.xyz/","User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"}
        return x + '|{0}'.format(urlencode(headers))

    except:
        return

def bingsport(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)iframe\s*src="([^"]*)',page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)',t)[0]
        return x + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + r
    except:
        return

def tvapp(url):
    try:
       
        page_data = requests.get(url).text
        token = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return token + '|User-Agent=Mozilla/5.0&Referer=https://thetvapp.to/'
    except:
        return

def score(url):
    try:
       
        page_data = requests.get(url).text
        token = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
        return token + '|User-Agent=Mozilla/5.0&Referer=' + url
    except:
        return
            
def worldcupglory(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)first-iframe">.*?src="([^"]*)',page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)',t)[0]
        return x + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + r
    except:
        return
            
def headlines(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)first-iframe">.*?src="([^"]*)',page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?s)source = \'([^\']*)',t)[0]
        return x + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + r
    except:
        return
            
def backfirstwo(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe.*?src=\'([^\']*)',page_data)[0]
        t = requests.get(r).text
        x = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)',t)[0]
        return x + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + r
    except:
        return
            
def streambtw(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)',page_data)[0]
        return r + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0&Referer=' + url
    except:
        return
            
def sportsupa(url):
    try:
       
        page_data = requests.get(url).text
        r = re.findall('(?s)<iframe.*?src="([^"]*)',page_data)[0]
        s = requests.get(r).text
        w = re.findall('(?:source|src|file):\s*[\'"]([^\'"]+)', s)[0]
        return w + '|User-Agent=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010.15%3B%20rv%3A120.0)%20Gecko%2F20100101%20Firefox%2F120.0&Referer=https%3A%2F%2Fnflscoop.xyz%2F'
    except:
        return


 ################### l1l1/ 1l1l #######################
l1ua = 'Mozilla/5.0 (iPad; CPU OS 15_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Mobile/15E148 Safari/604.1'

def l1l1(url):
    if '1l1l.to/' in url or 'l1l1.to/' in url: 
        if 'l1l1.' in url:
            referer = 'https://l1l1.to/'
            r = requests.get(url, headers={"Referer": referer}).text
            stream = re.findall(r'<iframe.+?src=(.+?) ', r)[-1]
            stream = stream.replace('"', '').replace("'","")
            stream = 'https:' + stream if stream.startswith('//') else stream
            rr = requests.get(stream, headers={"Referer": referer}).text
            if '<script>eval' in rr:
                from resources.utils import jsunpack
                unpack = re.findall(r'''<script>(eval.+?\{\}\))\)''', rr, re.DOTALL)[0].strip()
                rr = jsunpack.unpack(str(unpack) + ')')
                if '<script>eval' in rr and not '.m3u8?':
                    unpack = re.findall(r'''<script>(eval.+?\{\}\))\)''', rr, re.DOTALL)[0].strip()
                    rr = jsunpack.unpack(str(unpack) + ')')
                else:
                    rr = rr
                if 'player.src({src:' in rr:
                    flink = re.findall(r'''player.src\(\{src:\s*["'](.+?)['"]\,''', rr, re.DOTALL)[0]
                elif 'hlsjsConfig' in rr:
                    flink = re.findall(r'''src=\s*["'](.+?)['"]''', rr, re.DOTALL)[0]
                elif 'new Clappr' in rr:
                    flink = re.findall(r'''source\s*:\s*["'](.+?)['"]\,''', str(rr), re.DOTALL)[0]
                elif 'player.setSrc' in rr:
                    flink = re.findall(r'''player.setSrc\(["'](.+?)['"]\)''', rr, re.DOTALL)[0]
                else:
                    try:
                        flink = re.findall(r'''source:\s*["'](.+?)['"]''', rr, re.DOTALL)[0]
                    except IndexError:
                        ea = re.findall(r'''ajax\(\{url:\s*['"](.+?)['"],''', rr, re.DOTALL)[0]
                        ea = requests.get(ea).text
                        ea = ea.split('=')[1] 
                        flink = re.findall('''videoplayer.src = "(.+?)";''', ea, re.DOTALL)[0]
                        flink = flink.replace('" + ea + "', ea)
                flink += '|Referer={}'.format(quote(stream))
                stream_url = flink
        else:
            referer = 'https://l1l1.to/'
            r = requests.get(url).text

            if 'video.netwrk.ru' in r:
                frame = re.findall(r'<iframe.+?src=(.+?) ', r)[0]
                data = requests.get(frame, headers={"Referer": referer}).text
                link = re.findall(r'''hls:.*['"](http.+?)['"]\,''', data, re.DOTALL)[0]
                stream_url = link + '|Referer=https://video.netwrk.ru.com/&User-Agent=iPad'.format(referer, l1ua)
            else:
                vid = re.findall(r'''fid=['"](.+?)['"]''', r, re.DOTALL)[0]
                host = 'https://vikistream.com/embed2.php?player=desktop&live={}'.format(str(vid))
                data = requests.get(host, headers={"Referer": referer}).text

                try:
                    link = re.findall(r'''return\((\[.+?\])\.join''', data, re.DOTALL)[0]
                except IndexError:
                    link = re.findall(r'''file:.*['"](http.+?)['"]\,''', data, re.DOTALL)[0]


                stream_url = link.replace('[', '').replace(']', '').replace('"', '').replace(',', '').replace('\/', '/')
                stream_url += '|Referer=https://vikistream.com/&User-Agent={}'.format(quote(l1ua))
                
        return stream_url



################### full match #######################
match_user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36"
refdomains = "fullmatchtv.com"

def fullmatch(url):
    r_game = requests.get(url, headers={"Referer": refdomains, "User-Agent": match_user_agent}).text
    if "//ok.ru/videoembed" in r_game:
        embed_url = "https:" + re.compile(r'src="(//ok.ru/videoembed/.+?)"').findall(r_game)[0]
        r_embed = requests.get(embed_url, headers={"User-Agent": match_user_agent}).text
        embed_json = json.loads(html.unescape(re.compile(r'data-options="(.+?)"').findall(r_embed)[0]))
        metadata_json = json.loads(embed_json["flashvars"]["metadata"])
        return metadata_json["hlsManifestUrl"]+'|User-Agent='+ match_user_agent
    return url
        
################### Daily Motion #####################        
maxVideoQuality = '1080'
language = 'en_GB'
MOTION_UA = 'Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36'

def spliturl(elem):
    if elem[0] == "auto":
        return 1
    else:
        return int(elem[0].split("@")[0])

def dailymotion(vid, live=False):
    ff = "off"
    
    headers = {'User-Agent': MOTION_UA,
               'Origin': 'https://www.dailymotion.com',
               'Referer': 'https://www.dailymotion.com/'}
    cookie = {'lang': language,
              'ff': ff}
    r = requests.get("https://www.dailymotion.com/player/metadata/video/{0}".format(vid), headers=headers, cookies=cookie)
    content = r.json()
    if content.get('error') is not None:
        Error = (content['error']['title'])
        xbmcgui.Dialog().notification('Info:', Error, '', 5000, False)
        return
    else:
        cc = content['qualities']
        cc = list(cc.items())
        cc = sorted(cc, key=spliturl, reverse=True)
        m_url = ''
        other_playable_url = []

        for source, json_source in cc:
            source = source.split("@")[0]
            for item in json_source:
                m_url = item.get('url', None)
                xbmc.log("DAILYMOTION - m_url = {0}".format(m_url), xbmc.LOGDEBUG)
                if m_url:
                    if not live:
                        if source == "auto":
                            mbtext = requests.get(m_url, headers=headers).text
                            mb = re.findall('NAME="([^"]+)",PROGRESSIVE-URI="([^"]+)"', mbtext)
                            if checkUrl(mb[-1][1].split('#cell')[0]) is False:
                                mb = re.findall(r'NAME="([^"]+)".+\n([^\n]+)', mbtext)
                            mb = sorted(mb, key=spliturl, reverse=True)
                            for quality, strurl in mb:
                                quality = quality.split("@")[0]
                                if int(quality) <= int(maxVideoQuality):
                                    strurl = '{0}|{1}'.format(strurl.split('#cell')[0], urllib.urlencode(headers))
                                    xbmc.log('Selected URL is: {0}'.format(strurl), xbmc.LOGDEBUG)
                                    return strurl

                        elif int(source) <= int(maxVideoQuality):
                            if 'video' in item.get('type', None):
                                return '{0}|{1}'.format(m_url, urllib.urlencode(headers))

                    else:
                        m_url = m_url.replace('dvr=true&', '')
                        if '.m3u8?sec' in m_url:
                            m_url = m_url.split('?sec=')
                            the_url = '{0}?redirect=0&sec={1}'.format(m_url[0], urllib.quote(m_url[1]))
                            rr = requests.get(the_url, cookies=r.cookies.get_dict(), headers=headers)
                            mb = re.findall('NAME="([^"]+)"\n(.+)', rr.text)
                            mb = sorted(mb, key=spliturl, reverse=True)
                            for quality, strurl in mb:
                                quality = quality.split("@")[0]
                                if int(quality) <= int(maxVideoQuality):
                                    if not strurl.startswith('http'):
                                        strurl1 = re.findall('(.+/)', the_url)[0]
                                        strurl = strurl1 + strurl
                                    strurl = '{0}|{1}'.format(strurl.split('#cell')[0], urllib.urlencode(headers))
                                    xbmc.log('Selected URL is: {0}'.format(strurl), xbmc.LOGDEBUG)
                                    return strurl
                    if type(m_url) is list:
                        m_url = '?sec='.join(m_url)
                    other_playable_url.append(m_url)

        if len(other_playable_url) > 0:  # probably not needed, only for last resort
            for m_url in other_playable_url:
                xbmc.log("DAILYMOTION - other m_url = {0}".format(m_url), xbmc.LOGDEBUG)
                m_url = m_url.replace('dvr=true&', '')
                if '.m3u8?sec' in m_url:
                    rr = requests.get(m_url, cookies=r.cookies.get_dict(), headers=headers)
                    mburl = re.findall('(http.+)', rr.text)[0].split('#cell')[0]
                    if rr.headers.get('set-cookie'):
                        xbmc.log('DAILYMOTION - adding cookie to url', xbmc.LOGDEBUG)
                        strurl = '{0}|Cookie={1}'.format(mburl, rr.headers['set-cookie'])
                    else:
                        mb = requests.get(mburl, headers=headers).text
                        mb = re.findall('NAME="([^"]+)"\n(.+)', mb)
                        mb = sorted(mb, key=spliturl, reverse=True)
                        for quality, strurl in mb:
                            quality = quality.split("@")[0]
                            if int(quality) <= int(maxVideoQuality):
                                if not strurl.startswith('http'):
                                    strurl1 = re.findall('(.+/)', mburl)[0]
                                    strurl = strurl1 + strurl
                                break

                    xbmc.log("DAILYMOTION - Calculated url = {0}".format(strurl), xbmc.LOGDEBUG)
                    return strurl
                    
def checkUrl(url):
    ff = "off"
    xbmc.log('DAILYMOTION - Check url is {0}'.format(url), xbmc.LOGDEBUG)
    headers = {'User-Agent': MOTION_UA,
               'Referer': 'https://www.dailymotion.com/',
               'Origin': 'https://www.dailymotion.com'}
    cookie = {'lang': language,
              'ff': ff}
    r = requests.head(url, headers=headers, cookies=cookie)
    status = r.status_code == 200
    return status
    
    
def wrestlingpro(url):
    try:
        ref=''
        if '|' in url:
            url,ref = url.split('|')
        headers = {'Referer': ref}
        link=''
        if 'premiumplug' in url or 'issuessolution' in url or 'gpllicense' in url:

            html=requests.get(url,headers=headers).text

            iframe = parseDOM(html,'iframe', ret="src")[0]
            iframe = 'https:' + iframe if iframe.startswith('//') else iframe
        else:
            iframe = url
            
        try:
            link = resolveurl.resolve(iframe)
        except:
            if 'dood' in iframe:
                try:
                    link = wrestling.getLink(iframe)
                except:
                    pass
        if 'drop.down' in iframe and not link:
            try:
                link =wrestling.getDropDown(iframe)
            except:
                pass
        elif 'm2list' in iframe and not link:

            try:
                link =wrestling.getm2list(iframe,url)
            except:
                pass
        elif 'sawlive' in iframe and not link:


            try:
                link =wrestling.getsawlive(iframe,url)
            except:
                pass
        return link
    except Exception as e:
        #dialog.ok('wres', str(e))
        return

