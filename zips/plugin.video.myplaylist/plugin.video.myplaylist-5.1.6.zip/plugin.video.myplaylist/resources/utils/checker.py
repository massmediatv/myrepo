from bs4 import BeautifulSoup, Comment
try:import urllib2
except: import urllib.request as urllib2


import requests
import re
import xbmcgui
import six
import itertools

dialog =  xbmcgui.Dialog()
ignore = ['france', ' fr ', 'croatia', 'bulgaria', 'germany', 'canal', ' de ', 'portugal', 'turkey', 'romania', 'italy', ' br ', ' sur ', 'israel', 'poland', 'serbia', ' espa', ' es ']
ignore2 = ['orangesport', 'primasport', 'digisport', 'sport1il', 'sport2il', 'sport3il', 'sport4il', 'sport5il', 'ukraine', 'beinsport1ar', 'beinsport2ar', 'beinsport3ar', 'beinsport4ar', 'canal', 'sport1liveil', 'sport2liveil', 'sport3liveil', 'sport5liveil']
ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'

def red_links(url):
    headers = {'User-Agent': ua , 'Referer' : url}
    pattern = r'''href=['"]([^'"]+)['"]'''
    try:

        link = requests.get(url, headers=headers).text
        link = str(link)
        soup = re.findall('<tbody>(.*?)</tbody>',link,flags=re.DOTALL)

        table = soup[0]
        table = str(table)
        found = re.findall('<th scope="row">.*?<a href="(.*?)".*?class="mb-0 text-sm">(.*?)</span>',table,re.MULTILINE | re.DOTALL)
        found = [[x, t] for x, t in found if not x.startswith('#')]
            #dialog.textviewer('red', str(found))
        return found
    except Exception as e:
        #dialog.ok('red', str(e))
        return []
    
def foot_links(url, name, name2, name3):
    try:
        namelist = [name,name3]
        table2 = requests.get(url).text
        table2 = six.ensure_str(table2)
        bitelinks = re.findall('<a target="_blank" href="(.*?)">', table2, flags=re.DOTALL)
        found_bite = [l for l in bitelinks if any(word.lower() in l.lower() for word in namelist)]
        if len(found_bite) == 0:
            found_bite = [l for tag in name2 for l in bitelinks if tag in l.lower()]
        if len(found_bite) > 0:
            bite_cont = requests.get(found_bite[0]).text
            bite_cont = six.ensure_str(bite_cont)
            found = re.findall('<input type="hidden" value="(.*?)" id=".*?">.*?</i> (.*?)</td>',bite_cont,flags=re.DOTALL)
        return found
    except Exception as e:
        #dialog.ok('fiot', str(e))
        return []
    
def m3_links(name, name2, name3, type):
    try:
        namelist = [name,name3]
        found = []
        table1 = ''
        req = urllib2.Request('http://bit.ly/FOOTYSTRMZ')
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
        response = urllib2.urlopen(req)
        table2=response.read()
	    
        #table2 = requests.get('http://bit.ly/FOOTYSTRMZ',headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0'}, allow_redirects=True).text #  requests.get('http://bit.ly/FOOTYSTRMZ',).text
        table = six.ensure_str(table2)
        #dialog.ok('max',str(table))
        table = table.replace("/<\!--.+?-->/sg","") 
        bitelinks = re.findall('<title>(.*?)<.*?<link>(.*?)<', table, flags=re.DOTALL)
        
        found_bite = [l for n, l in bitelinks if any(word.replace('-',' ').lower() in n.lower() for word in namelist)]
        if len(found_bite) == 0:
            found_bite = [l for tag in name2 for n, l in bitelinks if tag in n.lower()]
        if len(found_bite) > 0:
            found = [l for l in found_bite if '.m3u8' in l]
        response.close()

        return found
    except Exception as e:
        #dialog.ok('max',str(e))
        return []
    
def daddy_links(url, name, name2, name3, type):
    try:
        namelist = [name,name3]
        found1 = []
        found2 = []
        table3 = requests.get(url).text
        table3 = six.ensure_str(table3)    
        try:data = table3.split('>%s</h2>' % type)[1].split('<h2')[0] #('<a target="_blank" href="(.*?)">', table3, flags=re.DOTALL)
        except: data=[]    
        try:dhdlinks = re.findall('<hr>(.*?) <(.*?)<br/>', data ,re.MULTILINE | re.DOTALL)
        except:dhdlinks = []
        dhd_found = [l for n, l in dhdlinks if any(word.replace('-',' ').lower() in n.lower() for word in namelist)]
        #if len(dhd_found) == 0: dhd_found = [l for n, l in dhdlinks if name3.replace('-',' ').lower() in n.lower()]
        if len(dhd_found) == 0:dhd_found = [l for tag in name2 for n, l in dhdlinks if tag in n.lower()]
        found = re.findall('<a style=".*?" href="(.*?)" target="_blank" rel="noopener">(.*?)</a></span>', dhd_found[0], flags=re.DOTALL)
        found2 = ['https://dlhd.so'+n for n, l in found if not any(word.lower() in l.lower() for word in ignore)]
        found1 = ['webudi.openhd.lol/lb/premium'+ n.split('stream-')[1].split('.')[0] for n, l in found if any(word.lower() in l.lower() for word in ignore)]

        #dialog.ok('max',str(found2))
        return [found2,found1]
    except:
    	return [[],[]]

def max_links(url, name, name2, name3):
    try:
        namelist = [name,name3]
        found1 = []
        found2 = []
        table4 = requests.get(url).text
        table4 = six.ensure_str(table4)
        maxlinks = [re.sub(r'[^\S\n]*\n[^\S\n]*', ' ', x).strip() for x in re.split(r'\n[^\S\n]*(?=\d)', table4)]

        found_max = [(index, l) for index, l in enumerate(maxlinks) if any(word.replace('-',' ').lower() in l.lower() for word in namelist)]
        #if len(found_max) == 0:
            #found_max = [(index, l) for index, l in enumerate(maxlinks) if name3.replace('-',' ').lower() in l.lower()]
        if len(found_max) == 0:
            found_max = [(index, l) for tag in name2 for index, l in enumerate(maxlinks) if tag in l.lower()]
        found = re.findall(r'(https?://[^\s]+)', found_max[0][1])

        if len(found) == 0:
            next = int(found_max[0][0])+1
            found = re.findall(r'(https?://[^\s]+)', maxlinks[next])

        if len(found) == 0:
            next = int(found_max[0][0])+2
            found = re.findall(r'(https?://[^\s]+)', maxlinks[next])
        
        if len(found) == 0:
            next = int(found_max[0][0])+3
            found = re.findall(r'(https?://[^\s]+)', maxlinks[next])
        for link in found:
            if not any(x in link.lower() for x in ignore2):
                    
                found2.append(link)
            else:
                found1.append(link)
        #dialog.ok('max', str(found2))
        return [found2, found1]

    except Exception as e:
        #dialog.ok('max',str(e))
        return [[],[]]
        
        
def l1l1_links(url, name, name2, name3):
    try:
        namelist = [name,name3]
        found1 = []
        found2 =[]
        table5 = requests.get(url).text
        table5 = six.ensure_str(table5)
        data = re.findall('<div class="d2">(.*?)----------------', table5 ,re.MULTILINE | re.DOTALL)
        #maxlinks = [re.sub(r'[^\S\n]*\n[^\S\n]*', ' ', x).strip() for x in re.split(r'\n[^\S\n]*(?=\d)', table4)]

        found_l1 = [l for l in data if any(word.replace('-',' ').lower() in l.lower() for word in namelist)]
        #if len(found_l1) == 0:
            #found_l1 = [l for l in data if name3.replace('-',' ').lower() in l.lower()]
        if len(found_l1) == 0:
            found_l1 = [l for tag in name2 for l in data if tag in l.lower()]
        for link in found_l1:
            if '[EN]' in link:
                found1.append(re.findall('<a href="(.*?)"', link))
            elif not '[' in link:
                found1.append(re.findall('<a href="(.*?)"', link))
            else:
                found2.append(re.findall('<a href="(.*?)"', link))
       # 
        found1 = list(itertools.chain.from_iterable(found1))
        found2 = list(itertools.chain.from_iterable(found2))
        #dialog.ok('list', str(found1))
        return [found1, found2]
    except Exception as e:
        #dialog.ok('l1l1',str(e))
        return [[],[]]