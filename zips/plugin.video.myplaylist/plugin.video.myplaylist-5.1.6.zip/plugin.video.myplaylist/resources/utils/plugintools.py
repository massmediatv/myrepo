import xbmc,xbmcplugin,xbmcaddon,xbmcgui,xbmcvfs
import inputstreamhelper

from resources.utils.resolve_check import *
from resources.resolvers.resolvers import *
from resources.utils.checker import *
from resources.utils.dom_parse import *
from bs4 import BeautifulSoup, Comment
from six.moves import reduce
try:import urllib2
except: import urllib.request as urllib2
try: import urllib.parse as urllib
except: import urllib
import re
import sys
import os
import six
import itertools
import io
import time
import json
#import datetime
import base64
import resolveurl

try:transPath = xbmc.translatePath
except:transPath = xbmcvfs.translatePath
dialog =  xbmcgui.Dialog()
myAddon = xbmcaddon.Addon().getAddonInfo("id")
addonid = xbmcaddon.Addon(myAddon) 
runpath = transPath(addonid.getAddonInfo('Path'))
art_path = os.path.join( runpath , "resources" , "art" )
#testFile = os.path.join(runpath, 'resources','utils', 'brotli-dict')
#myfile = open(testFile, 'a+')
#testFile2 = os.path.join(runpath, 'test2.txt')
#myfile2 = open(testFile2, 'a+')
icon = runpath+"/icon.png"
fanart = runpath+"/fanart.jpg"

mainXml = 'https://www.dropbox.com/s/fneese367e0lsbr/my.xml?dl=1'




def openset():
    addonid.openSettings()
    
def getContent(url, referer=False, redirect=False, data=False):
    try:
	    url = six.ensure_str(url)
	    if not data == False:
	        data = urllib.urlencode(data).encode('utf-8')
	        req = urllib2.Request(url=url,data=data)
	    else:
	        req = urllib2.Request(url)
	    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	    if not referer == False:
	        req.add_header('Referer', referer)
	    response = urllib2.urlopen(req)
	    if not redirect == False:
	        link = [response.read(),response.geturl()]
	    else:
	        link=response.read()
	    response.close()
	    return link
    except Exception as e:
        #dialog.ok('errorstream',str(e))
        return '<error>'
        

        
def playUrl(name, url, iconimage=None):
    try:
        url = six.ensure_str(url)

        inpstream = False
        #url = 'https://strikeout.ws/arsenal-sarandi-vs-defensa-y-justicia-stream-1'

        if 'plugin://plugin' in url and 'youtube' in url:
            xbmc.executebuiltin('ActivateWindow(10025,"'+url+'"), return')
        
        else:
            #dialog.ok('url', url)
            if '.m3u8' in url:
                url = url
                inpstream = True

            else:
                res_url = fetch_urll(url, _iframe=False, badmatch=[], check_urls=[], referer=None)

                if res_url != None:
                    url = res_url[0]
                    url = six.ensure_str(url)
                    if '.m3u8' in url:
                        inpstream = True
                elif resolveurl.HostedMediaFile(url).valid_url(): 
                    url = resolveurl.HostedMediaFile(url).resolve()

            
            url = six.ensure_str(url)
            #dialog.ok('url', url)
            listitem = xbmcgui.ListItem(path=url)
            listitem.setArt({'thumb': iconimage})
            if inpstream:
                try: hdr = url.split('|')[1]
                except: hdr = url
                PROTOCOL = 'hls'
                is_helper = inputstreamhelper.Helper(PROTOCOL)
                if is_helper.check_inputstream():
                    #play_item = xbmcgui.ListItem(path=stream)

                    listitem.setContentLookup(False)
 
                    listitem.setProperty('inputstream', 'inputstream.ffmpegdirect')
                    listitem.setMimeType('application/x-mpegURL')
                    listitem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
                    listitem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
                    listitem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            

            listitem.setProperty("IsPlayable", "true")            
            listitem.setInfo(type="Video", infoLabels={ "Title": name })

            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    except Exception as e:
        xbmcgui.Dialog().ok(xbmcaddon.Addon().getAddonInfo("name"), str(e))
        return

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
                            
    return param
    
    

    
def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r
	
def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r
	
def compile(url):
    url = six.ensure_str(url)
    try: title = re.compile('<name>(.*?)</name>', re.MULTILINE | re.DOTALL).findall(url)[0]
    except: title = re.compile('<title>(.*?)</title>', re.MULTILINE | re.DOTALL).findall(url)[0]
 
    try: links = re.compile('<link>(.*?)</link>', re.MULTILINE | re.DOTALL).findall(url)
    except: links = False
 
    try: thumb = re.compile('<thumbnail>(.*?)</thumbnail>', re.MULTILINE | re.DOTALL).findall(url)[0]
    except: thumb = ''
    if thumb == '': thumb = xbmcaddon.Addon().getAddonInfo("icon")
 
    try: fanart = re.compile('<fanart>(.*?)</fanart>', re.MULTILINE | re.DOTALL).findall(url)[0]
    except: fanart = ''
    if fanart == '': fanart = xbmcaddon.Addon().getAddonInfo("fanart")
 
    try: description = re.compile('<description>(.*?)</description>', re.MULTILINE | re.DOTALL).findall(url)[0]
    except: description = ''   
    return title,links,thumb,fanart,description
    
def addDir(name, url, mode, iconimage, fanart, description, extra ='', page='', cm=[], isFolder=True, isPlayable='true'):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)+"&extra="+urllib.quote_plus(extra)+"&page="+urllib.quote_plus(page)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': iconimage, 'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
    liz.setProperty('IsPlayable', isPlayable)
    liz.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.setContent( int(sys.argv[1]) ,"videos" )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
    
def install_addon(id):
    try:
        # See if there's an installed repo that has it
        xbmc.executebuiltin('InstallAddon({})'.format(id), wait=True)

        # Check if InputStream add-on exists!
        xbmcaddon.Addon('{}'.format(id))

        #log(0, 'InputStream add-on installed from repo.')
        addonid.setSetting(id, '')
        xbmc.executebuiltin("Container.Refresh()")
    except RuntimeError:
        #log(3, 'InputStream add-on not installed.')
        return False






