try: import urllib.parse as urllib
except: import urllib
from resources.utils import jsunpack
from resources.resolvers.resolvers import *
from resources.resolvers import m3u8 as m3u8checker
import requests
import base64
import re
import six
import xbmcgui
dialog =  xbmcgui.Dialog()

def resolve(url):
    try:
        
        #r = requests.get(url).text
        #if 'zmid ' in str(r): u = seventwenty(url)
        
        if 'elixx.xyz' in url: u = elixx(url)

        elif 'daddylive' in url: u = daddylive(url)

        elif 'daddyhd' in url: u = daddylive(url)
        
        elif 'dlhd.so' in url: u = daddylive(url)

        elif 'livetvon' in url: u = daddylive(url)

        elif 'eddensports.com' in url: u = solaris(url)

        elif 'redsoccer.info' in url: u = solaris(url)

        elif 'worldstreams.net' in url: u = worldstreams(url)

        elif 'mazymedias.com' in url: u = mazy(url)

        elif 'mazystreams.xyz' in url: u = mazy(url)

        elif 'buffstream.live/nfl' in url: u = crackacnfl(url)

        elif 'buffstream.live/nba' in url: u = bslivenba(url)

        elif 'ufcstreams.net/nbastreams.php' in url: u = bslivenba(url)

        elif 'nflup.live' in url: u = nflup(url)

        elif 'papahd' in url: u = papahd(url)
        
        elif 'bfst.xyz' in url: u = beast(url)

        elif 'bfst.live' in url: u = onestream(url)

        elif 'fightpass.site' in url: u = fightpass(url)

        elif 'allsportsmedia.live' in url: u = fightpass(url)

        elif 'allsportsdaily.co' in url: u = tvnba(url)

        elif 'gameavenue.co' in url: u = tvnba(url)

        elif 'maxsports.site' in url: u = tvnba(url)

        elif 'icelz.newsrade.tk' in url: u = ice(url)

        elif 'hockeynews.site' in url: u = helena(url)

        elif 'tennews.live' in url: u = helena(url)

        elif 'nbaweb.site' in url: u = helena(url)

        elif 'hockeyweb' in url: u = tvnba(url)

        elif 'scoresunday.com' in url: u = tvnba(url)

        elif 'nbaweb.xyz' in url: u = skuanet(url)

        elif 'myustv.com' in url: u = myustv(url)

        elif 'freesport.info' in url: u = myustv(url)

        elif 'cricworld.club' in url: u = myustv(url)

        elif 'thecyclingentertainment.com' in url: u = markky(url)

        elif 'motornews.live' in url: u = markky(url)

        elif 'markky88.com' in url: u = markky(url)

        elif 'markkystreams.com' in url: u = markky(url)

        elif '6stream.xyz' in url: u = markky(url)

        elif '6streams.tv' in url: u = markky(url)

        elif 'foxupdates.com' in url: u = markky(url)

        elif 'successstudios.co' in url: u = markky(url)

        elif 'sportsnest.co' in url: u = sportsnest(url)

        elif 'dofusports' in url: u = sportsnest(url)

        elif 'nbajunkie.xyz/' in url: u = sportsnest(url)

        elif 'bestreamsports.org' in url: u = sportsnest(url)

        elif 'sportsbuzz.co' in url: u = markky(url)

        elif 'givemevibes.com' in url: u = markky(url)

        elif 'techtricksng.com' in url: u = markky(url)

        elif 'telechargementfilmhd.com' in url: u = nbahdreplay(url)
        
        elif 'bestsolaris.com/nhlstreams' in url: u = tvnhl(url)

        elif 'bestsolaris.com' in url: u = tvnba(url)

        elif '123tvsports.com/nfl-streams/' in url: u = tvnfl(url)

        elif '9live.club' in url: u = tvnfl(url)

        elif '123tvsports.com/ncaaf-streams/' in url: u = tvncaaf(url)

        elif '123tvsports.com/mma-streams/' in url: u = tvmma(url)

        elif '123tvsports.com/boxing-streams/' in url: u = tvboxing(url)

        elif '123tvsports.com/f1-streams/' in url: u = tvf1(url)

        elif 'live-nhl.stream' in url: u = livenhl(url)

        elif 'sportsbay.org' in url: u = sportsbay(url)

        elif 'live-tennis.stream' in url: u = tennislive(url)

        elif 'nascar-live.stream' in url: u = tennislive(url)

        elif 'sports24.club/nhl' in url: u = sports24nhl(url)

        elif 'sports24.site/nhl' in url: u = sports24nhl(url)

        elif 'sports24.club/f1' in url: u = sports24f1(url)

        elif 'sports24.club/nba' in url: u = sports24nba(url)

        elif 'sports24.club/nfl' in url: u = sports24nfl(url)

        elif 'sports24.club/ncaa' in url: u = sports24ncaa(url)

        elif 'sports24.club/ncaab' in url: u = sports24ncaab(url)

        elif 'sports24.club/ncaab' in url: u = sports24ufc(url)

        elif 'everysports.us/watch/nhl/' in url: u = everysportsnhl(url)

        elif 'everysports.us/view/mlb' in url: u = everysportsmlb(url)

        elif 'everysports.us/view/nfl' in url: u = everysportsnfl(url)

        elif 'volokit.com/all-games/nhl' in url: u = volokitnhl(url)

        elif 'volokit.com/all-games/mlb' in url: u = volokitmlb(url)

        elif 'volokit.com/volostream/nfl-games' in url: u = volokitnfl(url)

        elif 'volokit2' in url: u = volokit2(url)

        elif 'sportsstatsme.net/watch/NHL-streams' in url: u = ssnhl(url)

        elif 'retsports.com' in url: u = ssnhl(url)

        elif 'sportsstats.xyz/www.sportsstats.me' in url: u = ssnhl(url)

        elif 'sportsstats.xyz/www.sportsstats.me/nhl2' in url: u = ssnhl(url)

        elif 'sportsstats.xyz/www.sportsrp.com/nhl' in url: u = ssnhl(url)

        elif 'sportsrp.com/www.sportsstats.me/nhl2' in url: u = ssnhl(url)

        elif 'sportsrp.com/sechdules/NHL-streams/2/' in url: u = ssnhl(url)

        elif 'www.sportsrp.com/watch/NHL-streams' in url: u = ssnhl(url)

        elif 'sportsstats.xyz/www.sportsstats.me/nhl3' in url: u = ssnhl(url)

        elif 'sportsstats.xyz/www.sportsstzts.me/nhl2' in url: u = ssnhl(url)

        elif 'sportsstatsme.net/watch/NBA-streams' in url: u = ssnba(url)

        elif 'sportsstatsme.net/watch/NFL-streams' in url: u = ssnba(url)

        elif 'sportsstatsme.net/watch/MLS-streams' in url: u = ssnba(url)

        elif 'playoffsstream' in url: u = playoffnfl(url)

        elif '720pstream' in url: u = seventwenty(url)

        elif 'watchkobestreams' in url: u = watchkobestreams(url)

        elif 'yoursports.stream' in url: u = yss(url)

        elif 'yrsprts.stream' in url: u = yss(url)

        elif 'yoursports.to' in url: u = yss(url)

        elif 'buffstream.io' in url: u = crackstreams(url)

        elif 'methstreams' in url: u = rmeth(url)

        elif 'nbastreamswatch' in url: u = rmeth(url)

        elif 'hesgoal' in url: u = hesgoal(url)

        elif 'thecrackstreams.net' in url: u = thecslive(url)

        elif 'thecrackstreams.live' in url: u = thecslive(url)

        elif 'buffstreams.app' in url: u = thecslive(url)

        elif 'buffstreams.ai' in url: u = thecslive(url)

        elif '60fps' in url: u = givemereddit(url)

        elif 'givemereddit' in url: u = givemereddit(url)

        elif 'givemenflstreams' in url: u = givemereddit(url)

        elif 'givemenbastreams' in url: u = givemereddit(url)

        elif 'givememmastreams' in url: u = givemereddit(url)

        elif 'givemeredditstreams' in url: u = givemereddit(url)

        elif 'tezgoal.com' in url: u = hdstreams(url)

        elif 'freehdgames' in url: u = hdstreams(url)

        elif 'hhdstreams.club' in url: u = hdstreams(url)

        elif 'hdstreamss.club' in url: u = hdstreams(url)

        elif 'uhdstreams.club' in url: u = hdstreams(url)

        elif 'uhdgames.xyz' in url: u = hdstreams(url)

        elif 'gameshdlive' in url: u = gameshdlive(url)

        elif 'bfstrms.xyz' in url: u = buff(url)

        elif 'ntgdhsgfs.re/' in url: u = buff(url)

        elif 'bfst.to' in url: u = buff(url)

        elif 'bfstrs.xyz' in url: u = buff(url)

        elif 'buffstreamz.com' in url: u = buff(url)

        elif 'ripple.stream' in url: u = ripple(url)

        elif 'nflsportz.com' in url: u = nflsportz(url)

        elif 'topstreams.info/nba' in url: u = topstreams(url)

        elif 'topstreams.info/nfl' in url: u = topstreamsnfl(url)

        elif 'streameast' in url: u = streameast(url)
        
        elif 'rojadirecta.'in url: u = streameast(url)
        
        elif 'thebuffstreams' in url: u = streameast(url)
        
        elif 'thesportsurge.net' in url: u = streameast(url)

        elif 'ertech.work' in url: u = skuanet(url)

        elif 'chimxoan.net' in url: u = skuanet(url)

        elif 'skuanet.us' in url: u = skuanet(url)

        elif 'Skuanet.Us' in url: u = skuanet(url)

        elif 'harumu.me/' in url: u = skuanet(url)

        elif 'viafb.site/' in url: u = skuanet(url)

        elif 'fnew.tech' in url: u = skuanet(url)

        elif 'psm.wtf' in url: u = skuanet(url)

        elif 'fabtech.work' in url: u = skuanet(url)

        elif 'ruapa.com/' in url: u = skuanet(url)

        elif 'gardener101.work' in url: u = skuanet(url)

        elif 'jmutech.xyz' in url: u = skuanet(url)

        elif 'aas.works' in url: u = skuanet(url)

        elif 'kimta' in url: u = skuanet(url)

        elif 'sagoad.com/' in url: u = skuanet(url)

        elif 'anhdepmoingay.com/' in url: u = skuanet(url)

        elif 'ustvgo.cc' in url: u = skuanet(url)

        elif 'hinhnenhd.info' in url: u = skuanet(url)

        elif 'bubofitness.com' in url: u = skuanet(url)

        elif 'midcoastplanning.org' in url: u = skuanet(url)

        elif 'fxmagicmusic' in url: u = skuanet(url)

        elif 'ftheanh.tech' in url: u = skuanet(url)

        elif 'azulitostreams.com' in url: u = skuanet(url)

        elif 'banknotewiki.com' in url: u = skuanet(url)

        elif 'boxingfightsvideos' in url: u = boxingfightsvideos(url)

        elif 'crichd' in url: u = cric(url)
        
        elif 'telehub.org' in url: u = tubby(url)

        elif 'btstream.live' in url: u = btstream(url)
        
        elif 'soccerjumbotv1.me' in url: u = jumbo(url)

        elif 'sjumbotvs' in url: u = jumbo(url)

        elif 'sportnews.to' in url: u = sportnews(url)

        elif 'mysports.to' in url: u = sportnews(url)

        elif 'footy.to' in url: u = sportnews(url)

        elif 'blacktiesports' in url: u = blacktienba(url)

        elif 'wpstream.tv' in url: u = weakspell(url)

        elif 'weakspell' in url: u = weakspell(url)

        elif 'weaksports.xyz' in url: u = hdstreams(url)

        elif 'liveonscore.tv' in url: u = weakspell(url)

        elif 'liveonscore.to' in url: u = weakspell(url)

        elif 'weakstreams' in url: u = weakspell(url)

        elif 'weakstream.org' in url: u = weakspell(url)

        elif 'ufckhabib.com' in url: u = ufckhabib(url)

        elif 'sportsurge.stream' in url: u = ufckhabib(url)

        elif 'ovostreams' in url: u = ovostreams(url)

        elif 'sportschamp' in url: u = ovostreams(url)

        elif 'soccerstreams.football' in url: u = ovostreams(url)

        elif 'tv247.us' in url: u = tvtwofour(url)

        elif 'myoplay.club' in url: u = myoplay(url)

        elif 'crackstreams.biz' in url: u = csbiz(url)

        elif 'crackstreams.club' in url: u = csbiz(url)

        elif 'crackstreams.is' in url: u = csis(url)

        elif 'nbastreams.gg' in url: u = csis(url)

        elif 'crackstreams.to' in url: u = csto(url)

        elif 'sportsnews4u.net' in url: u = csto(url)

        elif 'techoreels.com' in url: u = techno(url)

        elif 'techclips.net' in url: u = techno(url)

        elif 'bdnewszh' in url: u = ranionfl(url)

        elif 'epllive.net' in url: u = ranionfl(url)

        elif 'streamspass' in url: u = ranionfl(url)

        elif 'recipemam.com' in url: u = recipemam(url)

        elif 'catchystream.com' in url: u = catchy(url)

        elif 'sportsurge.in' in url: u = sportsurge(url)

        elif 'hdstreams.pw' in url: u = sportsurge(url)

        elif 'ace' in url: u = ace(url)

        elif 'nbatvsport.com' in url: u = nbatvsport(url)

        elif 'changnews.co.uk' in url: u = nbatvsport(url)

        elif 'geekingeek.com' in url: u = geekingeek(url)

        elif 'rightcombat.com' in url: u = rightcombat(url)

        elif 'poscitech.com' in url: u = poscitech(url)

        elif 'iwizwig.online' in url: u = iwizwig(url)

        elif 'torridplay.com' in url: u = skuanet(url)

        elif 'sportinglive.co' in url: u = skuanet(url)

        elif 'cricworld.club' in url: u = cricworld(url)

        elif 'nflscoop' in url: u = sportsupa(url)

        elif 'nflbuzz.xyz' in url: u = capp(url)

        elif 'techstribes.com' in url: u = capp(url)

        elif 'grealish.net' in url: u = capp(url)

        elif 'darwinstreams.com' in url: u = darwinstreams(url)

        elif 'freetvsports.com' in url: u = freetvsports(url)

        elif 'p2pstreams.com' in url: u = ptwopstreams(url)

        elif 'p2pstreams.live' in url: u = ptwopstreams(url)

        elif 'sportek.xyz' in url: u = sportek(url)

        elif 'bongstreams.com' in url: u = bong(url)

        elif 'sporteks.net' in url: u = sporteks(url)

        elif 'pawastreams' in url: u = pawastreams(url)
        
        elif 'espnv2' in url: u = espnv2(url)

        elif 'supertipz.com' in url: u = supertipz(url)

        elif 'dubsstreamz.com' in url: u = dubsstreamz(url)

        elif 'dubzstreams.com' in url: u = dubsstreamz(url)

        elif 'summerlivestream.com' in url: u = summerlivestream(url)

        elif 'streaming4u.org/' in url: u = summerlivestream(url)

        elif 'soccer24hd.com' in url: u = sstwentyfour(url)

        elif 'crazystreams.ga' in url: u = crazystreams(url)

        elif '1stream' in url: u = onestream(url)

        elif 'topstreams.tv' in url: u = toptv(url)

        elif 'dubznetwork' in url: u = dubznetwork(url)

        elif 'tvsportslive.fr' in url: u = tvsportslive(url)

        elif 'sportsio' in url: u = sportsio(url)

        elif '60fps' in url: u = sixtyfps(url)

        elif 'sportsguild.net' in url: u = sportsguild(url)

        elif 'ustv247.tv' in url: u = ustvtwentyfourseven(url)

        elif 'sportinglive' in url: u = sportinglive(url)

        elif 'silverspoon.site' in url: u = silverspoon(url)

        elif 'sequencecard.xyz' in url: u = silverspoon(url)

        elif 'willsports' in url: u = silverspoon(url)
        
        elif 'onloop.pro' in url: u = silverspoon(url)

        elif 'sportsallday.net' in url: u = silverspoon(url)

        elif 'sportsupa' in url: u = sportsupa(url)

        elif 'maxsport' in url: u = maxsport(url)

        elif 'thegentleclass' in url: u = tvnba(url)

        elif 'hitstreams' in url: u = hitstreams(url)

        elif 'metaporky' in url: u = metaporky(url)

        elif 'alexsports' in url: u = alexsports(url)

        elif 'alexsportz' in url: u = alexsports(url)

        elif 'nbagaffer' in url: u = nbagaffer(url)

        elif 'soccerstreams.football' in url: u = soccerstreams(url)

        elif 'f1livestream' in url: u = soccerstreams(url)

        elif 'soccersislive' in url: u = soccersislive(url)

        elif 'bikesports' in url: u = tvnba(url)

        elif 'basketball-video' in url: u = basketballvideo(url)

        elif 'nfl-video' in url: u = nflvideo(url)

        elif 'nizarstream' in url: u = nizarstream(url)

        elif 'enjoyhd' in url: u = enjoyhd(url)

        elif 'youpit' in url: u = youpit(url)

        elif 'mysports.to' in url: u = sportnews(url)

        elif 'prolive.tv' in url: u = prolive(url)

        elif 'paktech2' in url: u = paktech(url)

        elif 'olympicology.com' in url: u = olympicology(url)

        elif 'enjoy4k' in url: u = enjoyfourk(url)

        elif 'sports-stream.site' in url: u = sportsstreamsite(url)

        elif 'hdrez' in url: u = hdrez(url)

        elif 'bingsport' in url: u = bingsport(url)

        elif 'thetvapp' in url: u = tvapp(url)

        elif 'score808.football' in url: u = score(url)

        elif 'worldcupglory' in url: u = worldcupglory(url)

        elif 'headlines.footybite.to' in url: u = worldcupglory(url)

        elif 'headlines.reddit-soccerstreams' in url: u = headlines(url)

        elif 'backfirstwo' in url: u = backfirstwo(url)

        elif 'streambtw' in url: u = streambtw(url)

        elif 'livespor' in url: u = streambtw(url)
        
        elif '1l1l.to/' in url or 'l1l1.to/' in url: u = l1l1(url)
        
        elif 'fullmatchtv.' in url: u = fullmatchtv(url)
        
        elif 'sportea.' in url: u = sportea(url)
        
        elif 'salvagesurge.top' in url: u = sportea(url)
        
        elif 'hdenjoy.' in url: u = hdenjoy(url)
        
        elif "embedstreamgate.com" in url: u = csbiz(url)
        
        elif "eplwebcast" in url: u = epl_web(url)
        
        elif "s2watch." in url: u = s2watch(url)
        
        elif 'premiumplug' in url or 'issuessolution' in url or 'gpllicense' in url: u = wrestlingpro(url)
        
        elif 'dailymotion.com' in url:
            vid = url.rsplit('/', 1)[-1]
            u = dailymotion(vid)
        
        elif 'vidsrc' in url:
            from resources.resolvers import vidme
            u = vidme.vidsrc(url)        

        return u
    except:
        pass

def fetch_urll(url, _iframe=False, badmatch=[], check_urls=[], referer=None):
    pattern_m3u8 = re.compile(r'''['"]([^'"]+m3u8.*?)['"]''')
    pattern_iframe = re.compile(r'''<i?frame.+?src=[\"\']?([^\"\' ]+).*?['"]''')
    
    try:
        if not referer:
            ref = url
        else:
            ref = referer
        
        urlHandler = requests.get(url, headers={'referer': ref}).text
        urlHandler = six.ensure_str(urlHandler)
        quick_check = m3u8checker.getStreamUrl(url, html=urlHandler)
        res = resolve(url)
        
 
        
        if ".m3u8" in url:
            try: 
                try:urll = url.split('.m3u8')[0]
                except: urll = url.split('?&connection')[0]
            except: 
                try:urll = url.split('|')[0]
                except: urll = url
            if urll not in check_urls and not any(x in urll for x in badmatch):
                check_urls.append(urll)
                return [url, urll]
            # res = None
        elif res !=None:
            
            try: 
                try:urll = res.split('.m3u8')[0]
                except: urll = res.split('|')[0]
            except: urll = res
            if urll not in check_urls and not any(x in urll for x in badmatch):
                check_urls.append(urll)

                return [res, urll]
        
        elif quick_check:
            if '.m3u8' in quick_check:
            
                urll = quick_check.split('.m3u8')[0]
                #except: urll = quick_check.split('|')[0]
                if urll not in check_urls and not any(x in quick_check for x in badmatch):
                    check_urls.append(urll)
                    return [quick_check, urll]
            else:
                return fetch_urll(quick_check, _iframe=False, badmatch=badmatch, check_urls=check_urls, referer=url)
        

        elif pattern_m3u8.search(urlHandler):
            
            for m3u8 in pattern_m3u8.findall(urlHandler):
                m3 = m3u8
                try:
                    try:m3u8 = m3.split('.m3u8')[0]
                    except: m3u8 = m3.split('?&connection')[0]
                except: m3u8 = m3
                if m3u8 not in check_urls and not any(x in m3u8 for x in badmatch):
                    check_urls.append(m3u8)
                    return ['%s|Referer=%s&User-Agent=%s' % (m3,url,ua), m3u8] if m3.startswith('http') else []
                    
        elif pattern_iframe.search(urlHandler):
            
            for iframe in pattern_iframe.findall(urlHandler):
                if iframe.startswith('http') and not any(x in iframe for x in badmatch):
                    domain = urllib.urlparse(iframe).netloc
                    domain = domain.split('.')[0]
                    res_url = resolve(iframe)
                    
                    if 'wstream' in iframe or 'wigistream' in iframe:
                        try:
                            link2 = getContent(iframe,referer=url)
                            link2 = six.ensure_str(link2)
                            packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')
                            packed = packer.findall(link2)[0]
                            unpacked = jsunpack.unpack(packed)
                            source = re.compile('''['"](http[^'"]+)['"]''')
                            stream = source.findall(unpacked)[0]
                            stream_url = ('%s|verifypeer=false&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36' % stream)
                            try:
                                try:m3u8 = stream.split('.m3u8')[0]
                                except: m3u8 = stream.split('?&connection')[0]
                            except: m3u8 = stream
                            
                            if m3u8 not in check_urls and not any(x in m3u8 for x in badmatch):
                                check_urls.append(m3u8)

                                return [stream_url, m3u8]
                        except: pass
                        
                    elif res_url != None:
                        try: 
                            try:urll = res_url.split('?auth')[0]
                            except: urll = res_url.split('?&connection')[0]
                        except: urll = res_url.split('|')[0]
                        if urll not in check_urls and not any(x in urll for x in badmatch):
                            check_urls.append(urll)
                            return [res_url, urll]
                        #dialog.ok('test', 'hi')

                    else: return fetch_urll(iframe, _iframe=True, badmatch=badmatch, check_urls=check_urls, referer=url)
                    
                else:
                    domain = urllib.urlparse(url).netloc
                    sche = urllib.urlparse(url).scheme
                    if iframe.startswith('//'):
                        next_iframe = sche +':'+iframe
                    else:
                        next_iframe = sche +'://'+domain+iframe
                    return fetch_urll(next_iframe, _iframe=True, badmatch=badmatch, check_urls=check_urls, referer=url)
        return 
    except Exception as e:
        #dialog.ok('myaddon',str(e))
        return 
