from resources.utils.plugintools import*
import requests

ignore = ['france', ' fr', 'croatia', 'bulgaria', 'germany', 'canal', ' de ', 'portugal', 'turkey', 'romania', 'italy', ' br', ' sur', 'israel', 'poland', 
    'serbia', ' espa', ' es ', 'spain', 'arabia', 'brazil', 'dutch', ' nl', 'argentina', 'russia', 'ukraine', 'new zealand', ' prima', 'movistar', 
    'deportes', 'australia', 'maximo', 'columbia', 'arena sport', 'uruguay', 'weather', 'willow ']

def liveon():
    try:
        url2 = 'https://liveon.sx/program'
        content2 = getContent(url2)
        content2 = six.ensure_str(content2)
     
        xmlLists2 = re.findall('<td><a href="(.*?)" onclick=".*?"><button class="tvch">(.*?)<i class',content2, re.MULTILINE | re.DOTALL)
        if len(xmlLists2) < 1:
            raise Exception()
        englist = [(add, item.strip()) for add, item in xmlLists2 if not any(x in item.strip().lower() for x in ignore)]
        for addres, item in englist:

	        addDir(item,addres,2,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
	
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
    except Exception as e:
        return
        
def l1l1_sched():
    try:

        url = 'https://liveon.sx/program'
        table5 = requests.get(url).text
        table5 = six.ensure_str(table5)
        from datetime import datetime as dates
        import datetime
        tod = dates.today().strftime('%A %d %B')
        tomorrow = dates.today() + datetime.timedelta(days=1)
        tomorrow = tomorrow.strftime('%A %d %B')
        try:table5 = table5.split(tod)[1]
        except:pass
        try: table5 = table5.split(tomorrow)[0]
        except: pass
        data = re.findall('<div class="d2">(.*?)----------------', table5 ,re.MULTILINE | re.DOTALL)
        #maxlinks = [re.sub(r'[^\S\n]*\n[^\S\n]*', ' ', x).strip() for x in re.split(r'\n[^\S\n]*(?=\d)', table4)]

        #found_l1 = [l for l in data if any(word.replace('-',' ').lower() in l.lower() for word in namelist)]
        #if len(found_l1) == 0:
            #found_l1 = [l for l in data if name3.replace('-',' ').lower() in l.lower()]
        #if len(found_l1) == 0:
            #found_l1 = [l for tag in name2 for l in data if tag in l.lower()]
        for link in data:
            programs = re.findall('<div class="left1" >(.*?)</div>',link, re.MULTILINE | re.DOTALL)[0]
            #dialog.ok('l1l1',str(programs))
            programs = programs.split('\n')
            links = re.findall('<a href="(.*?)"', link)
            try:
                for program in programs:
                    if not program == '':
                        timesplit = int(program.split(':')[0])
                        if timesplit == 0 or timesplit == 1:
                            raise Exception
                        else:
                            timealt = str(timesplit - 2).zfill(2)
                        titles = program.split(':', 1)[1]
                        name = str(timealt)+':'+titles
                        program = name.replace('&amp;', '&')
                        addDir(program,str(links),3,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
            except:
                pass
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
    except Exception as e:
        dialog.ok('l1l1',str(e))
        return [[],[]]