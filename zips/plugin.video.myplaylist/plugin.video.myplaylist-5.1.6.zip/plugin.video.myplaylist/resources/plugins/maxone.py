from resources.utils.plugintools import*
import requests

ignore = ['france', ' fr', 'croatia', 'bulgaria', 'germany', 'canal', ' de ', 'portugal', 'turkey', 'romania', 'italy', ' br', ' sur', 'israel', 'poland', 
    'serbia', ' espa', ' es ', 'spain', 'arabia', 'brazil', 'dutch', ' nl', 'argentina', 'russia', 'ukraine', 'new zealand', ' prima', 'movistar', 
    'deportes', 'australia', 'maximo', 'columbia', 'arena sport', 'uruguay', 'weather', 'willow ']
    
def max_sched():
    try:
        url = 'https://maxsport.one/index2.txt'
        table4 = requests.get(url).text
        table4 = six.ensure_str(table4)
        from datetime import datetime as dates
        import datetime
        tod = dates.today().strftime('%A, %d %B %Y').replace(', 0', ', ')
        tomorrow = dates.today() + datetime.timedelta(days=1)
        tomorrow = tomorrow.strftime('%A, %d %B %Y').replace(', 0', ', ')
        #dialog.ok('max', today+'\n'+tomorrow)
        try:table4 = table4.split(tod)[1]
        except:pass
        try: table4 = table4.split(tomorrow)[0]
        except: pass
        maxlinks = [re.sub(r'[^\S\n]*\n[^\S\n]*', ' ', x).strip() for x in re.split(r'\n[^\S\n]*(?=\d)', table4)]

        for link in maxlinks:
            links = re.findall(r'(https?://[^\s]+)', link)
            try:name = re.findall('^[0-9].*', link, re.MULTILINE)[0]
            except: name =''
            try: name = name.split('http')[0].strip()
            except:pass
            name = name.replace('\t', ' ').replace('  ', ' ') #re.sub(r"[\n\t\s]*", "", name)
            try:
                if ':' == name[2]:
                    addDir(name,str(links),3,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
            except:
                pass
            #dialog.ok('max', name)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)

    except Exception as e:
        dialog.ok('max',str(e))
        return [[],[]]

def maxone():
    try:

        url = 'https://maxsport.one'
        content = getContent(url)
        content = six.ensure_str(content)
         
        xmlLists = re.findall('<div class="grid-item"><a href="(.*?)".*?<strong>(.*?)</strong></span></a></div>',content, re.MULTILINE | re.DOTALL)
        if len(xmlLists) < 1:
            raise Exception()
        englist = [(add, item) for add, item in xmlLists if not any(x in item.lower() for x in ignore)]
        for address, item in englist:
            #if not any(x in item.lower() for x in ignore):
            link = url+address
            addDir(item,link,2,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
     
    except Exception as e:
        return
