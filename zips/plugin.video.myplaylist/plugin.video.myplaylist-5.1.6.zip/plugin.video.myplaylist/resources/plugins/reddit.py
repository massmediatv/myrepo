from resources.utils.plugintools import*
import requests

dp = xbmcgui.DialogProgress()

def football():
    try:
        divisions = []

        url = 'https://pre1.soccerstreamlinks.com/'
        link = getContent(url)
        link = six.ensure_str(link)
        #dialog.textviewer('test',str(link))
        link = re.compile('<h2 class="table-caption">.*?src="(.*?)".*?<a class="ml-1".*?href="(.*?)">(.*?)</a>').findall(repr(link))
        
        for img, url, item in link:
	        addDir(' [B]%s[/B]' % (item),url,21,img,xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)
    except Exception as e:
        dialog.ok('test',str(e))
        #pass
        
def football2(url):
    try:
        link = getContent(url)
        soup = BeautifulSoup(link, 'html.parser')
        data = soup.findAll('tr', {"class":["odd", "even"]})
        for i in data:
             home = i.select('abbr')[0].text
             away = i.select('abbr')[1].text
             #away = i.a[1].text
             img = i.img['src']
             #dialog.ok('tt',str(img))

             url2 = i.a['href']
        
             time = i.select('td')[2].text
             time = time.strip()
             title = home.strip()
             title = '%s -  %s' % (time, title)
             time = six.ensure_str(time)
             if 'LIVE' in time:
                 time = '[COLOR ff6efe17]%s[/COLOR]' % time
             elif 'Canceled' in time:
                 time = '[COLOR red]%s[/COLOR]' % time
             else:
                 time = '[COLOR yellow]%s[/COLOR]' % time
             title = ('%s  -  %s Vs %s' % (time, home,away))
             addDir("[B]%s[/B]" % title,url2,12,img,'','Soccer',extra='', isFolder= True)

	
    except Exception as e:
        dialog.ok('test',str(e))
        #pass
        
        
def football3(url):
    try:
        link = getContent(url)
        link = six.ensure_str(link)
        
        r = re.compile('class="team-name".*?href="(.*?)"><span>(.*?)</span>.*?<abbr.*?title=".*?">.*?<img src="(.*?)" class="imageLoaded">.*?<a class="team-name" href=".*?"><span>(.*?)</span>.*?style="display: table-cell.*?>(.*?)</a>').findall(repr(link))
        
        for url,home,img,away,time in r:
             time = six.ensure_str(time).strip()
             if 'LIVE' in time:
                 time = '[COLOR ff6efe17]%s[/COLOR]' % time
             elif 'Canceled' in time:
                 time = '[COLOR red]%s[/COLOR]' % time
             else:
                 time = '[COLOR yellow]%s[/COLOR]' % time
             title = ('%s  -  %s Vs %s' % (time, home,away))
             addDir("[B]%s[/B]" % title,url,12,img,'','Soccer',extra='', isFolder= True)

	
    except Exception as e:
        dialog.ok('test',str(e))
        #pass
        

def boxing(urll, type):

    url = 'https://onsite.boxingstreamlinks.com'
    link = getContent(urll)
    soup = BeautifulSoup(link, 'html.parser')
    data = soup.findAll('tr', {"class":["odd", "even"]})
    for i in data:
        home = i.a.text

        url2 = i.a['href']
        
        time = i.select('td')[2].text
        time = time.strip()
        title = home.strip()
        title = '%s -  %s' % (time, title)
        if ' vs' in title.lower():
            addDir("[B]%s[/B]" % title,url2,12,icon,'',type,extra='', isFolder= True)
        
        
def mma():

    url = 'https://mmastreamlinks.to'
    link = getContent(url)
    soup = BeautifulSoup(link, 'html.parser')
    data = soup.findAll('tr', {"class":["odd", "even"]})
    for i in data:
        title = i.a.text
        title = " ".join(title.split())

        url2 = i.a['href']
        
        time = i.select('td')[2].text
        time = time.strip()
        title = title = ('%s -  %s' % (time, title))
        addDir("[B]%s[/B]" % title,url2,12,icon,'','MMA',extra='', isFolder= True)
        
        

def fightreplays():
    try:
        playables = []
        url2 = 'https://boxingvideo.org/fight-replays/'
        content2 = getContent(url2)
        content2 = six.ensure_str(content2)

        xmlLists2 = re.findall('<a href="(.*?)" title="(.*?)">',content2, re.MULTILINE | re.DOTALL)
        if len(xmlLists2) < 1:
            raise Exception()
        for addres, item in xmlLists2:
            if ' vs' in item:
                items = [item, addres]
                if items not in playables:
	                playables.append([item,addres])
	
        if playables:
            for item in playables:
                addDir(item[0],item[1],11,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)

    except Exception as e:
        xbmcgui.Dialog().notification(xbmcaddon.Addon().getAddonInfo("name"), str(e)+ '    List unavailable', icon=xbmcaddon.Addon().getAddonInfo("icon"), time=5, sound=True)


def replaylink(url):
    try:
        playables = []
        content2 = getContent(url)
        content2 = six.ensure_str(content2)
        
        xmlLists2 = re.findall('<iframe.*?src="(.*?)"', content2, flags=re.IGNORECASE) # re.findall('<a href="(.*?)" title="(.*?)">',content2, re.MULTILINE | re.DOTALL)
        if len(xmlLists2) < 1:
            raise Exception()
        for item in xmlLists2:
            if item not in playables:
                if not item.startswith('http'): item = 'http:'+item
                 
                playables.append(item)
        if playables:

            for index, item in enumerate(playables):
                addDir('[B]Link [COLOR lime]%s[/B][/COLOR]' % str(int(index)+1),item,2,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)

    except Exception as e:
        xbmcgui.Dialog().notification(xbmcaddon.Addon().getAddonInfo("name"), str(e)+ '    List unavailable', icon=xbmcaddon.Addon().getAddonInfo("icon"), time=5, sound=True)
        
        
def search_links(url, name, type):
    dp.create (xbmcaddon.Addon().getAddonInfo("name"),"Searching Web")
    dp.update(10)
    try:name2 = name.lower().split('  -  ')[1].split(' vs ')[0].split(' ')
    except: name2 = []
    try:name3 = name.lower().split(' vs ')[1].split('[/b]')[0].replace(' ','-')
    except: name3 = ''
    dp.update(30)
    try:
        name = name.lower().split('  -  ')[1].split(' vs ')[0].replace(' ','-')
    except:
        name = name.lower().split('[b]')[1].split(' vs ')[0].replace(' ','-')
    
    urls = []
    badmatch = ['prntscr.com','facebook.com','discord.gg','reddit','twitch.tv', 'elixx']
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'
    headers = {'User-Agent': ua ,
                'Referer' : url}

    potentialred = red_links(url)
    dp.update(95)
    potentialfoot = foot_links('https://footybite.to',name,name2,name3)

    dp.update(90)

    
    urls+= [[l, a] for l, a in potentialred if l.startswith ('http') and l not in urls and not any(x in l for x in badmatch)]
    
    urls+= [[l, a] for l, a in potentialfoot if l.startswith ('http') and l not in urls and not any(x in l for x in badmatch)]
    

    if len(urls) == 0:
        dialog.notification(xbmcaddon.Addon().getAddonInfo("name"), '[B]Try 30 mins before Kick Off if game hasnt already finished[/B]', icon, 5000)
        quit()
    else: ThreadLinks(urls, badmatch, name)
        #for url,title in (urls):
            #myfile.write(str(url)+'\n')
            #addDir(url, url, 2, icon, fanart, url, extra='', isFolder= False)
            #addDir(title, url, 2, icon, fanart, url, extra='', isFolder= False)
def ThreadLinks(urls, badmatch, name=''):
    import threading
    dp.update(99)
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'
    badmatch+= ['prntscr.com', 'facebook.com', 'discord.gg', 'reddit', 'twitch.tv', 'google', 'widgets', 'youtube', '.png', '.jpg', 'widget']
    playables = []
    check_urls = []
    
    potential = len(urls)
    
    def fetch_urIl(url, _iframe=False, badmatch=badmatch, check_urls=check_urls, referer=None):
        if not referer:
            ref = url
        else:
            ref = referer
        
        urlHandler = getContent(url, referer=ref)
        pattern_m3u8 = re.compile(r'''['"]([^'"]+m3u8.*?)['"]''').findall(urlHandler)[0]
        return pattern_m3u8
          
    def fetch_url1(url, _iframe=False, referer=None):
        if '.m3u8' in url[0]:
            playables.append(url)
        fastcheck = fetch_urll(url[0], _iframe=False, badmatch=badmatch, check_urls=check_urls, referer=None)
        if fastcheck:
            check_urls.append(fastcheck[1])
            playables.append([fastcheck[0],url[1]])
            #playables.add(url)
    #dp.update(50, 'Checking Streams')
    dp.update(0)
    found = 0
    for url in urls:
        found += 1
        progress = (found) / float(len(urls)) * 100
        dp.update (int(progress),  "Grabbing Sources")
        threads = []
        t = threading.Thread(target=fetch_url1, args=(url,))
        threads.append(t)
        t.start()
    dp.update(0,'')
    #dp.update(99, 'Checking Streams')
    while True:
        if dp.iscanceled():
           break
        
        msg = "Links Found = [COLOR lime]%s | [/COLOR]Live Links = [COLOR lime]%s[/COLOR]" % (potential,str(len(playables)))
        #time.sleep(0.5)
        progress = (len(urls) - threading.active_count()) / float(len(urls)) * 100
        dp.update (int(progress), msg + "\n"+"Searching for active links")
        if threading.active_count() < 5:
            #time.sleep(1)
            dp.update (100, msg + "\n"+"Complete")
            break
    #else:
    dp.close()

    if playables:
        for url,title in playables:
            addDir(title, url.replace('////','//'), 2, icon, fanart, url.replace('////','//'), extra='', isFolder= False)
    else: 
        addDir('[B]No Links Available, Check Closer To Start Time[/B]','url',2,icon,fanart,name,extra='', isFolder= False)
    #dp.close()
