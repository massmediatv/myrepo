from resources.utils.plugintools import*
import requests

ignore = ['france', ' fr', 'croatia', 'bulgaria', 'germany', 'canal', ' de ', 'portugal', 'turkey', 'romania', 'italy', ' br', ' sur', 'israel', 'poland', 
    'serbia', ' espa', ' es ', 'spain', 'arabia', 'brazil', 'dutch', ' nl', 'argentina', 'russia', 'ukraine', ' prima', 'movistar', 
    'deportes', 'maximo', 'columbia', 'arena sport', 'uruguay', 'weather', 'willow ']
    
    
def daddy_events():
   # try:
        leagues =[]
        url = 'https://dlhd.so/schedule/schedule-generated.json'
        table3 = requests.get(url).json()
        date_key = list(table3.keys())[0]
        events = table3[date_key].keys()
        for item in events:
            addDir(item,'',18,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), item,extra='', isFolder= True)
        #for item in events:
    
def daddy_league(type):
   # try:
        leagues =[]
        url = 'https://dlhd.so/schedule/schedule-generated.json'
        table3 = requests.get(url).json()
        date_key = list(table3.keys())[0]
        events = table3[date_key][type]
        for item in events:
            event = item['event'].split(' : ')[0]
            if not event in leagues:
                leagues.append(event)
                addDir(event.replace('&amp;', '&'),'',14,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), json.dumps(events),extra='', isFolder= True)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
                
        
        
    #except:
        #pass
        
        
def daddy_sched(league, type):
    #try:
        type = json.loads(type)
        for item in type:
            
            event = item['event'].replace('&amp;', '&')
            if league in event:
                event_time = item['time']
                found = item['channels']
                
            #dialog.textviewer('dad',str(item))   
            


                
                titles = event.split(':')
                name = event_time+' : '+titles[0]
                try:name = event_time+' :'+titles[1]
                except:pass
                try: name = event_time+ ' : '+ titles[2]
                except:pass
                name = name.replace('&amp;', '&')
                if len(found) > 1:
                    addDir(name,json.dumps(found),23,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)
                else:
                	addDir(name,json.dumps(found),23,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)


    #except:
    	#return [[],[]]            
    
    
def daddy():
    try:
        daddylive = 'https://dlhd.so/'
        ukenturl = 'https://magnetic.website/jet/TVGUIDE/TVGUIDE_UK Entertainment.json'
        ukent = requests.get(ukenturl).json()
        ukentdata = ukent['items']
        url = 'https://dlhd.so/24-7-channels.php'
        content = getContent(url)
        content = six.ensure_str(content)
 
        xmlLists = set(re.findall('<div class="grid-item"><a href="(.*?)".*?<strong>(.*?)</strong></span></a></div>',content, re.MULTILINE | re.DOTALL))
        if len(xmlLists) > 0:

            englist = [(add, item) for add, item in xmlLists if not any(x in item.lower() for x in ignore)]
            for address, item in englist:
            #if not any(x in item.lower() for x in ignore):
                address = daddylive+address
                addDir(item,address,2,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
        for item in ukentdata:
            try:
                chan_name = item['title'].split('red]')[1].split('[/')[0]
                address = item['link'][0].split('search_json/')[1].split('?query')[0]
                addDir(chan_name,address,28,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
            except:
                pass


        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
    except Exception as e:
        return

def ukentlinks(name, url):
    links= []
    num = 0
    items = []
    ukent = requests.get(url).json()
    ukentdata = ukent['items']

    for item in ukentdata:
        try:
            link = item['sportjetextractors']
        except:
            link = item['link']
        num = item['title']
        if isinstance(link, list):
            for addres in link:
                if not "berliniptv" in addres.lower():
                    links.append(addres)
                    items.append(str(num))
        else:
            if not "berliniptv" in link.lower():
                links.append(link)
                items.append(str(num))

    if len(links) == 1:
        url = "RunPlugin(plugin://plugin.video.jetproxy/play/%s)" % links[0].replace('jetproxy://','')
        xbmc.executebuiltin(url)
    elif len(links) > 1:
        context = dialog.contextmenu(list=items)
        if context < 0:
            return
        else:
            url = "RunPlugin(plugin://plugin.video.jetproxy/play/%s)" % links[context].replace('jetproxy://','')
            xbmc.executebuiltin(url)
        
        
def daddylinks(name, url):
    list_urls = json.loads(url)
    if len(list_urls) > 1:
        for item in list_urls:
            title = item['channel_name']
            urls = item['channel_id']
        
            address = 'https://dlhd.so/stream/stream-'+urls+'.php'
            addDir(title,address,2,xbmcaddon.Addon().getAddonInfo("icon"),xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= False)
    else:
        title = list_urls[0]['channel_name']
        urls = list_urls[0]['channel_id']
        address = 'https://dlhd.so/stream/stream-'+urls+'.php'
        playUrl(title+' : '+name, address)