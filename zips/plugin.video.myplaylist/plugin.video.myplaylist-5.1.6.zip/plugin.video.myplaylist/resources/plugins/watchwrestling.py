from resources.utils.plugintools import*
from resources.utils.dom_parse import*
import requests

if six.PY3:
    basestring = str
    unicode = str
    xrange = range

def fightmma(url, page):
    try:
        if '/page/' in url:
            url = re.sub('/page/\\d+','/page/%d'%int(page),url)
        else:
            url = url + '/page/%d' %int(page)

        content = getContent(url)
        content = six.ensure_str(content)
 
        xmlLists = parseDOM(content,'div', attrs={'class':"video-section"})[0] #re.findall('<h3 class="post-title"><a href="(.*?)">(.*?)</a></h3>',content, re.MULTILINE | re.DOTALL)
        article = parseDOM(xmlLists,'article')
        for art in article:
            title = parseDOM((parseDOM(art,'h3')[0]),'a')[0].replace('&#8211;','-')
            title = re.sub('^watch','',title, 0, re.IGNORECASE)
            href = parseDOM(art,'a', ret="href")[0]
            dt = parseDOM(art,'span', attrs={'class':"date"})[0]
            img = parseDOM(art,'img', ret="src")[0]


            addDir(title,href,22,img,xbmcaddon.Addon().getAddonInfo("fanart"), '',extra='', isFolder= True)
        ntpage = re.findall('"([^"]+)"\>Next',xmlLists,re.DOTALL)
        if ntpage:

            nextpage = unicode(int(page)+1)
            addDir('>> next page >>', url , 10,'','','', extra='', page=nextpage, isFolder=True)

    except Exception as e:
        #dialog.ok('test', str(e))
        pass
        
        
def ListLinks2(name,url,icon):
    zz=''
    html=getContent(url)
    html = six.ensure_str(html)
    html = html.replace("\'",'"')
    videos = parseDOM(html,'div', attrs={'class':"post-entry"})
    ab = len(name)
    
    iksy = ''
    for x in xrange(ab-5):
        iksy+='#'
    if videos:
        #add_item('empty', '[B][COLOR gold]'+iksy+'[/COLOR][/B]', rys, "empty",fanart=FANART, folder=False, IsPlayable=False, infoLabels={'plot':nazwa})
        #add_item('empty', '[B][COLOR gold]'+nazwa + ' [/COLOR][/B]', rys, "empty",fanart=FANART, folder=False, IsPlayable=False, infoLabels={'plot':nazwa})
        #add_item('empty', '[B][COLOR gold]'+iksy+'[/COLOR][/B]', rys, "empty",fanart=FANART, folder=False, IsPlayable=False, infoLabels={'plot':nazwa})
        videos = videos[0]
        srcs = parseDOM(videos,'p', attrs={'style':"text\-align.*?"})
        com =''

        for src in srcs:

            if 'ommentary' in src:
                try:
                    src = src.replace('<strong>','').replace('</strong>','')
                    com = re.findall('>([^<]+)<\/span>',src)[0]
                except:

                    com=''
            if 'bk-button-wrappe' in src:
                try:
                    host = re.findall('strong>([^<]+)',src)[0]
                except:
                    host = re.findall('small">([^<]+)',src)[0] #small>Dropapk<

                if 'download links' in host.lower():
                    continue
                if 'waav' in host.lower() or 'netu' in host.lower():
                    continue
                hreftitle = re.findall('href="([^"]+)".*?>([^<]+)',src)
                for href,title in hreftitle:
                    href = href.replace('&amp;','&')
                    if 'waav' in title.lower() or 'netu' in title.lower():
                        continue

                    tit = '[B][COLOR khaki]'+title + '[/B][/COLOR][I]      (' +host+')[/I]'
                    addDir(tit, href+'|'+url,2, icon,'','',extra='', isFolder= False)
                    #add_item(href+'|'+url, tit, rys, "playlink",fanart=FANART, folder=False, IsPlayable=True, infoLabels={'plot':title, 'code':com})





