import utils
import backup
import main
from variables import*

###############################################################################
#						                                                  FRESH INSTALL
###############################################################################

def freshStart(install=None):
	currentSkin = addon.setSetting('lastSkin', xbmc.getSkinDir())
	skinset = True
	checkSkin = utils.getOld('lookandfeel.skin')
	skin = 'skin.estuary'
	if not checkSkin == skin:
		skinset = utils.swapSkins(skin)	
		#time.sleep(3)
		
	if install: yes_pressed = True

	else: yes_pressed=dialog.yesno(addonTitle,"Do you wish to restore your configuration to default settings?", "")
	
	if yes_pressed and skinset:

		try:
			if os.path.exists(favourites):
				shutil.copy(favourites, backupPath)
		except:
			pass     

		xbmcPath = transPath(os.path.join('special://home'))
		try:
			stopidle()
		except:
		    pass
		dialogProgress.create(addonTitle,"Clearing all files and folders:")
		total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)])
		del_file = 0

		try:
			for root, dirs, files in os.walk(xbmcPath,topdown=True):
				fold = root.replace('/', '\\').split('\\')
				dirs[:] = [d for d in dirs if d not in ignorefresh]
				files[:] = [file for file in files if file not in ignorefresh]		
				for name in files:
					del_file += 1
					delete = True
					dialogProgress.update(int(utils.percentage(del_file, total_files)), 'File: [COLOR ffff7e14]%s[/COLOR]' % name)
					try:
						folder = fold.index('addon_data')+1    
						#dialog.ok(addonTitle, str(fold[folder]))
						if 'addon_data' in fold and fold[folder] in ignoresettings:
							delete = False
					except Exception as e:
						#dialog.ok(addonTitle, str(fold[-2]))
						pass
					
					if delete == True:
						#dialog.ok(addonTitle, str(fold[-1]))
						try: os.remove(os.path.join(root,name))
						except: pass

			for root, dirs, files in os.walk(xbmcPath,topdown=True):
				fold = root.replace('/', '\\').split('\\')
				dirs[:] = [d for d in dirs if d not in ignorefresh]
				

				for name in dirs:
					delete = True
					dialogProgress.update(100, 'Cleaning Up Empty Folder: [COLOR ffff7e14]%s[/COLOR]' % name)

					try:
						if 'addon_data' in fold:
							#dialog.ok(addonTitle, str(name))
							#folder = fold.index('addon_data')+1
							if name in ignoresettings:
								delete = False
							else:
								for plug in ignoresettings:
									if plug in fold:
										delete = False
					except Exception as e:
						#dialog.ok(addonTitle, str(e))
						pass
						
					if name not in ["Database","userdata","temp","addons","addon_data"]:
						if delete == True:
							shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)


			addon.setSetting('buildname', '')
			addon.setSetting('skin', '')
			#dialogProgress.close()

		except Exception as e:
			dialogProgress.close()
			dialog.ok(addonTitle, str(e))


		#dialogProgress.close()

		if install:
			main.buildWizard(install)
		else:
			dialogProgress.close()
			dialog.ok(addonTitle, "The process is complete, you're now back to a fresh Kodi configuration\nPlease press ok to restart Kodi in order for the changes to be applied.")
			killxbmc()

	else: utils.notify(addonTitle,'Fresh Install: [COLOR ffff7e14]Cancelled![/COLOR]'); xbmc.executebuiltin('Container.Refresh')

#############################
####KILL XBMC ###############
#####THANKS GUYS @ TI########


def killxbmc():

	if xbmc.getCondVisibility('system.platform.android'):

		try: os._exit(1)
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass     
		try: os.system('adb shell am force-stop com.semperpax.spmc16')
		except: pass
		try: os.system('adb shell am force-stop com.spmc16')
		except: pass            
		try: os.system('adb shell am force-stop com.semperpax.spmc')
		except: pass
		try: os.system('adb shell am force-stop com.spmc')
		except: pass    
		try: os.system('adb shell am force-stop uk.droidbox.dbmc')
		except: pass
		try: os.system('adb shell am force-stop uk.dbmc')
		except: pass   
		try: os.system('adb shell am force-stop com.perfectzoneproductions.jesusboxmedia')
		except: pass
		try: os.system('adb shell am force-stop com.jesusboxmedia')
		except: pass 		

		xbmc.executebuiltin("ActivateWindow(busydialog)")


		if 'com.robbzkiill3r.iint3liig3ncii' not in killerAPK():
			xbmc.executebuiltin( "Dialog.Close(busydialog)" )
			dialog.ok(addonTitle, "An additional app is needed to force close kodi automatically. Press ok to start download")

			lib=os.path.join(packagesdir, 'killer.apk') 
			dialogProgress.create(addonTitle,'Downloading Force close app.... Please Wait')
			try: os.remove(lib)
			except: pass
			utils.download(restartUrl, lib, dialogProgress)
			xbmc.sleep(500)
			xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
			time.sleep(5)
			dialog.ok(addonTitle,"Install is complete please press ok to restart kodi")
			xbmc.executebuiltin("ActivateWindow(busydialog)")


		os.system('am start --user 0 -a android.intent.action.MAIN -c android.intent.category.HOME')
		killerPATH = home.split("/")
		GOT = False
		if 188==188:
			i = 0
			for killerDIR in killerPATH:
				if killerDIR.count('.') >= 2:
					GOT = True
					break
				else:
					i+=1
			if GOT == True:
				WHAT = killerPATH[i]

		if "org.xbmc.kodi" in WHAT:
			os.system('am start --user 0 -n com.robbzkiill3r.iint3liig3ncii/.iiNT3LiiStopGoKodii &')

		else:
			os.system('am start --user 0 -n com.robbzkiill3r.iint3liig3ncii/.iiNT3LiiStopGoSPMC &')


	elif xbmc.getCondVisibility('system.platform.linux'):
	
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you're seeing this message it means the force close was unsuccessful. Please force close Kodi. DO NOT exit cleanly via the menu.")
		
	elif xbmc.getCondVisibility('system.platform.osx'):
	
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		
		dialog.ok("[COLOR red][B]WARNING  !!![/COLOR][/B]", "If you're seeing this message it means the force close was unsuccessful. Please force close Kodi. DO NOT exit cleanly via the menu.")
	
	
	elif xbmc.getCondVisibility('system.platform.windows'):
	
		try:
		    os.system('@ECHO off')
		    os.system('tskill XBMC.exe')
		except: pass
		try:
		    os.system('@ECHO off')
		    os.system('tskill Kodi.exe')
		except: pass
		try:
		    os.system('@ECHO off')
		    os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
		    os.system('@ECHO off')
		    os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		
		try: 
		    os._exit(1)
		except: pass
		try:
		    sys.exit()
		except: pass
		
		dialog.ok("[COLOR red][B]WARNING  !!![/COLOR][/B]", "If you're seeing this message it means the force close was unsuccessful. Please force close Kodi DO NOT exit cleanly via the menu. Use task manager and NOT ALT F4")
	
	else:
		# IOS
		try: os.system('killall AppleTV')
		except: pass
		
		#OSMC / RASPBMC
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you're seeing this message it means the force close was unsuccessful. Please force close Kodi DO NOT exit via the menu. iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")

def killerAPK():
    if xbmc.getCondVisibility('system.platform.android'):
        import subprocess
        InstalledAPK = subprocess.Popen(['exec ''/system/bin/pm list packages -3'''], executable='/system/bin/sh', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).communicate()[0].rstrip('\n').splitlines()
        for i in range(len(InstalledAPK)):
            InstalledAPK[i] = InstalledAPK[i].partition(':')[2]
        return InstalledAPK
	