from variables import*



def log(msg, level=xbmc.LOGDEBUG):
    if kodiDebug == False and level != xbmc.LOGERROR: return
    if level == xbmc.LOGERROR: msg += ' ,' + traceback.format_exc()
    xbmc.log(addon_ID + '-' + addonVer + '-' + (msg.encode("utf-8")), level)




class Installer(object):
    def __init__(self, update=None):
        #self.cache    = SimpleCache()
        #if not self.chkVersion(): return
        if update == True:
            self.lastURL  = droidUrl%('releases'.lower().replace('//','/'),devicePlatform) 

            self.lastPath = addon.getSetting("LastPath")
            self.selectDialog2(self.lastURL, True)
        else:
            self.lastURL  = self.buildMain()

            self.lastPath = addon.getSetting("LastPath")
            self.selectDialog(self.lastURL, True)
        
        
    def chkVersion(self):
        try: 
            build = int(re.compile('Android (\d+)').findall(droidVersion)[0])
        except: build = minDroid
        if build >= minDroid: return True
        else: return False
        

    def openURL(self, url):
        if url is None: return
        log('openURL, url = ' + str(url))
        try:
            #cacheResponce = self.cache.get(addonTitle + '.openURL, url = %s'%url)
            #if not cacheResponce:
            #request = urllib2.Request(url)
            #responce = urllib2.urlopen(request, timeout = kodiTimeout).read()
            responce = requests.get(url).content
                #self.cache.set(addonTitle + '.openURL, url = %s'%url, responce, expiration=timedelta(minutes=5))
            return BeautifulSoup(responce, "html.parser")
        except Exception as e:
            log("openURL Failed! " + str(e), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(addonTitle, strings(30001), icon, 4000)
            return None

            
    def getItems(self, soup):
        try: #folders
            items = (soup.find_all('tr'))
            del items[0]
        except: #files
            items = (soup.find_all('a'))
        return [x.get_text() for x in items if x.get_text() is not None]

        
    def buildMain(self):
        tmpLST = []
        for idx, item in enumerate(droidOptions): 
            liz = xbmcgui.ListItem(item.title(),labelStrings[idx])
            liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
            tmpLST.append(liz)
        select = xbmcgui.Dialog().select(addonTitle, tmpLST, preselect=-1, useDetails=True)
        if select < 0: return #return on cancel.
        return  droidUrl%(droidOptions[select].lower().replace('//','/'),devicePlatform)
            
            
    def buildItems(self, url):
        soup = self.openURL(url)
        if soup is None: return
        for item in self.getItems(soup):
            try: #folders
                
                label, label2 = re.compile("(.*?)/-(.*)").match(item).groups()
                
                if label == devicePlatform: label2 = strings(30014)%devicePlatform
                else: label2 = '' #Don't use time-stamp for folders
                liz = xbmcgui.ListItem(label.strip(),label2.strip())
                liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                yield liz
            except: #files
                
                label, label2 = re.compile("(.*?)\s(.*)").match(item).groups()
                if '.apk' in label: 
                    try:
                        label = label.split('.apk')[0]
                        label = label+'.apk'
                    except:
                        pass
                    try:label2 = label2.split('-', 1)[1]
                    except: pass
                    liz = xbmcgui.ListItem(label.strip(),label2.strip())
                    liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                    yield liz

    def buildItems2(self, url):
        soup = self.openURL(url)
        
        #if soup is None: return
        for item in self.getItems(soup):
            #xbmcgui.Dialog().ok('file', str(item))
            label, label2 = re.compile("(.*?)\s(.*)").match(item).groups()
            try:label2 = label2.split('-', 1)[1]
            except: pass
            #except: pass
            try:
                version = label.split('-')[1].split('-')[0]
                if version == str(currentKodi):
                    label2 = '[COLOR ffff7e14]Currently Installed[/COLOR] - '+label2
            except:
                pass
        
            if '.apk' in label:
                label = label.split('.apk')[0]
                label = label+'.apk'
                
                if addon.getSetting('release_type') == '1':
                    if 'rc' in label:
                        liz = xbmcgui.ListItem(label.strip(),label2.strip())
                        liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                        yield liz
	
                elif addon.getSetting('release_type') == '2':
                    if 'beta' in label:
                        liz = xbmcgui.ListItem(label.strip(),label2.strip())
                        liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                        yield liz

                elif addon.getSetting('release_type') == '0':
                    if not 'beta' in label:
                        if not 'rc' in label:
                            liz = xbmcgui.ListItem(label.strip(),label2.strip())
                            liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                            yield liz

                elif addon.getSetting('release_type') == '3':
                    liz = xbmcgui.ListItem(label.strip(),label2.strip())
                    liz.setArt({'icon':images+'kodi.png','thumb':images+'kodi.png'})
                    yield liz

				


    def setLastPath(self, url, path):
        addon.setSetting("LastURL",url)
        addon.setSetting("LastPath",path)
        
        
    def selectDialog(self, url, bypass=False):
        log('selectDialog, url = ' + str(url))
        newURL = url
        while not xbmc.Monitor().abortRequested():
            items  = list(self.buildItems(url))
            if len(items) == 0: break           
            else:
                label  = url.replace(kodiUrl,'./').replace('//','/')
                select = xbmcgui.Dialog().select(label, items, preselect=-1, useDetails=True)
                if select < 0: import main; main.Downloads(); break#return on cancel.
                label  = items[select].getLabel()
                newURL = url + items[select].getLabel()
                preURL = url.rsplit('/', 2)[0] + '/'
            
                if newURL.endswith('.apk') and select >= 0: 
                    dest = transPath(os.path.join(addonData,label))
                    self.setLastPath(url,dest)
                    return self.downloadAPK(newURL,dest)
                elif label.startswith('Parent directory') and "android" in preURL:
                    return self.selectDialog(preURL, True)
                elif label.startswith('Parent directory') and "android" not in preURL:
                    return self.selectDialog(self.buildMain(), False)
                url = newURL + '/'


    def selectDialog2(self, url, bypass=False):
        log('selectDialog, url = ' + str(url))
        newURL = url
        while not xbmc.Monitor().abortRequested():
            items  = list(self.buildItems2(url))
            if len(items) > 100000: break
            else:
                label  = url.replace(kodiUrl,'./').replace('//','/')
                select = xbmcgui.Dialog().select(label, items, useDetails=True)
                if select < 0: #return on cancel.
	                 import main
	                 main.Downloads()
	                 break
                else:
                    label  = items[select].getLabel()
                    newURL = url + items[select].getLabel()
                    preURL = url.rsplit('/', 2)[0] + '/'
            
                    if newURL.endswith('.apk'): 
                        dest = transPath(os.path.join(addonData,label))
                        self.setLastPath(url,dest)
                        return self.downloadAPK(newURL,dest)
                

    def fileExists(self, dest):
        if os.path.exists(dest):
            if not xbmcgui.Dialog().yesno(addonTitle, strings(30004)+'\n'+dest.rsplit('/', 1)[-1], nolabel=strings(30005), yeslabel=strings(30006)): return True
        elif kodiMaint and xbmcvfs.exists(self.lastPath): self.deleteEXE(self.lastPath); return False

        
        
    def deleteEXE(self, path):
        count = 0
        #some file systems don't release the file lock instantly.
        while not xbmc.Monitor().abortRequested() and count < 3:
            count += 1
            if xbmc.Monitor().waitForAbort(1): return 
            try: 
                if xbmcvfs.delete(path): return
            except: pass
    
        
    def downloadAPK(self, url, dest):
        if self.fileExists(dest) == True: 
            return self.installAPK(dest)
        else:
            dialogProgress.create(addonTitle, 'Downloading Kodi Application')
            dialogProgress.update(0)
			
            try:
                utils.download(url, dest, dialogProgress)
            except Exception as e:
                dialogProgress.close()
                xbmcgui.Dialog().notification(addonTitle, strings(30001), icon, 4000)
                log("downloadAPK, Failed! (%s) %s"%(url,str(e)), xbmc.LOGERROR)
                return self.deleteEXE(dest)
            return self.installAPK(dest)
            
            
    def installAPK(self, apkfile):
        xbmc.executebuiltin('XBMC.AlarmClock(shutdowntimer,XBMC.Quit(),0.5,true)')
        xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+apkfile+'")')



