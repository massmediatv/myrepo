import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob

if xbmc.getCondVisibility("System.Platform.Android") and sys.version_info[0] < 3:
    from resources import zipfile
else:
    import zipfile
	
import shutil
try:import urllib.request as urllib2
except: import urllib2
import urllib
import re
import time
import datetime
import utils
import traceback
import socket
import platform
import requests

from bs4 import BeautifulSoup

from datetime import date, datetime, timedelta
from sqlite3 import dbapi2 as database
try:
	import json as simplejson 
except:
	import simplejson


PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

###############################################################################
#						                                                  XBMC ARGUMENTS
###############################################################################

dialog = xbmcgui.Dialog()
dialogProgress  = xbmcgui.DialogProgress()
currentKodi = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
baseKodi = float(xbmc.getInfoLabel("System.BuildVersion")[:3])
setSkin  = xbmc.getSkinDir()
space = '[COLOR blue][B]-------------------------------------------------[/B][/COLOR]'
kodiTimeout   = 15
minDroid   = 5 #Minimum Android Version Compatible with Kodi
try: transPath = xbmc.translatePath
except: transPath = xbmcvfs.translatePath

###############################################################################
#						                                                  GLOBAL PATHS
###############################################################################

addon_ID       = 'plugin.video.kodiwiz'
addonTitle     = 'Karls Wizard'
addon          = xbmcaddon.Addon(addon_ID)
addonversion = addon.getAddonInfo('version')
home           = transPath('special://home/')
profile       = transPath('special://profile/')
addons       = os.path.join(home, 'addons')
userData       = os.path.join(home, 'userdata')
tempDir = os.path.join(home,'tempDir')
addonHome = transPath(addon.getAddonInfo('path'))
addonData      = transPath('special://home/userdata/addon_data/plugin.video.kodiwiz')
addonVer = addon.getAddonInfo('version')
strings      = addon.getLocalizedString
databasePath = transPath('special://userdata/Database')
addons27 = os.path.join(databasePath, 'Addons27.db')
addons33 = os.path.join(databasePath, 'Addons33.db')
packagesdir    =  transPath(os.path.join('special://home/addons/packages',''))
thumbnails    =  transPath('special://home/userdata/Thumbnails')
cachePath = os.path.join(home, 'cache')
tempPath = transPath('special://temp')
textures  = transPath('special://home/userdata/Database/Textures13.db')
kodilog = transPath('special://logpath/kodi.log')
kodiold = transPath('special://logpath/kodi.old.log')
favourites         =  transPath(os.path.join(userData,'favourites.xml'))
backedupFavourites       = os.path.join(addonData, 'favourites.xml')
firstrun = 'ivue admin'
fanart = os.path.join(addonHome, 'fanart.jpg')
icon   = os.path.join(addonHome, 'icon.png')
images = transPath(os.path.join(addonHome + '/resources/art/'))
DefaultNoteImage= images+'ContentPanel.png'
focus = images+'focus.png'
nofocus	= images+'nofocus.png'


###############################################################################
#						                                                  GLOBAL URLS
###############################################################################


latestKodi = 'http://ivuetvguide.com/kls/repo/files/apptest1.txt'
buildFile  = 'http://ivuetvguide.com/kls/repo/files/builds4.txt'
restartUrl= 'https://www.dropbox.com/s/hs54pie2djgz5jg/com.robbzkiill3r.iint3liig3ncii.apk?dl=1'
kodiUrl  = 'http://mirrors.kodi.tv/'
droidUrl = kodiUrl + '%s/android/%s/'

###############################################################################
#						                                                  GLOBAL SETTINGS
###############################################################################

installed = addon.getSetting('installed')
extractOk = addon.getSetting('extract')
extractError  = addon.getSetting('errors')
buildName = addon.getSetting('buildname')
buildVersion  = addon.getSetting('buildversion')
keepFavs = addon.getSetting('keepfavourites')
installedSkin = addon.getSetting('current.skin')
lastSkin = addon.getSetting('lastSkin')
latestBuild  = addon.getSetting('latestversion')
backupPath  =  transPath(addon.getAddonInfo('profile'))
startupMaint = addon.getSetting('clearcache')
enableAddon = addon.getSetting('enableaddon')
filesize = int(addon.getSetting('filesize_alert'))
filesize_thumb = int(addon.getSetting('filesizethumb_alert'))
show = addon.getSetting('show')
kodiDebug     = addon.getSetting('Enable_Debugging') == 'true'
kodiMaint     = addon.getSetting('Disable_Maintenance') == 'false'
droidVersion   = addon.getSetting("Version")
deviceLabel = (addon.getSetting("Platform") or None)
kodiCache         = addon.getSetting('Disable_Cache') == 'false'

if str(currentKodi) >= '21':
    MATCHED = '21'

elif str(currentKodi) >= '20':
    if buildName == 'Karls Matrix Setup':
        buildName = 'Karls Setup'
    MATCHED = '20'

elif str(currentKodi) >= '19':
    if buildName == 'Karls Matrix Setup':
        buildName = 'Karls Setup'
    MATCHED = '19'
elif str(currentKodi) >= '18':
    #MATCHED = 'Karls Leia Setup'
    MATCHED = '18'
    
elif str(currentKodi) < '18':
    #MATCHED = 'Karls Krypton Setup'
    MATCHED = '17'


    


droidOptions = ['nightlies','releases','snapshots','test-builds']
labelStrings = [strings(30017),strings(30016),strings(30015),strings(30018)]


if deviceLabel is None: devicePlatform = ""
elif '64' in deviceLabel: devicePlatform = "arm64-v8a"
elif '86' in deviceLabel: devicePlatform = "x86"
else: devicePlatform = "arm"

ignoreFiles = [addon_ID]
backupheader = "Checking and Preparing Files"
backupinfo1 = "Archiving..."
backupinfo2 = ""
backupinfo3 = "Please Wait"
backupignoreDirs =  [addon_ID, 'cache', 'system', 'temp', 'Thumbnails', '__pycache__', 'pvr.iptvsimple', 'pvr.iptvsimple2', 'inputstream.ffmpegdirect', 'inputstream.adaptive', 'inputstream.rtmp']
backupignoreFiles = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log","Textures13.db", "Epg13.db", "TV38.db", "data.db"]
ignoresettings = ['plugin.video.genesis', 'plugin.video.flashiptv', 'plugin.video.gmgm', 'plugin.video.teamexpatiptv', 'script.ivueguide', 'plugin.video.intervue', 'plugin.video.IVUEcreator', 'plugin.video.xmlplaylist','plugin.video.themoviedb.helper']
ignorefresh = [addon_ID, 'script.module.soupsieve', 'xbmc.log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'repository.k86', 'script.module.beautifulsoup4', 'script.module.requests', 'script.module.urllib3', 'script.module.certifi', 'script.module.chardet', 'script.module.idna', 'plugin.video.kodiWizard', 'guisettings.xml', 'service.xbmc.versioncheck', 'script.module.simplecache', 'Database', 'bookmarks.db', 'xbmc.repo.ivueguide', 'inputstream.ffmpegdirect', 'inputstream.adaptive', 'inputstream.rtmp']

def startidle():
    if str(currentKodi) >= '18':
        return xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    else:
        return xbmc.executebuiltin('ActivateWindow(busydialog)')
def stopidle():
    if str(currentKodi) >= '18':
        return xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    else:
        return xbmc.executebuiltin('Dialog.Close(busydialog)')
