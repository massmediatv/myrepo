# -*- coding: utf-8 -*-
import utils
import maintenance
from variables import*

buildLabel = "installedBuild,%s" % buildName
xbmc.executebuiltin('Skin.SetString(%s)' % buildLabel)
versionLabel = "installedVersion,%s" % buildVersion
xbmc.executebuiltin('Skin.SetString(%s)' % versionLabel)
checkSkin = utils.getOld('lookandfeel.skin')



if not backupPath == addonData:
    addon.setSetting('backup', addonData)


def log(msg, level=xbmc.LOGDEBUG):
    pass

class Service(object):
    def __init__(self):
        try:
            self.getBuild()
            self.getVersion()
            self.lastPath = addon.getSetting("LastPath")
            
        except Exception as e: 
            log("Service Failed! " + str(e), xbmc.LOGERROR)
        #checkbuild()
        
    def getBuild(self): 
        count = 0
        build = ''
        try:
            while not xbmc.Monitor().abortRequested() and count < 3:
                count += 1
                build = platform.machine()
                if len(str(build)) > 0: return addon.setSetting("Platform",str(build))
        except Exception as e: log("getBuild Failed! " + str(e), xbmc.LOGERROR)
              
              
    def getVersion(self):
        count = 0
        build = ''
        try:
            while not xbmc.Monitor().abortRequested() and count < 3:
                count += 1 
                build = xbmc.getInfoLabel('System.OSVersionInfo')
                if build.lower() != 'busy': return addon.setSetting("Version",str(build))
                if xbmc.Monitor().waitForAbort(1): return
        except Exception as e: log("getVersion Failed! " + str(e), xbmc.LOGERROR)

def checkbuild():
	tellUser = False

	if buildName == '':
		header = "[B][COLOR lime]KARL'S WIZARD[/COLOR][/B]\n\n[COLOR orange] Karls build is not installed from the wizard.[/COLOR]\n\nPress download\n\nThen press download and install when asked"
		mynews = '[COLOR orange]Any questions just ask[/COLOR]'
		mynews = header
		if show == 'true':
		  TempWindow=utils.startup(download='true', noteType='t',noteMessage=mynews,noteImage=''); 
		  TempWindow.doModal(); 
		  del TempWindow
		else:
		  if startupMaint == 'true': maintenance.clearCache(startup=True)

	else:

		version = buildVersion
		update = '[COLOR lime]Latest Version Installed[/COLOR]'
		#kodiUpdate = update
		kodiVersion = str(currentKodi)
		matchKodi = kodiVersion

		link           = utils.openURL(buildFile).replace('\n','').replace('\r','').replace('\t','')
		match          = re.compile('kodi="%s"name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?kin="(.+?)"' % (MATCHED, buildName)).findall(link)

		if len(match) > 0:
		  version = match[0][0]
		  #dialog.ok('wiz', str(version))
		  addon.setSetting('latestversion', version)

		if version > buildVersion:
		  update = '[COLOR red]Update Available Click Download[/COLOR]'
		  tellUser = True


		#if xbmc.getCondVisibility("System.Platform.Android"):
		  #matchKodi          = utils.checkApk('Kodi', 'version')

		  #if matchKodi > str(currentKodi):
		      #kodiUpdate = '[COLOR red]Update Available Click Download[/COLOR]'
		      #tellUser = True

		header = "[B][COLOR deepskyblue]KARL'S WIZARD[/COLOR][/B]\n\nKodi Version = %s\n\n[COLOR ffffffff]Your current setup is:[/COLOR] [COLOR lime]%s[/COLOR]\n\n" % (str(currentKodi),buildName)

		mynews = "Current Setup Version = %s: %s" % ( buildVersion, update)

		mynews = header + mynews
		TempWindow=utils.startup(noteType='t',noteMessage=mynews,noteImage='')

		if version > buildVersion:
		    TempWindow=utils.startup(download='true', noteType='t',noteMessage=mynews,noteImage='')

		if show == 'true':
		    if tellUser:		
		        TempWindow.doModal() 
		        del TempWindow
		    else:
		        if startupMaint == 'true': 
		            maintenance.clearCache(startup=True)
		else:
		    if startupMaint == 'true':
		        maintenance.clearCache(startup=True)

def checkInstall(skin):
    query = '{"jsonrpc":"2.0", "method":"Addons.GetAddonDetails","params":{"addonid":"%s","properties": ["enabled"]}, "id":1}' % (skin)
    r = xbmc.executeJSONRPC(query)

    data = simplejson.loads(r)
    if not "error" in data.keys(): 
        if data["result"]["addon"]["enabled"] == True: 
            return True 
        else:
            return False
    else:
        return False


#if installedSkin == '':
    #if not checkSkin == 'skin.estuary':
        #utils.swapSkins('skin.estuary')
        #time.sleep(2)

if not installedSkin == '':
    if not checkSkin == installedSkin and checkInstall(installedSkin) == True:
        utils.swapSkins(installedSkin)
        time.sleep(2)
    elif checkSkin == installedSkin and checkInstall(installedSkin) == False:
        if not checkSkin == 'skin.estuary':
            utils.swapSkins('skin.estuary')
            time.sleep(2)

if enableAddon =='true':
    utils.enable17()
checkbuild()






  


