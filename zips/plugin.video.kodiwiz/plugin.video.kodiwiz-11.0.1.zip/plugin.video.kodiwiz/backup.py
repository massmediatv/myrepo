 # -*- coding: utf-8 -*-
import utils
from variables import*


###############################################################################
#                                                                        FULL BACK UP AND SPECIAL CONVERT
###############################################################################

def BackUp(folder, title, silent=None):

    if backupPath == '':
        dialog.ok(addonTitle, 'No path set for backup location. Please set path in settings and try again')
        addon.openSettings()
    else:
        #if compression == 'zip':
        backup_zip = transPath(os.path.join(backupPath,title+'.zip'))
        #elif compression == 'tar':
            #backup_zip = transPath(os.path.join(backupPath,title+'.tar.gz'))

        if  title == 'setup':
            utils.ConvertPaths(home)
        ArchiveTree(folder, backup_zip, title, backupheader, backupinfo1, backupinfo2, backupinfo3, backupignoreDirs, backupignoreFiles)
        time.sleep(1)

        if silent:
            pass
        else:
            dialog.ok(addonTitle, '%s Backup was [COLOR fffea800][B]SUCCESSFUL[/B][/COLOR]!'% title)


###############################################################################
#                                                                        ARCHIVE TREE
###############################################################################

def ArchiveTree(sourcefile, destfile, name, backupheader, backupinfo1, backupinfo2, backupinfo3, backupignoreDirs, backupignoreFiles):
    #if compression == 'zip':
    backupZip = zipfile.ZipFile(destfile , 'w', zipfile.ZIP_DEFLATED)
    #elif compression == 'tar':
        #backupZip = tarfile.open(destfile , "w:gz")
    rootlen = len(sourcefile)
    for_progress = []
    item =[]
    dialogProgress.create(backupheader, backupinfo1+'\n'+backupinfo2+'\n'+backupinfo3)

    for base, dirs, files in os.walk(sourcefile):
        for file in files:
            item.append(file)

    itemNumber =len(item)

    for base, dirs, files in os.walk(sourcefile):
        dirs[:] = [d for d in dirs if d not in backupignoreDirs]
        files[:] = [f for f in files if f not in backupignoreFiles]

        for file in files:
            if not file.endswith('pyo'):
	            for_progress.append(file)
	            progress = len(for_progress) / float(itemNumber) * 100
	            dialogProgress.update(int(progress),"Backing Up Files\n[COLOR fffea800]%s[/COLOR]"%file+ "\nPlease Wait")
	            fn = os.path.join(base, file)
	
	            if not 'temp' in dirs:
	                if not addon_ID in dirs:
	                   import time
	                   force= '01/01/1980'
	                   fileDate = time.strftime('%d/%m/%Y', time.gmtime(os.path.getmtime(fn)))
	
	                   if fileDate > force:
	                   	#if compression == 'zip':
	                       backupZip.write(fn, fn[rootlen:])
	                   	#elif compression == 'tar':
	                           #backupZip.add(fn, fn[rootlen:])

    if itemNumber == 0:
    	#if compression == 'zip':
        backupZip.write(sourcefile, name)
    	#elif compression == 'tar':
            #backupZip.add(sourcefile, name)

    backupZip.close()
    dialogProgress.close()

