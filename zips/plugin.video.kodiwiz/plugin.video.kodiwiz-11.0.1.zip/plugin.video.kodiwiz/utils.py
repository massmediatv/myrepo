import main
import maintenance
from variables import*
try: import socket
except: pass
###############################################################################
#						                                                  PERCENTAGE
###############################################################################
	
def percentage(part, whole):
	return 100 * float(part)/float(whole)

###############################################################################
#						                                                       NOTIFY
###############################################################################

def notify(title,message,times=2000,icon=icon):
	dialog.notification(title, message, icon, times, False)
	#xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s, false)' % (title , message , icon, times))


###############################################################################
#						                                          FORCE REPO UPDATES
###############################################################################

def forceUpdate():
	xbmc.executebuiltin('UpdateAddonRepos()')
	notify(addonTitle, 'Checking Addon Updates')


def getFiles():
	items = []
	if not checkUrl(buildFile) == True: return False
	try:link = openURL(buildFile).replace('\n','').replace('\r','').replace('\t','')
	except:link = openURL(buildFile).decode().replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('addon = "(.+?)".+?ink = "(.+?)".+?ocation = "(.+?)"').findall(link)
	for name, url, location in match:
	    items.append(name)
	if len(items) > 0:
	    return items
	else:
	    return False

###############################################################################
#						                                                CHECK BUILD INFO
###############################################################################

def checkBuild(name, ret):
	if not checkUrl(buildFile) == True: return False
	try:link = openURL(buildFile).replace('\n','').replace('\r','').replace('\t','')
	except:link = openURL(buildFile).decode().replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('kodi="%s"name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?kin="(.+?)"' % (MATCHED, name)).findall(link)
	if len(match) > 0:
		for version, url, skin in match:
			if ret   == 'version': return version
			elif ret == 'url':     return url
			elif ret == 'skin':     return skin
			elif ret == 'kodi':     return kod
	else: return False

def getBuilds():
	items = []
	if not checkUrl(buildFile) == True: return False
	try:link = openURL(buildFile).replace('\n','').replace('\r','').replace('\t','')
	except:link = openURL(buildFile).decode().replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('kodi="%s"name="(.*?)"version="(.*?)"url=".*?"skin=".*?"' % MATCHED, re.DOTALL).findall(link)
	for name, version in match:
	    items.append([name,version])
	if len(items) > 0:
	    return items
	else:
	    return False
	
def checkFiles(name, ret):
	if not checkUrl(buildFile) == True: return False
	try:link = openURL(buildFile).replace('\n','').replace('\r','').replace('\t','')
	except:link = openURL(buildFile).decode().replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('addon = "%s".+?ink = "(.+?)".+?ocation = "(.+?)"' % name).findall(link)
	if len(match) > 0:
		for link, location in match:
			if ret   == 'link': return link
			elif ret == 'location':     return location
	else: return False


###############################################################################
#						                                                CHECK APK INFO
###############################################################################

def checkApk(name, ret):
	if not checkUrl(latestKodi) == True: return False
	try:link = openURL(latestKodi).replace('\n','').replace('\r','').replace('\t','')
	except:link = openURL(latestKodi).decode().replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="%s".+?ersion="(.+?)".+?rl="(.+?)"' % name).findall(link)
	if len(match) > 0:
		for version, url in match:
			if   ret == 'version':     return version
			elif ret == 'url':    return url
	else: return ''
###############################################################################
#						                                                      CHECK URL
###############################################################################
 
def checkUrl(url):
	if url == 'http://': return False
	try:
		try:socket.setdefaulttimeout(8)
		except: pass
		req = urllib2.Request(url)
		response = urllib2.urlopen(req)
		response.close()
	except Exception as e:
		return e
	return True

###############################################################################
#						                                                         OPEN URL
###############################################################################
 
def openURL(url,note=None):
	if not checkUrl(url) == True: 
	    if note:
	        notify(addonTitle, 'Website not available'); return ''
	    else: return None
	try:socket.setdefaulttimeout(8)
	except: pass
	#req = urllib2.Request(url)
	#req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	#response = urllib2.urlopen(req)
	link = requests.get(url).text
	#link=response.read()
	#response.close()
	return link


###############################################################################
#						                                                      LOG WINDOW
###############################################################################


def TextBoxes(announce):

	class window():

		def __init__(self,*args,**kwargs):

			xbmc.executebuiltin("ActivateWindow(10147)")
			self.win=xbmcgui.Window(10147)
			xbmc.sleep(500)
			self.setControls()

		def setControls(self):

			self.win.getControl(1).setLabel(addonTitle)
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(5).setText(str(text))
			return

	window()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)
	maintenance.logs()

## ################################################## ##
## ################################################## ##

class startup(xbmcgui.WindowDialog):
	scr={}; scr['L']=0; scr['T']=0; scr['W']=1280; scr['H']=720; 
	def __init__(self,download=None,kodi=None,noteType='t',noteMessage='',noteImage='', L=140,T=110,W=1000,H=500,Font='font14',TxtColor='FFFFFFFF'):
		if len(noteImage)==0: noteImage=DefaultNoteImage
		noteType='t'
		
		self.noteType=noteType; self.noteMessage=noteMessage; self.noteImage=noteImage; self.Font=Font; self.TxtColor=TxtColor; 
		## ### ## 
		self.background=DefaultNoteImage; #artp('black1'); 
		self.BG=xbmcgui.ControlImage(L,T,W,H,self.background,aspectRatio=0); 

		iLogoW=144; iLogoH=68; 

		L2=200; T2=200; W2=880; H2=340; 
		L3=L2+5; T3=T2+60; W3=W2-18; H3=H2-5-60; 
		
		self.TxtMessage=xbmcgui.ControlTextBox(L2+5,T2,W2-10,H2,font=self.Font,textColor=self.TxtColor); 

		w1=140; h1=60; w2=140; h2=60; spacing1=20; 
		l2=L+W-spacing1-w2; t2=T+H-h2-spacing1; 
		l1=L+W-spacing1-w2-spacing1-w1; t1=T+H-h1-spacing1;
		self.buttonContinue=xbmcgui.ControlButton(l2,t2,w2,h2,"Continue",textColor="0xffffffff",focusedColor="0xFF191970",alignment=6,focusTexture=focus,noFocusTexture=nofocus);
		self.buttonDownload=xbmcgui.ControlButton(l1,t1,w1,h1,"Download",textColor="0xffffffff",focusedColor="0xFF191970",alignment=6,focusTexture=focus,noFocusTexture=nofocus);
		
		if download:		 

		    for z in [self.BG,self.TxtMessage,self.buttonContinue,self.buttonDownload]: self.addControl(z); 

		    self.buttonContinue.controlLeft(self.buttonDownload); self.buttonContinue.controlRight(self.buttonDownload); 
		    self.buttonDownload.controlLeft(self.buttonContinue); self.buttonDownload.controlRight(self.buttonContinue);

		else:
		    for z in [self.BG,self.TxtMessage,self.buttonContinue]: self.addControl(z);
		    self.buttonContinue.controlLeft(self.buttonContinue); self.buttonContinue.controlRight(self.buttonContinue); 
		
		self.setFocus(self.buttonContinue); 	
		self.TxtMessage.setText(self.noteMessage); 
		
	def ContinuePressed(self):
		self.close()
		if startupMaint == 'true': maintenance.clearCache(startup=True)
	def downloadPressed(self):
		startidle()
		#kodiMatch = checkApk('Kodi', 'version')
		#if str(currentKodi) < kodiMatch:
		    #yes_pressed=dialog.yesno(addonTitle,"Do you wish to update Kodi to the latest version", nolabel='No', yeslabel='Yes')
	
		    #if yes_pressed:
		        #import apkUpdate
		        #apkUpdate.Installer(update=True)
		        #pass

		    #else:
		        #return
		if buildName == '':
		    main.Builds()
		elif buildVersion < checkBuild(buildName, 'version'):
		    main.buildWizard(buildName, 'freshstart')
		else:
		    main.viewBuild(buildName)
		

	def onControl(self,control):
		if   control.getId()== 3003: self.ContinuePressed()
		elif   control.getId()== 3004: self.downloadPressed()
		else:
			try:
				self.setFocus(self.doWizard); 
			except: pass




###############################################################################
#						                                             SKIN SWITCHER GET OLD
###############################################################################

def getOld(old):

	try:
		old = '"%s"' % old 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (old)
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)

		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 

	except:
		pass

	return None

###############################################################################
#						                                             SKIN SWITCHER SET NEW
###############################################################################

def setNew(new, value):

	try:
		new = '"%s"' % new
		value = '"%s"' % value
		query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)
		responce = xbmc.executeJSONRPC(query)
		xbmc.executebuiltin('SendClick(11)')

	except:
		pass


	return True

###############################################################################
#						                                                  SKIN SWITCHER
###############################################################################

def swapSkins(skin):

	old = 'lookandfeel.skin'
	value = skin
	current = getOld(old)
	new = old
	if setNew(new, value):
	    return True

###############################################################################
#						                                                  DOWNLOADER
###############################################################################


###############################################################################
#						                                                  DOWNLOADER
###############################################################################

def download(url, dest, dialogProgress = None):

    if not dialogProgress:
        dialogProgress.create("Downloader","Downloading Content",' ')

    dialogProgress.update(0)
    start_time=time.time()

    try:urllib2.urlretrieve(url, dest, lambda nb, bs, fs: downloadProgress(nb, bs, fs, dialogProgress, start_time))
    except:urllib.urlretrieve(url, dest, lambda nb, bs, fs: downloadProgress(nb, bs, fs, dialogProgress, start_time))



def downloadProgress(numblocks, blocksize, filesize, dialogProgress, start_time):

        try: 
            percent = min(numblocks * blocksize * 100 / filesize, 100) 
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 

            if kbps_speed > 0 and not int(percent) == 100: 
                eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: 
                eta = 0

            kbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '%.02f MB of %.02f MB' % (currently_downloaded, total) 
            s = 'Speed: %.02f Kb/s ' % kbps_speed 
            e = 'ETA: %02d:%02d' % divmod(eta, 60) 
            if PY2:
                dialogProgress.update(percent, mbs, e)
            else:
                dialogProgress.update(int(percent), mbs+'\n'+s+'\n'+e+'\n')

        except: 
            percent = 100 
            dialogProgress.update(percent) 

        if dialogProgress.iscanceled(): 
            dialogProgress.close()
            raise Exception("Canceled")



    
def downloadProgs2(url, dest, dp):

    with open(dest, 'wb') as f:
        user_agent = {'user-agent': ('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')}
        response = requests.get(url, stream=True)

        total = response.headers.get('content-length')

        if total is None:
            f.write(response.content)
        else:
            downloaded = 0
            total = int(total)
            start_time = time.time()
            mb = 1024*1024
            
            for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
                downloaded += len(chunk)
                f.write(chunk)
                
                done = int(100 * downloaded / total)
                kbps_speed = downloaded / (time.time() - start_time)
                
                if kbps_speed > 0 and not done >= 100:
                    eta = (total - downloaded) / kbps_speed
                else:
                    eta = 0
                
                kbps_speed = kbps_speed / 1024
                type_speed = 'KB'
                
                if kbps_speed >= 1024:
                    kbps_speed = kbps_speed / 1024
                    type_speed = 'MB'
                    
                currently_downloaded = '%.02f MB of %.02f MB' % (downloaded / mb, total / mb)
                speed = 'Speed: %.02f %s ' % (kbps_speed ,type_speed)
                div = divmod(eta, 60)
                speed1 = 'ETA: %02d:%02d' % (div[0], div[1])
                
                dp.update(done, str(currently_downloaded) + '\n' + str(speed)+'\n' + str(speed1)+'\n ') 
                if dp.iscanceled():
                    dp.close()
                    return
                	

###############################################################################
#						                                                     EXTRACTOR
###############################################################################

def extractAll(_in, _out, dialogProgress):

	zin = zipfile.ZipFile(_in,  'r')
	nFiles = float(len(zin.namelist()))
	count = 0; errors = 0; error = '';
	zipit = str(_in).replace('\\', '/').split('/'); zname = zipit[len(zipit)-1].replace('.zip', '')

	try:

		for item in zin.infolist():
			count += 1; update = int(count / nFiles * 100);
			file = str(item.filename).split('/')
			if PY2:
				dialogProgress.update(update, 'Installing update: (Errors: %s)' % (errors),'[COLOR fffea800]%s[/COLOR]' % item.filename)
			else:
				dialogProgress.update(update, 'Installing update: (Errors: %s)' % (errors)+'\n[COLOR fffea800]%s[/COLOR]\n \n ' % item.filename)

			try:
				zin.extract(item, _out)


			except Exception as e:
				errors += 1; error += '%s\n' % e

	except Exception as e:
		pass

	if dialogProgress.iscanceled(): 
		raiseException("Canceled")
		dialogProgress.close()



###############################################################################
#						                                                  CONVERT TO SPECIAL
###############################################################################

def ConvertPaths(folder):

    dialogProgress.create(addonTitle,"Renaming paths to special:// \nPlease Wait")

    for root, dirs, files in os.walk(folder):
        for file in files:



            if file.endswith(".xml"):
                 dialogProgress.update(0,"Converting "+file+ " Please Wait")
                 try:a=open((os.path.join(root, file)).read())
                 except:a=open((os.path.join(root, file)),'rb').read().decode()
                 b=a.replace(userData, 'special://profile/').replace(addons,'special://home/addons/')
                 try:f = open((os.path.join(root, file)),  'w', encoding='utf-8')
                 except:f = open((os.path.join(root, file)), 'w')
                 f.write(b)
                 f.close()

    dialog.ok(addonTitle, "All file paths converted to special://\nPlease press ok to continue")

def enable17():
    if str(currentKodi) > '17':
        if str(currentKodi) > '19':
            getDB = database.connect(addons33)
        else:
            getDB = database.connect(addons27)
        listAddons = os.listdir(addons)
        getDB.executemany('update installed set enabled=1 WHERE addonID = (?)', ((name,) for name in listAddons))
        getDB.commit()
        xbmc.executebuiltin("UpdateLocalAddons()")
        notify(addonTitle, 'Enabling all addons')  
    else:
        pass


def getItems(soup):
    try: #folders
        items = (soup.find_all('tr'))
        del items[0]
    except: #files
        items = (soup.find_all('a'))
    return [x.get_text() for x in items if x.get_text() is not None]

def openkodiURL(url):
    if url is None: return

    try:
        simCache = SimpleCache()
        cacheResponce = simCache.get(addonTitle + '.openURL, url = %s'%url)
        if not cacheResponce:
            request = urllib2.Request(url)
            responce = urllib2.urlopen(request, timeout = kodiTimeout).read()
            simCache.set(addonTitle + '.openURL, url = %s'%url, responce, expiration=timedelta(minutes=5))
        return BeautifulSoup(simCache.get(addonTitle + '.openURL, url = %s'%url), "html.parser")
    except Exception as e:
        log("openURL Failed! " + str(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(addonTitle, strings(30001), icon, 4000)
        return None

def checkVersion():
    version = str(currentKodi)
    url  = droidUrl%('releases'.lower().replace('//','/'),devicePlatform) 
    soup = openkodiURL(url)
    if soup is None: return None
    label, label2 = re.compile("(.*?)\s(.*)").match(getItems(soup)[2]).groups()
    if label.endswith('.apk'):
        version = label.split('-')[1].split('-')[0]
    return version

