import maintenance
import utils
import restart
import backup
import apkUpdate
import grabdata
from variables import*

def menu():
    items = []
    downloads = ['Downloads-System Setup','Maintenance-Check device','Internet Tools-ookla Speed Checker','Addon Enabler-Enable all addons','Backup Tools-Backup / Restore setups']
    maintenance = '[COLOR ffff7e14]Maintenance:[/COLOR] Check device'
    internet = '[COLOR ffff7e14]Internet Tools:[/COLOR] ookla Speed Checker'
    backup = '[COLOR ffff7e14] Administrator:[/COLOR] Tools'
    kodifix = '[COLOR ffff7e14]Kodi fix:[/COLOR] Enable all addons'
    for item in downloads:
        label = item.split('-')[0]
        label2 = item.split('-')[1]
        item = xbmcgui.ListItem(label,label2)
        item.setArt({'icon': images+label+'.png'})
        items.append(item)

    option = dialog.select(addonTitle + ' - ' + addonversion, items, useDetails=True)

    if option == 0:
	    Downloads()
    if option == 1:
	    Maintenance()
    if option == 2:
        import ookla
    if option == 3:
	    utils.enable17()
    if option == 4:
	    adminBackup()


###############################################################################
#						                                                  DOWNLOAD MENU
###############################################################################

def Downloads():
	startidle()
	items = []
	#match          = utils.checkApk('Kodi', 'version')
	#kodi = 'Kodi Application-[COLOR lime]Up To Date[/COLOR] (%s)' % currentKodi
	build = '%s-[COLOR lime]Up To Date[/COLOR] (%s)' % (buildName,buildVersion)
	#if match > str(currentKodi):
		#kodi = 'Kodi Application-[COLOR red]Update To Version[/COLOR] (%s)' % (match)
		
	if len(buildName) > 0:
		version = buildVersion

		try:link           = utils.openURL(buildFile, 'Updates').replace('\n','').replace('\r','').replace('\t','')
		except:link           = utils.openURL(buildFile, 'Updates').decode().replace('\n','').replace('\r','').replace('\t','')
		match          = re.compile('kodi="%s"name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?kin="(.+?)"' % (MATCHED, buildName)).findall(link)

		if len(match) > 0:
		  version = match[0][0]
		  addon.setSetting('latestversion', version)

		if version > buildVersion: 
		  build = '%s-[COLOR red]Update To Version[/COLOR] (%s)' % (buildName,version)

	else: 
		  build = 'Kodi Setup-[COLOR ffff7e14]No Build Installed[/COLOR] (Click here to download)'
	
	#Klabel = kodi.split('-')[0]
	#Klabel2 = kodi.split('-')[1]
	#item = xbmcgui.ListItem(Klabel,Klabel2)
	#item.setArt({'icon': images+Klabel+'.png'})
	#items.append(item)
	Slabel = build.split('-')[0]
	Slabel2 = build.split('-')[1]
	item = xbmcgui.ListItem(Slabel,Slabel2)
	item.setArt({'icon': images+'Kodi Application.png'})
	items.append(item)
	Alabel = '-------------'
	Alabel2 = ''
	item = xbmcgui.ListItem(Alabel,Alabel2)
	item.setArt({'icon': images+'Downloads.png'})
	items.append(item)
	Alabel = 'Extras'
	Alabel2 = '[COLOR yellow]Extra Files[/COLOR] Addons and setup files'
	item = xbmcgui.ListItem(Alabel,Alabel2)
	item.setArt({'icon': images+'Downloads.png'})
	items.append(item)
	if not buildName == '':
	    Blabel = 'All Builds'
	    Blabel2 = '[COLOR yellow]Setup Files[/COLOR] Karls Custom Setups'
	    item = xbmcgui.ListItem(Blabel,Blabel2)
	    item.setArt({'icon': images+'Downloads.png'})
	    items.append(item)
	stopidle()
	option = dialog.select('DOWNLOADS', items, useDetails=True) 

	if option < 0:
	    menu()
	#if option == 0:
	    #apkUpdate.Installer(update=True)
	    
	if option == 0:
	    if buildName == '':
	        Builds()
	    else:
	        viewBuild(buildName)
	
	if option == 2:
	    viewFiles()
	
	if option == 3:
	    Builds()

###############################################################################
#						                                                  MAINTENANCE MENU
###############################################################################   

def Maintenance():
	items = []
	if not os.path.exists(packagesdir):
		os.makedirs(packagesdir)

	try:
		cacheSize    = maintenance.get_size(tempPath)
		packageSize = maintenance.get_size(packagesdir)
		thumbSize    = maintenance.get_size(thumbnails)
	except: pass
	
	try:
		convertCache    = maintenance.convertSize(cacheSize)
		convertPackages = maintenance.convertSize(packageSize)
		convertThumbs    = maintenance.convertSize(thumbSize)
	except: pass

	options = ['Clear Cache-'+ str(convertCache),'Clear Packages-' + str(convertPackages), 'Delete Thumbnails-' + str(convertThumbs),'Kodi Logs-View Logs and errors', 'Fresh Start-Wipe Kodi Clean']
	for item in options:
	    label = item.split('-')[0]
	    label2 = item.split('-')[1]
	    item = xbmcgui.ListItem(label,label2)
	    item.setArt({'icon': images+label+'.png'})
	    items.append(item)

	option = dialog.select('MAINTENANCE', items, useDetails=True) 

	if option < 0:
	    menu() 
	if option == 0:
	    maintenance.clearCache()
	if option == 1:
	    maintenance.clearPackages()
	if option == 2:
	    maintenance.removeThumbs()
	if option == 3:
	    maintenance.logs()
	if option == 4:
	    restart.freshStart()


###############################################################################
#						                                                  BACKUP MENU
###############################################################################


def adminBackup():
    items = []
    types = []
    backupbuild = 'Kodi Configuration-Backup complete setup'
    backupfavs = 'Kodi Favourites-Backup favourites.xml'
    Flabel = backupfavs.split('-')[0]
    Flabel2 = backupfavs.split('-')[1]
    item = xbmcgui.ListItem(Flabel,Flabel2)
    item.setArt({'icon': images+Flabel+'.png'})
    items.append(item)
    Slabel = backupbuild.split('-')[0]
    Slabel2 = backupbuild.split('-')[1]
    item = xbmcgui.ListItem(Slabel,Slabel2)
    item.setArt({'icon': images+Slabel+'.png'})
    items.append(item)
    tlabel = 'Zip File'
    tlabel2 = 'zip file backup'
    itemtype = xbmcgui.ListItem(tlabel,tlabel2)
    itemtype.setArt({'icon': images+Slabel+'.png'})
    types.append(itemtype)
    #t2label = 'Tar File'
    #t2label2 = 'Tar file backup for Kodi 18 and Android devices'
    #itemtype = xbmcgui.ListItem(t2label,t2label2, images+Slabel+'.png')
    #types.append(itemtype)

    option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Backup[/COLOR]', items, useDetails=True) 

    if option < 0:
      menu()

    if option == 0:
        yes_pressed=dialog.yesno(addonTitle,"Do you wish to backup your favourites", nolabel='Cancel', yeslabel='Backup')
	
        if yes_pressed:
            backup.BackUp(favourites, 'favourites.xml')


    if option == 1:
        yes_pressed=dialog.yesno(addonTitle,"Do you wish to backup your setup", nolabel='Cancel', yeslabel='Backup')

        if yes_pressed == 1:
            backup.BackUp(home, 'setup', 'zip')
        else:
            adminBackup()
    else:
      menu()


###############################################################################
#						                                                  BUILD WIZARD
###############################################################################
	
def buildWizard(name, freshstart=None):
	buildzip = utils.checkBuild(name, 'url')
	if not utils.checkUrl(buildzip) == True:
	   try:stopidle()
	   except:pass
	   utils.notify(addonTitle, 'Build Install: [COLOR ffff7e14]Invalid Zip Url![/COLOR]')
	   return
	if freshstart:
		restart.freshStart(name)

	else:
		yes_pressed = True

		if yes_pressed:

			zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')

			#if not utils.checkUrl(buildzip) == True: utils.notify(addonTitle, 'Build Install: [COLOR ffff7e14]Invalid Zip Url![/COLOR]'); return
			if not os.path.exists(packagesdir): os.makedirs(packagesdir)
			dialogProgress.update(0,'Downloading %s ' % (utils.checkBuild(name,'version'))+'\nPlease Wait')
			
			lib=os.path.join(packagesdir, '%s.zip' % zipname)


			try: os.remove(lib)
			except: pass

			utils.download(buildzip, lib, dialogProgress)
			xbmc.sleep(500)
			dialogProgress.update(0,"Installing %s " % name)

			#if buildzip.endswith('.zip?dl=1'):
			utils.extractAll(lib,home,dialogProgress)
			#elif buildzip.endswith('.gz?dl=1'):
			   #utils.extractAndroid(lib,home,dialogProgress)
			
			#xbmc.sleep(500)

			addon.setSetting('buildname', name)
			addon.setSetting('buildversion', utils.checkBuild( name,'version'))
			addon.setSetting('current.skin', utils.checkBuild( name,'skin'))
			addon.setSetting('latestversion', utils.checkBuild( name,'version'))
			
			try:
			   if os.path.exists(os.path.join(backupPath, 'favourites.xml')):
				   dialogProgress.create(addonTitle,"Adding favourites.xml:")
				   shutil.copy(os.path.join(backupPath, 'favourites.xml'), profile)
			except:
			   pass

			dialogProgress.close()
			try: os.remove(lib)
			except: pass
			dialog.ok(addonTitle, "To save changes you now need to restart Kodi, Press OK to automatically restart Kodi")
			restart.killxbmc()


def Builds():
	startidle()
	items =[]
	files = utils.getBuilds()
	if files == False:
	    dialog.ok(addonTitle, 'No Builds Available At The Moment')
	    menu()
	else:
	    for item in files:
	        label = item[0]
	        label2 = 'Version:  %s' % item[1]
	        item = xbmcgui.ListItem(label,label2)
	        item.setArt({'icon': images+'Downloads.png'})
	        items.append(item)
	    stopidle()
	    option = dialog.select('Karls Builds', items, useDetails=True) 
	    if option < 0:
	        Downloads()
	    else:
	        name = files[option][0]
	        viewBuild(name)
	
###############################################################################
#						                                                  VIEW CURRENT BUILD
###############################################################################

def viewBuild(name):
	try:
		stopidle()
	except:
		pass
	download = False     
	version = utils.checkBuild(name, 'version')
	if version == False:
	    build = 'No downloads available-'
	else:
	    download = True       
	    build = 'Download and Install-Version %s' % (version)

	label = build.split('-')[0]
	label2 = build.split('-')[1]
	item = xbmcgui.ListItem(label,label2)
	item.setArt({'icon': images+label+'.png'})
	option = dialog.select(name, [item], useDetails=True) 
	if option < 0:
	    Downloads()
	if option == 0:
	    if download == True:
	       startidle()
	       buildWizard(name, 'freshstart')

def viewFiles():
	startidle()
	items =[]
	files = utils.getFiles()
	if files == False:
	    dialog.ok(addonTitle, 'No Extras Available At The Moment')
	    menu()
	else:
	    for item in files:
	        label = item.split('-')[0]
	        label2 = item.split('-')[1]
	        item = xbmcgui.ListItem(label,label2)
	        item.setArt({'icon': images+'Downloads.png'})
	        items.append(item)
	    stopidle()
	    option = dialog.select('Kodi Extras', items, useDetails=True) 
	    if option < 0:
	        Downloads()
	    else:
		    file = files[option]
		    dialogProgress.create(addonTitle,"Getting %s url" % file.split('-')[0])
		    
		    fileurl = utils.checkFiles(file, 'link')
		    location = utils.checkFiles(file, 'location')
		    if not os.path.exists(packagesdir): os.makedirs(packagesdir)
		    
		    dialogProgress.update(0,'Downloading %s ' % (file.split('-')[0])+'\nPlease Wait')
		    lib=os.path.join(packagesdir, '%s.zip' % file.split('-')[0])
		    try: os.remove(lib)
		    except: pass

		    utils.download(str(fileurl), lib, dialogProgress)
		    xbmc.sleep(500)
		    dialogProgress.update(0,"Installing %s " % file.split('-')[0])

		    path = transPath(location)
		    utils.extractAll(lib,path,dialogProgress)
			
		    dialogProgress.close()
		    try: os.remove(lib)
		    except: pass
		    dialog.ok(addonTitle, "%s Successfully Downloaded" % file.split('-')[0])
		    utils.enable17()


if __name__ == '__main__' :
    menu()
