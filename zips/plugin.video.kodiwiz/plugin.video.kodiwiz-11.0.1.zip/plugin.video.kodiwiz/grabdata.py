import xbmc, xbmcgui, xbmcvfs 
import sqlite3
import datetime
import time
import re
dialog = xbmcgui.Dialog()
try:transPath = xbmc.translatePath 
except: transPath = xbmcvfs.translatePath 
program_db = transPath('special://profile/addon_data/plugin.program.iptv.merge/data.db')



def importData():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    groups = ['Football', 'EFL', 'Live Events', 'UFC']
    channelList = []
    sqlite3.register_adapter(datetime.datetime, adapt_datetime)
    sqlite3.register_converter('timestamp', convert_datetime)
    conn = sqlite3.connect(program_db, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread=False)
    c = conn.cursor()
    c.execute('DELETE FROM override')

    c.execute('SELECT * FROM channel WHERE playlist_id=2')
    for row in c:
        channel = [row[0], row[1], row[5], row[7]]
        channelList.append(channel)       

    for channel in channelList:
        notvisible = ""
        fields = ""
        findgroup = eval(channel[3])
            
        if not findgroup[0] in groups:
                
            if findgroup[0] == 'General Streams' and 'UK:' not in channel[2]:
                fields = '{"groups": ["Entertainment"], "visible": false}'
            elif findgroup[0] == 'General Streams' :
                fields = '{"groups": ["Entertainment"]}'
            elif findgroup[0] == 'Documentaries' and 'UK:' not in channel[2]:
                fields = '{"groups": ["Documentary"], "visible": false}'
            elif findgroup[0] == 'Documentaries':
                fields = '{"groups": ["Documentary"]}'
            elif 'UK:' not in channel[2]:
                fields = '{"visible": false}'
            if fields != "":
                c.execute(
                    'INSERT OR REPLACE INTO override(slug, playlist_id, fields, attribs, properties, headers) VALUES(?, ?, ?, ?, ?, ? )',
                    [channel[0], channel[1], fields, "{}", "{}", "{}"])
                if not c.rowcount:
                    c.execute(
                        'UPDATE override SET slug=?, playlist_id=?, fields=?, attribs=?, properties=?, headers=?',
                        [channel[0], channel[1], fields, "{}", "{}", "{}"])
            fields = ""
            notvisible = ""


    channelList = None
    conn.commit()
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    
    
    
def editData():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    groups = ['DAZN']
    channelList = []
    sqlite3.register_adapter(datetime.datetime, adapt_datetime)
    sqlite3.register_converter('timestamp', convert_datetime)
    conn = sqlite3.connect(program_db, detect_types=sqlite3.PARSE_DECLTYPES, check_same_thread=False)
    c = conn.cursor()

    c.execute('SELECT * FROM channel WHERE playlist_id=2')
    for row in c:
        channel = [row[0], row[1], row[5], row[7]]
        channelList.append(channel)       

    for channel in channelList:
        notvisible = ""
        fields = ""
        findgroup = eval(channel[3])
            
        if findgroup[0] in groups:
            c.execute('DELETE FROM override WHERE slug=?', [channel[0]])


    channelList = None
    conn.commit()
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

def adapt_datetime(ts):
    return time.mktime(ts.timetuple())

def convert_datetime(ts):
    try:
        return datetime.datetime.fromtimestamp(float(ts))
    except ValueError:
        return None

