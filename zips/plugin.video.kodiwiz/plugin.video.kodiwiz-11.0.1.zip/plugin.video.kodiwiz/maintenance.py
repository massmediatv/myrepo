import utils
import restart
from variables import*

def removeThumbs():

    if os.path.exists(thumbnails)==True:  

        try:
            shutil.rmtree(thumbnails)
            os.remove(textures)
        except:
            dialog.ok(addonTitle, 'Error removing thumbnails folders or textures.db file')

        if not os.path.exists(thumbnails) or not os.path.exists(textures):
            dialog.ok(addonTitle, 'Thumbnails were successfully removed\nPlease press ok and wait for kodi to Close')
            restart.killxbmc()

    else:
        dialog.ok(addonTitle, 'Thumbnails folder not found')

def clearPackages(over=None):

	if os.path.exists(packagesdir):

		try:	
			shutil.rmtree(packagesdir)
		except: 
			utils.notify(addonTitle,'Clear Packages: [COLOR red]Error[/COLOR]!')

		if not os.path.exists(packagesdir):
			utils.notify(addonTitle,'Clear Packages: [COLOR green]Success[/COLOR]!')

	else: 
		utils.notify(addonTitle,'Clear Packages: [COLOR red]None Found![/COLOR]')
 

def checkSizes	():
    print("MAINTENANCE SETTINGS", filesize, filesize_thumb)
    total_size2 = 0
    total_size = 0
    count = 0


    for dirpath, dirnames, filenames in os.walk(packagesdir):
	    count = 0
	    for f in filenames:
		    count += 1
		    fp = os.path.join(dirpath, f)
		    total_size += os.path.getsize(fp)
    total_sizetext = "%.0f" % (total_size/1024000.0)
	
    if int(total_sizetext) > filesize:
	    clearPackages('startup')
			
    for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
	    for f2 in filenames2:
		    fp2 = os.path.join(dirpath2, f2)
		    total_size2 += os.path.getsize(fp2)
    total_sizetext2 = "%.0f" % (total_size2/1024000.0)

    if int(total_sizetext2) > filesize_thumb:
	    removeThumbs()
    else: 
	    utils.forceUpdate()
 
def clearCache(startup=False):
	cachelist = [
		(addonData),
		(os.path.join(home,'cache')),
		(os.path.join(home,'temp')),
		(os.path.join(addonData,'plugin.video.itv','Images'))]
		
	delfiles = 0

	for item in cachelist:

		if os.path.exists(item) and not item in [addonData]:
			for root, dirs, files in os.walk(item):

				file_count = 0
				file_count += len(files)

				if file_count > 0:
					for f in files:
						if not f in ['kodi.log', 'xbmc.log']:
							try:
								os.unlink(os.path.join(root, f))
							except:
								pass

					for d in dirs:
						try:
							shutil.rmtree(os.path.join(root, d))
							delfiles += 1
						except:
							pass

		else:
			for root, dirs, files in os.walk(item):
				for d in dirs:
					if 'cache' in d.lower():

						try:
							shutil.rmtree(os.path.join(root, d))
							delfiles += 1
						except:
							pass


	utils.notify(addonTitle,'Clear Cache: Removed %s Files' % delfiles)
	if startup == True: checkSizes()


def viewLogFile():
			
	if os.path.exists(kodilog):
		if os.path.exists(kodilog) and os.path.exists(kodiold):
			option = dialog.yesno(addonTitle,"Which log would you like to view?","","Current or Old", yeslabel='[B]OLD[/B]',nolabel='[B]CURRENT[/B]')
			if option == 0:
				f = open(kodilog,mode='rb'); msg = f.read(); f.close()
				utils.TextBoxes("%s - kodi.log" % msg)
			else:
				f = open(kodiold,mode='rb'); msg = f.read(); f.close()
				utils.TextBoxes("%s - kodi.old.log" % msg)
		else:
			f = open(kodilog,mode='rb'); msg = f.read(); f.close()
			utils.TextBoxes("%s - kodi.log" % msg)		
			
	if os.path.isfile(kodilog):
		return True
	else:
		dialog.ok(addonTitle,'No log file was found.')
		logs()

def view_LastError():

	found = 0

	if os.path.exists(transPath('special://logpath/')):
		try:openlog=open(kodilog, 'rb').read().decode('utf-8')	
		except:openlog=open(kodilog).read()
		scanlog=openlog.replace('\n','NEW_L').replace('\r','NEW_R')
		match = re.compile('EXCEPTION Thrown(.+?)End of Python script error report').findall(scanlog)
		for checker in match:
			found = 1
			founderror = "[B][COLOR red]THE LAST ERROR IN YOUR LOG WAS:[/B][/COLOR]\n\n" + checker + '\n'
		if found == 0:
			dialog.ok(addonTitle,'No errors were found in your log.')
		else:
			c=founderror.replace('NEW_L','\n').replace('NEW_R','\r')
			utils.TextBoxes("%s" % c)

	else:
		dialog.ok(addonTitle,'No log file was found on your system')
		logs()

def logs():
	items = []
	founderrors = 0

	if os.path.exists(transPath('special://logpath/')):
		try:openlog=open(kodilog, 'rb').read().decode('utf-8')	
		except:openlog=open(kodilog).read()
		scanlog=openlog.replace('\n','NEW_L').replace('\r','NEW_R')
		match = re.compile('EXCEPTION Thrown(.+?)End of Python script error report').findall(scanlog)
		for checker in match:
			founderrors = founderrors + 1
	
	if founderrors == 0:
		errorslogged = "View Errors-Errors found [COLOR ffffffff]0[/COLOR]"
	else:
		errorslogged = "View Errors-Errors found [COLOR ffff7e14]" + str(founderrors) + "[/COLOR]"
	rLogs = 'Read logs-Current or old logs'
	Klabel = errorslogged.split('-')[0]
	Klabel2 = errorslogged.split('-')[1]
	item = xbmcgui.ListItem(Klabel,Klabel2)
	item.setArt({'icon': images+Klabel+'.png'})
	items.append(item)
	Slabel = rLogs.split('-')[0]
	Slabel2 = rLogs.split('-')[1]
	item = xbmcgui.ListItem(Slabel,Slabel2)
	item.setArt({'icon': images+Slabel+'.png'})
	items.append(item)
	resp = dialog.select(addonTitle+' [COLOR ffff7e14]XBMC Logs[/COLOR]', items, useDetails=True) 
	if resp < 0:
	    import main
	    main.Maintenance()

	if resp == 0:
	    view_LastError()
	if resp == 1:
	    viewLogFile()

def get_size(start_path):
	total_size = 0
	for dirpath, dirnames, filenames in os.walk(start_path):
		for f in filenames:
			fp = os.path.join(dirpath, f)
			total_size += os.path.getsize(fp)
	return total_size

def convertSize(size):
   import math
   if (size == 0):
       return '[COLOR ffffffff]0 MB[/COLOR]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")#!f!T!G!#
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
       return '[COLOR lime]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name[i] == "KB":##f#T#G##
       return '[COLOR ffffffff]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name[i] == "GB":
       return '[COLOR lightskyblue]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name[i] == "TB":
       return '[COLOR lightskyblue]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s < 50:
       return '[COLOR ffffffff]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 50:
       if s < 100:
           return '[COLOR red]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 100:
       return '[COLOR lightskyblue]%s %s' % (s,size_name[i]) + '[/COLOR]'

def convertSizeInstall(size):
   import math
   if (size == 0):
       return '[COLOR blue]0 MB[/COLOR]'
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size,1024)))
   p = math.pow(1024,i)
   s = round(size/p,2)
   if size_name[i] == "B":
       return '[COLOR lime]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name[i] == "KB":
       return '[COLOR ffffffff]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if size_name[i] == "TB":
       return '[COLOR lightskyblue]%s %s' % (s,size_name[i]) + '[/COLOR]'#!f!T!G!#
   if s < 1000:
       return '[COLOR ffffffff]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 1000:
       if s < 1500:
           return '[COLOR red]%s %s' % (s,size_name[i]) + '[/COLOR]'
   if s >= 1500:
       return '[COLOR lightskyblue]%s %s' % (s,size_name[i]) + '[/COLOR]'

